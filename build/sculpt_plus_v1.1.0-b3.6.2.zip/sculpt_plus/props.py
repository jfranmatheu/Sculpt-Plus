_G='SIMPLIFY'
_F='DISPLACEMENT_SMEAR'
_E='DISPLACEMENT_ERASER'
_D='DRAW_FACE_SETS'
_C='sculpt_plus'
_B='NONE'
_A=None
from typing import Union,List,Dict,Set,Tuple
from enum import Enum,auto
import bpy
from bpy.types import Context,Image as BlImage,ImageTexture as BlImageTexture,Brush as BlBrush,WorkSpace
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.path import SculptPlusPaths
from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
from brush_manager.api import bm_types,BM_UI
from brush_manager.globals import GLOBALS,CM_UIContext
from sculpt_plus.globals import G
sculpt_tool_brush_name:Dict[str,str]={'BLOB':'Blob','BOUNDARY':'Boundary','CLAY':'Clay','CLAY_STRIPS':'Clay Strips','CLAY_THUMB':'Clay Thumb','CLOTH':'Cloth','CREASE':'Crease',_D:'Draw Face Sets','DRAW_SHARP':'Draw Sharp','ELASTIC_DEFORM':'Elastic Deform','FILL':'Fill/Deepen','FLATTEN':'Flatten/Contrast','GRAB':'Grab','INFLATE':'Inflate/Deflate','LAYER':'Layer','MASK':'Mask','MULTIPLANE_SCRAPE':'Multi-plane Scrape',_E:'Multires Displacement Eraser',_F:'Multires Displacement Smear','NUDGE':'Nudge','PAINT':'Paint','PINCH':'Pinch/Magnify','POSE':'Pose','ROTATE':'Rotate','SCRAPE':'Scrape/Peaks','DRAW':'SculptDraw',_G:'Simplify','TOPOLOGY':'Slide Relax','SMOOTH':'Smooth','SNAKE_HOOK':'Snake Hook','THUMB':'Thumb'}
builtin_brush_names:Tuple[str]=tuple(sculpt_tool_brush_name.values())
builtin_brushes:Set[str]=set(builtin_brush_names)
builtin_images:Set[str]={'Render Result','Viewer Node'}
manager_exclude_brush_tools:Set[str]={'MASK',_D,_G,_E,_F}
toolbar_hidden_brush_tools:Set[str]={A for A in sculpt_tool_brush_name.keys()if A not in manager_exclude_brush_tools}
exclude_brush_names:Set[str]={sculpt_tool_brush_name[A]for A in manager_exclude_brush_tools}
filtered_builtin_brush_names=tuple((A for A in builtin_brush_names if A not in exclude_brush_names))
stored_sculpt_tool=_B
IN_BRUSH_CTX=lambda _type:_type=='BRUSH'
IN_TEXTURE_CTX=lambda _type:_type=='TEXTURE'
' Helper to get properties paths (with typing). '
class Props:
	@staticmethod
	def Workspace(context=_A)->WorkSpace or _A:
		A=context;A=A if A else bpy.context
		for B in bpy.data.workspaces:
			if _C in B:return B
		return _A
	@staticmethod
	def WorkspaceSetup(context)->WorkSpace or _A:
		C='Sculpt+';A=context;D=A.window.workspace
		try:Props.Temporal(A).test_context=True
		except RuntimeError as E:print(E);return _A
		bpy.ops.workspace.append_activate(False,idname=C,filepath=SculptPlusPaths.BLEND_WORKSPACE());B:WorkSpace=bpy.data.workspaces.get(C,_A);A.window.workspace=B
		if _C not in B:B[_C]=1
		A.window.workspace=D;return B
	@staticmethod
	def Canvas()->Union[Canvas,_A]:
		if not hasattr(bpy,'sculpt_hotbar'):return _A
		return bpy.sculpt_hotbar._cv_instance
	@staticmethod
	def Scene(context:Context):return context.scene.sculpt_plus
	@staticmethod
	def Temporal(context:Context):return context.window_manager.sculpt_plus
	@classmethod
	def UI(A,context:Context):return A.Temporal(context).ui
	class SculptTool:
		@staticmethod
		def get_stored()->str:global stored_sculpt_tool;return stored_sculpt_tool
		@staticmethod
		def set_stored(id:str)->_A:global stored_sculpt_tool;stored_sculpt_tool=id
		@staticmethod
		def clear_stored()->_A:global stored_sculpt_tool;stored_sculpt_tool=_B
		@staticmethod
		def get_from_context(context:Context)->tuple[str,str]:
			try:A=ToolSelectPanelHelper._tool_active_from_context(context,'VIEW_3D',mode='SCULPT',create=False)
			except AttributeError as B:print('[SCULPT+] WARN!',B);return _A,_B
			if A is _A:print('[SCULPT+] WARN! Current active tool is NULL');return _A,_B
			type,A=A.idname.split('.');A=A.replace(' ','_').upper();return type,A
		@classmethod
		def update_stored(A,context:Context)->str:global stored_sculpt_tool;stored_sculpt_tool=A.get_from_context(context)[1]
		@classmethod
		def has_changed(A,context:Context)->bool:global stored_sculpt_tool;return stored_sculpt_tool!=A.get_from_context(context)[1]