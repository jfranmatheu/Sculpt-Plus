_A=None
import os,bpy
from enum import Enum
import bpy.utils.previews
from .path import SculptPlusPaths
preview_collections={}
class CallEnum(Enum):
	def __call__(A)->int:
		B=preview_collections.get(A.__class__.__name__,_A)
		if B is _A:B=bpy.utils.previews.new();preview_collections[A.__class__.__name__]=B
		C=B.get(A.name,_A)
		if C is not _A:return C.icon_id
		B.load(A.name,SculptPlusPaths.SRC_LIB_IMAGES_ICONS(A.value+'.png'),'IMAGE');C=B.get(A.name,_A)
		if C is not _A:return C.icon_id
		return 0
class Previews:
	class Main(CallEnum):BRUSH='.brush_icon';BRUSH_ADD='.brushAdd_icon';FILL='.icons8-fill-drip-32';MIRROR='.Mirror_icon';SCALE_UP='.ScaleUp_icon';SCALE_DOWN='.ScaleDown_icon';FRONT_FACES='.frontFaces_icon';BRUSH_BROOM='.icons8-broom-64'
	class Mask(CallEnum):MASK='.Mask_icon';CLEAR='.MaskClear_icon';INVERT='.MaskInvert_icon';GROW='.MaskScaleUp_icon_flat';SHRINK='.MaskScaleDown_icon_flat';SHARP='.MaskSharp_icon';SMOOTH='.MaskSmooth_icon';BOX='.Box_Mask_icon';LASSO='.Lasso_Mask_icon';CONTRAST_UP='.MaskContrastUp_icon_flat';CONTRAST_DOWN='.MaskContrastDown_icon_flat';EXTRACT='.MaskExtract_icon2';SLICE='.MaskSlice_icon';RANDOM='.MaskRandom_icon';CAVITY='.MaskCavity_icon'
	class FaceSets(CallEnum):FACE_SETS='.FaceSets_icon';GROW='.FaceSetsScaleUp_icon';SHRINK='.FaceSetsScaleDown_icon';BOX='.Box_FaceSet_icon';LASSO='.Lasso_FaceSet_icon'
"\ndef register():\n    # Note that preview collections returned by bpy.utils.previews\n    # are regular py objects - you can use them to store custom data.\n    return\n\n    import bpy.utils.previews\n    for collection_name in preview_collections.keys():\n        pcoll = bpy.utils.previews.new()\n        for item in getattr(Previews, collection_name):\n            print(item.name, item.value)\n            pcoll.load(item.name, SculptPlusPaths.SRC_LIB_IMAGES_ICONS(item.value + '.png'), 'IMAGE')\n        preview_collections[collection_name] = pcoll\n"
def unregister():
	for A in preview_collections.values():
		if A is not _A:bpy.utils.previews.remove(A)
	preview_collections.clear()