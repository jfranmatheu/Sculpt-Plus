from pathlib import Path
def read_file(file_path:str or Path)->str:
	A=file_path
	if isinstance(A,Path):A=str(A)
	with open(A,'r')as B:C=B.read();return C