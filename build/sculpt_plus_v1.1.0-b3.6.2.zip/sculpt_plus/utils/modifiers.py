from typing import Union
from bpy.types import Modifier
def get_modifier_by_type(object,modifier_type:str)->Union[Modifier,None]:
	for A in object.modifiers:
		if A.type==modifier_type:return A
	return None