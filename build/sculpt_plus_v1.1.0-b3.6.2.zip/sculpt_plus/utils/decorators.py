from functools import wraps
def singleton(orig_cls):
	B=orig_cls;C=B.__new__;A=None
	@classmethod
	def D(cls):nonlocal A;return A
	@classmethod
	def E(cls,data):nonlocal A;A=data
	@wraps(B.__new__)
	def __new__(cls,*B,**D):
		nonlocal A
		if A is None:A=C(cls,*(B),**D)
		return A
	B.__new__=__new__;B.get_instance=D;B.set_instance=E;return B