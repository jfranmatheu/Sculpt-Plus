_M='SECTIONS'
_L='sculpt_hotbar'
_K='Active Slot Color'
_J='Slot Background Color'
_I='Background Color'
_H='DIR_PATH'
_G='NONE'
_F=False
_E=None
_D=True
_C='COLOR'
_B=0.0
_A=1.0
from bpy.types import AddonPreferences,Context
from bpy.props import StringProperty
from sculpt_plus.path import SculptPlusPaths
from bpy.types import AddonPreferences,Region
from bpy.props import FloatProperty,BoolProperty,EnumProperty,IntVectorProperty,IntProperty,FloatVectorProperty,StringProperty
from mathutils import Vector
import bpy,os
from os.path import dirname,abspath,join
app_data_path=os.getenv('APPDATA')
SLOT_SIZE=56
enum_list=[(_G,'None','')]
class SCULPTPLUS_AddonPreferences(AddonPreferences):
	bl_idname:str=__package__;first_time:BoolProperty(default=_F);brush_lib_path:StringProperty(name='Brush Library Directory',description='Folder where to save your brush sets',default=SculptPlusPaths.APP__DATA(),subtype=_H);num_backup_versions:IntProperty(name='Backup Versions',description='Number of Backup Versions to store',default=2,min=0,max=10)
	def get_scale(A,context)->float:B=context.preferences.system.ui_scale;return B*A.scale
	def update_ui(A,context):
		B=context
		if not hasattr(bpy,_L):return
		if bpy.sculpt_hotbar is _E:return
		C=bpy.sculpt_hotbar.get_cv(B.region)
		if not C:return
		D=A.get_scale(B);C.update(_E,_E,D,A)
	data_path_local=StringProperty(default=join(dirname(abspath(__file__)),'data'),subtype=_H);data_path=StringProperty(default=join(app_data_path,_L)if app_data_path else join(dirname(abspath(__file__)),'data'),subtype=_H);use_smooth_scroll:BoolProperty(default=_D,name='Smooth Scroll',update=update_ui);padding:IntProperty(default=1,min=0,max=6,name='Hotbar Brush-Icon Padding',update=update_ui);margin_bottom:IntProperty(default=8,min=0,max=64,name='Hotbar Bottom Margin',update=update_ui);margin_left:IntProperty(default=8,min=0,max=64,name='Sidebar Left Margin',update=update_ui);scale:FloatProperty(default=_A,min=0.8,max=2.0,name='Scale',update=update_ui);theme_hotbar:FloatVectorProperty(size=4,default=(0.007,0.007,0.007,0.95),min=_B,max=_A,name=_I,subtype=_C);theme_hotbar_slot:FloatVectorProperty(size=4,default=(0.09,0.09,0.09,0.85),min=_B,max=_A,name=_J,subtype=_C);theme_shelf:FloatVectorProperty(size=4,default=(0.1,0.1,0.1,0.9),min=_B,max=_A,name=_I,subtype=_C);theme_shelf_slot:FloatVectorProperty(size=4,default=(0.16,0.16,0.16,0.5),min=_B,max=_A,name=_J,subtype=_C);theme_sidebar:FloatVectorProperty(size=4,default=(0.1,0.1,0.1,0.9),min=_B,max=_A,name=_I,subtype=_C);theme_sidebar_slot:FloatVectorProperty(size=4,default=(0.16,0.16,0.16,0.5),min=_B,max=_A,name=_J,subtype=_C);theme_selected_slot_color:FloatVectorProperty(size=4,default=(0.9,0.5,0.4,_A),min=_B,max=_A,name='Selected Slot Color',subtype=_C);theme_active_slot_color:FloatVectorProperty(size=4,default=(0.2,0.5,0.9,_A),min=_B,max=_A,name=_K,subtype=_C);theme_slot_outline_color:FloatVectorProperty(size=4,default=(0.1,0.1,0.1,0.9),min=_B,max=_A,name=_K,subtype=_C);theme_slot_color:FloatVectorProperty(size=4,default=(0.1,0.1,0.1,0.9),min=_B,max=_A,name=_K,subtype=_C);theme_text:FloatVectorProperty(size=4,default=(0.92,0.92,0.92,1),min=_B,max=_A,name='Text Color (0-9)',subtype=_C)
	def get_camera_list(B,context):
		enum_list.clear()
		for A in context.scene.objects:
			if A.type=='CAMERA':enum_list.append((A.name,A.name,''))
		if enum_list:return enum_list
		return[(_G,'None','')]
	set_list:EnumProperty(items=get_camera_list,name='Camera List');toolbar_position:EnumProperty(name='Toolbar Position',items=(('LEFT','Left','Left, while panels will be at its right'),('RIGHT','Right','Right, while panels will be at its left')),default='LEFT');toolbar_panel_mask_layout:EnumProperty(name='Mask Panel Layout',items=(('COMPACT','Compact','A simple and compact display of the different mask operations, without subpanels/sections or tabs'),(_M,'Sections','A set of sections (box-like) for each kind of mask operation'),('TABS','Tabs','Only the selected tab option is visible')),default=_M)
	def draw(A,context):
		H='STATUSBAR';D=A.layout;D.use_property_split=_D
		if A.first_time:return
		def B(title:str,icon:str=_G,align=_D,_layout=_E,*F):
			B=_layout;B=B or D;C=B.column(align=_D);C.box().row(align=_D).label(text=title,icon=icon);E=C.box().column(align=align)
			for G in F:E.prop(A,G)
			return E
		E=B('3D Viewport Toolbar Settings','TOOL_SETTINGS',align=_F);E.row().prop(A,'toolbar_position',expand=_D);E.prop(A,'toolbar_panel_mask_layout');' SCULPT HOTBAR.... ';C=B('Sculpt Hotbar Preferences',H);C=C.split(factor=0.4);F=B('General UI Settings','SETTINGS',align=_F,_layout=C);F.prop(A,'scale',slider=_D);F.prop(A,'use_smooth_scroll');G=B('Style',H,align=_F,_layout=C);G.prop(A,'margin_bottom',text='Bottom Margin',slider=_D);G.prop(A,'padding',text='Brush Icon Padding',slider=_D)
def get_prefs(context:Context)->SCULPTPLUS_AddonPreferences:
	A=context
	if __package__ not in A.preferences.addons:return _E
	return A.preferences.addons[__package__].preferences