import subprocess,sys,os,bpy
addons_path:str=os.path.join(bpy.utils.user_resource('SCRIPTS'),'addons')
class VersionError(Exception):0
def check_brush_manager():
	from .  import BM_VERSION as C;D='brush_manager'
	try:
		import brush_manager as A
		if hasattr(A,'tag_version')and A.tag_version!=C:raise VersionError(f"Required Brush Manager version is {C} but found {A.tag_version}")
	except (ModuleNotFoundError,ImportError)as B:print(B)
	except VersionError as B:print(B)
PILL_IMPORT_ERROR=False
PILL_UPDATE_ERROR=False
def is_pil_ok()->bool:global PILL_IMPORT_ERROR;return PILL_IMPORT_ERROR
def install_pill():
	E='install';C='pip';B='-m';from .  import PILLOW_VERSION as F;A=os.path.join(sys.prefix,'bin','python.exe');G=os.path.join(sys.prefix,'lib','site-packages')
	try:
		import PIL
		if not hasattr(PIL,'__version__')or float(PIL.__version__[:-2])<9.3:print('Pillow version is too old! Requires to install a recent version...');raise VersionError('Pillow version is too old!')
	except (ModuleNotFoundError,ImportError):
		subprocess.call([A,B,'ensurepip']);subprocess.call([A,B,C,E,'--upgrade',C])
		try:subprocess.call([A,B,C,E,F,'-t',G])
		except PermissionError as D:print(D);global PILL_IMPORT_ERROR;PILL_IMPORT_ERROR=True
	except VersionError:
		try:subprocess.call([A,B,C,E,'--ignore-installed',F,'-t',G])
		except PermissionError as D:print(D);global PILL_UPDATE_ERROR;PILL_UPDATE_ERROR=True
def install():check_brush_manager();install_pill();'\n    os.system("pip3 install -r requirements.txt")\n    os.system("pip3 install -r requirements-dev.txt")\n    os.system("pip3 install -r requirements-test.txt")\n    '