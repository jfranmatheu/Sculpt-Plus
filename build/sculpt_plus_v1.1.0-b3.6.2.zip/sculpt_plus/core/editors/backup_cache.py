from bl_ui.space_view3d import VIEW3D_HT_tool_header
from bpy.types import VIEW3D_PT_tools_brush_select,VIEW3D_PT_tools_active,VIEW3D_PT_tools_brush_settings
from collections import defaultdict
classes_to_cache=VIEW3D_PT_tools_active,VIEW3D_HT_tool_header,VIEW3D_PT_tools_brush_select,VIEW3D_PT_tools_brush_settings
_cache_reset={}
_mod_cls_attributes=defaultdict(set)
def get_attr_from_cache(cls,attr,default=None):
	A=default
	if(B:=_cache_reset.get(cls,None)):
		if hasattr(B,attr):return B.get(attr,A)
	return A
def cache_cls_attributes(cls):_cache_reset[cls]=cls.__dict__.copy()
def set_cls_attribute(cls,attr,new_value):
	B=attr;A=cls
	if A not in _cache_reset:cache_cls_attributes(A)
	_mod_cls_attributes[A].add(B);setattr(A,'old_'+B,get_attr_from_cache(A,B));setattr(A,B,new_value)
def pre_register():
	for A in classes_to_cache:cache_cls_attributes(A)
def pre_unregister():
	for (B,D) in _mod_cls_attributes.items():
		C=_cache_reset[B]
		for A in D:
			if not hasattr(B,A)or A not in C:continue
			setattr(B,A,C[A]);delattr(B,'old_'+A)