_B='sculpt_plus'
_A='SCULPT'
import bpy
from bpy.utils import register_class,unregister_class
from bpy.types import VIEW3D_PT_tools_brush_select,VIEW3D_PT_tools_active,VIEW3D_PT_tools_brush_settings,VIEW3D_PT_tools_brush_settings_advanced,VIEW3D_PT_tools_brush_falloff,VIEW3D_PT_tools_brush_stroke,VIEW3D_PT_tools_brush_texture
from bl_ui.properties_paint_common import UnifiedPaintPanel,BrushSelectPanel,BrushPanel
from bpy.types import VIEW3D_PT_sculpt_dyntopo,VIEW3D_PT_sculpt_voxel_remesh,VIEW3D_PT_sculpt_symmetry,VIEW3D_PT_sculpt_options_gravity,VIEW3D_PT_sculpt_options
from .backup_cache import get_attr_from_cache
classes_to_override__poll=VIEW3D_PT_tools_brush_select,VIEW3D_PT_tools_brush_settings
classes_to_override__draw=()
panels_to_override__category=()
@classmethod
def poll(cls,context):
	A=context
	if A.mode==_A and _B in A.workspace:return False
	return A.object and A.mode==_A
def poll_default(cls,context):return True
def draw(self,context):
	A=context
	if A.mode==_A and _B in A.workspace:return False
	self.__class__._ori_draw(A)
def draw_default(self,context):0
def register():
	for A in classes_to_override__poll:A.poll=poll
	for A in classes_to_override__draw:A._ori_draw=get_attr_from_cache(A,'draw',draw_default);A.draw=draw
	for A in panels_to_override__category:unregister_class(A);A.bl_category='Sculpt';register_class(A)