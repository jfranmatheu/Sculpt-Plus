from bl_ui.properties_paint_common import StrokePanel
class DummyPanel(StrokePanel):
	def __init__(A,layout):A.layout=layout