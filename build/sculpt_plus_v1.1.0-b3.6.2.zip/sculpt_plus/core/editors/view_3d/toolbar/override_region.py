_F='idname'
_E='builtin_brush'
_D='sculpt_plus'
_C=None
_B=False
_A=True
from bl_ui.space_toolsystem_toolbar import VIEW3D_PT_tools_active
from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
from time import time
from sculpt_plus.props import Props,toolbar_hidden_brush_tools,SculptTool
from sculpt_plus.prefs import get_prefs
from .panels import *
from ...backup_cache import set_cls_attribute
def _layout_generator_single_row(layout,scale_y):
	col=layout.row(align=_A);is_sep=_B
	while _A:
		if is_sep is _A:col=layout.row(align=_A);col.scale_y=scale_y
		elif is_sep is _C:yield _C;return
		is_sep=yield col
def draw_cls(cls,layout,context,detect_layout=_A,default_layout='COL',scale_y=1.75,spacing=0.25):
	G='wm.tool_set_by_id';F='ALL_BRUSH';E='MULTIRES_DISPLACEMENT_SMEAR';D='MULTIRES_DISPLACEMENT_ERASER';C='DRAW_FACE_SETS';B='SIMPLIFY';A='NONE';use_legacy_sculpt=_D not in context.workspace;using_multires:bool=[_A for mod in context.sculpt_object.modifiers if mod.type=='MULTIRES']!=[];using_dyntopo:bool=context.sculpt_object.use_dynamic_topology_sculpting;space_type=context.space_data.type;active_tool=ToolSelectPanelHelper._tool_active_from_context(context,space_type);tool_active_id=getattr(active_tool,_F,_C);active_tool_type,active_tool_id=SculptTool.get_from_context(context);active_tool_id_upper:str=active_tool_id.replace(' ','_').upper();stored_tool_id=SculptTool.get_stored();is_brush=active_tool_type==_E;hidden_brush_tool_selected=active_tool_id_upper in toolbar_hidden_brush_tools
	if stored_tool_id==A and active_tool_id!=A and is_brush and hidden_brush_tool_selected:SculptTool.set_stored(active_tool_id)
	if detect_layout:ui_gen,show_text=cls._layout_generator_detect_from_region(layout,context.region,scale_y)
	else:
		if default_layout=='COL':ui_gen=ToolSelectPanelHelper._layout_generator_single_column(layout,scale_y)
		else:ui_gen=_layout_generator_single_row(layout,scale_y)
		show_text=_A
	ui_gen.send(_C);dyntopo_tools={B};anti_dyntopo_tools={C,'BOX_FACE_SET','LASSO_FACE_SET','FACE_SET_EDIT','COLOR_FILTER','PAINT','SMEAR','MASK_BY_COLOR'};multires_tools={D,E};skip_first_brush={'MASK',C,D,E,B};skipped_brushes=set();tools_from_context=cls.tools_from_context(context)
	for item in tools_from_context:
		if item is _C:ui_gen.send(_A);layout.separator(factor=spacing);continue
		if type(item)is tuple:
			is_active=_B;i=0
			for (i,sub_item) in enumerate(item):
				if sub_item is _C:continue
				is_active=sub_item.idname==tool_active_id
				if is_active:index=i;break
			del i,sub_item
			if is_active:cls._tool_group_active[item[0].idname]=index
			else:index=cls._tool_group_active_get_from_item(item)
			item=item[index];use_menu=_A
		else:index=-1;use_menu=_B
		is_active=item.idname==tool_active_id;tool_idname:str=item.idname.split('.')[1].replace(' ','_').upper()
		if _E in item.idname:
			if tool_idname in skipped_brushes:0
			elif tool_idname in skip_first_brush:skipped_brushes.add(tool_idname);continue
			elif tool_idname==F:
				if hidden_brush_tool_selected:is_active=_A
			else:continue
			if tool_idname in multires_tools and not using_multires:continue
			if tool_idname in dyntopo_tools and not using_dyntopo:continue
		if using_dyntopo and tool_idname in anti_dyntopo_tools:continue
		icon_value=ToolSelectPanelHelper._icon_value_from_icon_handle(item.icon);sub=ui_gen.send(_B)
		if tool_idname==F:sub.scale_y=1.75;sub.operator('sculpt_plus.all_brush_tool',text=' ',depress=is_active,icon_value=icon_value,emboss=_A)
		elif use_menu:sub.operator_menu_hold(G,text=item.label if show_text else'',depress=is_active,menu='WM_MT_toolsystem_submenu',icon_value=icon_value).name=item.idname
		else:sub.operator(G,text=item.label if show_text else'',depress=is_active,icon_value=icon_value).name=item.idname
	ui_gen.send(_C)
timer=time()
def draw_toolbar(self,context):
	A='color_toolbar_panel_emboss_bottom'
	if context.mode!='SCULPT'or _D not in context.workspace:VIEW3D_PT_tools_active.draw_cls(self.layout,context);return
	use_legacy_sculpt=_D not in context.workspace;prefs=context.preferences;ui_scale=prefs.system.ui_scale;sculpt_plus_prefs=get_prefs(context)
	if sculpt_plus_prefs is _C:VIEW3D_PT_tools_active.draw_cls(self.layout,context);return
	if context.region.width<=96*ui_scale or use_legacy_sculpt:self.layout.operator('sculpt_plus.expand_toolbar',text='',icon='RIGHTARROW',emboss=_B);draw_cls(VIEW3D_PT_tools_active,self.layout,context,spacing=0.1);return
	layout=self.layout;'\n    global timer\n    if (preview := context.sculpt_object.id_data.preview) is None:\n        preview = context.sculpt_object.id_data.preview_ensure()\n        timer = time()\n    elif not preview.is_icon_custom:\n        if (time() - timer) > 1.0:\n            preview.reload()\n            timer = time()\n    layout.box().template_icon(preview.icon_id, scale=10)\n    ';space_type=context.space_data.type;tool_active=VIEW3D_PT_tools_active._tool_active_from_context(context,space_type);tool_active_id:str=getattr(tool_active,_F,_C);tool_active_type,tool_active_id=tool_active_id.split('.');tool_active_id=tool_active_id.replace(' ','_').upper();layout=self.layout
	if sculpt_plus_prefs.toolbar_position=='LEFT':
		factor=1.0-(context.region.width-96*ui_scale/2)/context.region.width;row=layout.split(align=_B,factor=factor);col_1=row.column(align=_B)
		if tool_active:col_2=row.column(align=_B)
	else:
		factor=(context.region.width-96*ui_scale/2)/context.region.width;row=layout.split(align=_B,factor=factor)
		if tool_active:col_2=row.column(align=_B)
		col_1=row.column(align=_B)
	reg=context.region;view_scroll_y=abs(reg.view2d.region_to_view(0,reg.height)[1]);line_height_px=20*ui_scale;offset_factor_y=view_scroll_y/line_height_px;sep=col_1.column(align=_A);sep.label(text='',icon='BLANK1');sep.scale_y=offset_factor_y*1.0333;toolbar=col_1.column(align=_A);draw_cls(VIEW3D_PT_tools_active,toolbar,context,spacing=1.0)
	if tool_active is _C:return
	ui_props=Props.UI(context);color_scale=0.19;color_bot_scale=0.2;panel_tool=col_2.column(align=_A);col=panel_tool.row(align=_A);col.scale_y=color_scale;col.prop(ui_props,'color_toolbar_panel_tool',text='')
	if tool_active_type==_E:draw_brush_settings_tabs(panel_tool,context)
	else:draw_tool_settings(panel_tool,context,tool_active,tool_active_id)
	col=panel_tool.row(align=_A);col.scale_y=color_bot_scale;col.enabled=_B;col.prop(ui_props,A,text='');col_2.separator();panel_maskfacesets=col_2.column(align=_A);col=panel_maskfacesets.row(align=_A);col.scale_y=color_scale;col.prop(ui_props,'color_toolbar_panel_maskfacesets',text='');draw_mask_facesets(panel_maskfacesets,context);col=panel_maskfacesets.row(align=_A);col.scale_y=color_bot_scale;col.enabled=_B;col.prop(ui_props,A,text='');col_2.separator();panel_sculptmesh=col_2.column(align=_A);col=panel_sculptmesh.row(align=_A);col.scale_y=color_scale;col.prop(ui_props,'color_toolbar_panel_sculptmesh',text='');draw_sculpt_sections(panel_sculptmesh,context);col=panel_sculptmesh.row(align=_A);col.scale_y=color_bot_scale;col.enabled=_B;col.prop(ui_props,A,text='')
def register():set_cls_attribute(VIEW3D_PT_tools_active,'draw',draw_toolbar)