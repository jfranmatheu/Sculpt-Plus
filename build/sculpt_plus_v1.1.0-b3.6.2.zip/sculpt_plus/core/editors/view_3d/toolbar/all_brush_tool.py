import bpy
from bpy.types import WorkSpaceTool,Operator
from .override_tools import accept_brush_tools
from .override_region import toolbar_hidden_brush_tools
from sculpt_plus.props import Props,CM_UIContext
from sculpt_plus.globals import G
class SCULPTPLUS_OT_all_brush_tool(Operator):
	bl_idname:str='sculpt_plus.all_brush_tool';bl_label:str='All Brush Tool';bl_description:str='All for One. One for All.'
	def execute(J,context):
		H='SCULPT';D='FINISHED';C='CANCELLED';A=context
		if A.mode!=H:return{C}
		if A.space_data is None:return{C}
		E=Props.Workspace(A)
		if E is None or A.workspace!=E:return{C}
		B=Props.SculptTool.get_stored()
		if B=='NONE':return{C}
		if B in accept_brush_tools:bpy.ops.wm.tool_set_by_id(name='builtin_brush.'+B.replace('_',' ').title());return{D}
		if B not in toolbar_hidden_brush_tools:return{D}
		bpy.ops.wm.tool_set_by_id(name='builtin_brush.Draw')
		with CM_UIContext(A,mode=H,item_type='BRUSH'):
			if(I:=G.bm_data.active_brush):I.set_active(A)
			elif(F:=G.bm_data.active_category):
				if F.items.count>0:F.items[0].set_active(A)
		Props.SculptTool.update_stored(A);return{D}