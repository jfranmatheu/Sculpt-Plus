import bpy
from bpy.types import WorkSpaceTool,Operator
from .override_tools import accept_brush_tools
from .override_region import toolbar_hidden_brush_tools
from sculpt_plus.props import Props,CM_UIContext,SculptTool
from sculpt_plus.globals import G
class SCULPTPLUS_OT_all_brush_tool(Operator):
	bl_idname:str='sculpt_plus.all_brush_tool';bl_label:str='All Brush Tool';bl_description:str='All for One. One for All.'
	def execute(L,context):
		J='builtin_brush.';I='SCULPT';D='FINISHED';C='CANCELLED';A=context
		if A.mode!=I:return{C}
		if A.space_data is None:return{C}
		E=Props.Workspace(A)
		if E is None or A.workspace!=E:return{C}
		B=SculptTool.get_stored()
		if B=='NONE':return{C}
		F=B.replace(' ','_').upper()
		if F in accept_brush_tools:bpy.ops.wm.tool_set_by_id(name=J+B);return{D}
		if F not in toolbar_hidden_brush_tools:return{D}
		bpy.ops.wm.tool_set_by_id(name=J+B)
		with CM_UIContext(A,mode=I,item_type='BRUSH'):
			if(K:=G.bm_data.active_brush):K.set_active(A)
			elif(H:=G.bm_data.active_category):
				if H.items.count>0:H.items[0].set_active(A)
		return{D}