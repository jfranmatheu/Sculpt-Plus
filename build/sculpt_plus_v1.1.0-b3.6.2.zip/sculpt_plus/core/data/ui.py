_F='MASK_FILTERS'
_E='Section'
_D='COLOR'
_C=True
_B=None
_A=False
from bpy.types import PropertyGroup
from bpy.props import PointerProperty,BoolProperty,EnumProperty,FloatVectorProperty
from sculpt_plus.previews import Previews
toolbar_brush_sections_items=[]
def get_toolbar_brush_sections_items(self,context):
	C='NONE';A=context.tool_settings.sculpt.brush
	if A is _B:return[(C,C,'')]
	B=[('BRUSH_SETTINGS','Brush','Brush Settings','BRUSH_DATA',0),('BRUSH_SETTINGS_ADVANCED','Advanced','Advanced Brush Settings','OPTIONS',1),('BRUSH_SETTINGS_STROKE','Stroke','Brush Stroke Settings','GP_SELECT_STROKES',2),('BRUSH_SETTINGS_FALLOFF','Falloff','Brush Falloff Settings','SMOOTHCURVE',3)]
	if A.texture is not _B:B.append(('BRUSH_SETTINGS_TEXTURE','Texture','Brush Texture Settings','TEXTURE_DATA',4))
	return B
def get_toolbar_sculpt_sections_items(self,context):
	K='Quad Remesh';J='Voxel Remesh';I='MOD_MULTIRES';H='MESH_ICOSPHERE';G='DYNTOPO';E=context;D='MULTIRES';B='Multires';A='Dyntopo'
	if E.sculpt_object.use_dynamic_topology_sculpting:return(G,A,A,H,2),
	L=E.sculpt_object;C=_B
	for F in L.modifiers:
		if F.type==D:C=F;break
	if C is not _B and C.total_levels>0:return(D,B,B,I,3),
	return('VOXEL_REMESH',J,J,'FILE_VOLUME',0),('QUAD_REMESH',K,K,'MOD_REMESH',1),(G,A,A,H,2),(D,B,B,I,3)
def get_toolbar_maskfacesets_sections_items(self,context):return('MASK','Mask','Mask Options','MOD_MASK',0),('FACESETS','Face Sets','Face Sets Options',Previews.FaceSets.FACE_SETS(),1)
class SCULPTPLUS_PG_ui_toggles(PropertyGroup):show_brush_settings:BoolProperty(default=_C);show_brush_settings_advanced:BoolProperty(default=_A);show_brush_settings_stroke:BoolProperty(default=_A);show_brush_settings_falloff:BoolProperty(default=_A);show_brush_settings_texture:BoolProperty(default=_A);show_brush_settings_panel:BoolProperty(default=_C,name='Show Brush Settings');show_mask_facesets_panel:BoolProperty(default=_A,name='Show Mask/Face Sets Panel');show_sculpt_mesh_panel:BoolProperty(default=_C,name='Show Sculpt Mesh Panel');show_facesets_panel_initialize_section:BoolProperty(default=_A,name='Show Initialize FaceSets Options');show_facesets_panel_createfrom_section:BoolProperty(default=_C,name='Show Create FaceSets From Options');toolbar_brush_sections:EnumProperty(name=_E,items=get_toolbar_brush_sections_items);toolbar_maskfacesets_sections:EnumProperty(name=_E,items=get_toolbar_maskfacesets_sections_items);toolbar_sculpt_sections:EnumProperty(name=_E,items=get_toolbar_sculpt_sections_items);mask_panel_tabs:EnumProperty(name='Mask Tabs',items=(('MASK_EXPAND','Expand','Mask Expand Operators'),('MASK_EFFECTS','Generator','Mask Effect/Generator Operators'),(_F,'Filters','Mask Filter Operators'),('MASK_TO_MESH','To Mesh','Mask To Mesh Operators')),default=_F);color_toolbar_panel_tool:FloatVectorProperty(default=(226/255,29/255,106/255),size=3,subtype=_D);color_toolbar_panel_maskfacesets:FloatVectorProperty(default=(130/255,211/255,60/255),size=3,subtype=_D);color_toolbar_panel_sculptmesh:FloatVectorProperty(default=(30/255,203/255,225/255),size=3,subtype=_D);color_toolbar_panel_emboss_bottom:FloatVectorProperty(default=(0.0,0.0,0.0,1.0),size=4,subtype=_D,name='',description='')