_A=None
from gpu.types import GPUShader,GPUBatch
from gpu_extras.batch import batch_for_shader as batsh
from typing import Dict,Tuple,Any,Union
from mathutils import Vector
class ShaderType:VERTEX=0;FRAGMENT=1;GEOMETRY=2
class PrimitiveType:POINT='POINTS';LINE='LINES','LINE_STRIP','LINE_LOOP';TRIANGLE='TRI';RECT='TRI';SHAPE=TRIANGLE,RECT;IMG='TRI_FAN'
class Shader:
	sh:GPUShader;geo_type:PrimitiveType
	def __init__(A):(A.batsh):GPUBatch=_A;A.init_props()
	def set_rect(A,pos:Vector,size:Vector)->_A:A.set_coords()
	def set_custom_shape(A,pos:Vector,size:Vector,custom_shape:Tuple[Vector])->_A:A.set_coords();A.set_indices()
	def set_point(A,pos:Vector,scale:float)->_A:(A.point_scale):float=scale
	def init_props(A):' Init shader props. '
	def get_inputs(A)->Dict[str,Any]:' Get shader inputs. ';return{}
	def get_indices(A)->Union[Tuple[Tuple[int]],_A]:
		' Get shader indices. '
		if A.geo_type in{'RECT'}:return
		return _A