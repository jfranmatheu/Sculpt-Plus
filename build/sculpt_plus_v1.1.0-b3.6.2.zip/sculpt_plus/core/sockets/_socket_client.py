_A=None
from socket import socket,SocketType,AF_INET,SOCK_STREAM
import struct
class SocketClient:
	recv_format:str;recv_size:int;port:int;_instance=_A
	@classmethod
	def Singleton(A):
		if A._instance is _A:A._instance=A()
		return A._instance
	def __init__(A,port:int=0)->_A:A.socket=socket(AF_INET,SOCK_STREAM);A.port=port;A.init()
	def init(A)->_A:0
	def start(A)->_A:A.socket.connect(('localhost',A.port))
	def stop(A)->_A:
		if A.socket is not _A:A.socket.close();A.socket=_A
	def __enter__(A):A.start();return A
	def __exit__(A,exc_type,exc_val,exc_tb):A.stop()
	@property
	def recv_format(self)->str:return'i'
	@property
	def recv_size(self)->int:return struct.calcsize(self.recv_format)
	def send_data(A)->tuple:
		'\n        Receive data from client.\n\n        :param client: Client socket.\n        :return: Received data.\n        '
		if A.socket is _A:return
		A.socket.sendall(A.pack_data(A.prepare_data()))
	def pack_data(A,data:tuple)->bytes:
		'\n        Unpack received data.\n\n        :param data: Received data.\n        :return: Unpacked data.\n        '
		if not data:return _A
		return struct.pack(A.recv_format,*(data))
	def prepare_data(A)->tuple:return()