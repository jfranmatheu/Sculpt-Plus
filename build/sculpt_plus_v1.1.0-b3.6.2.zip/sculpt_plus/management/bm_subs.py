_B='SCULPT'
_A=None
from brush_manager.api import BM_SUB,bm_types
from sculpt_plus.globals import G
default_layer_brush_set_brushes='SculptDraw','Draw Sharp','Clay Strips','Blob','Inflate/Deflate','Crease','Pinch/Magnify','Grab','Elastic Deform','Scrape/Peaks'
_default_layer_brush_set_brushes=set(default_layer_brush_set_brushes)
if BM_SUB.AddonData.SAVE is _A:raise Exception("OPS! Can't Subscribe to BM events.")
def on_addon_data_init(bm_data:bm_types.AddonDataByMode)->_A:
	E='DEFAULT';C=bm_data
	if C.mode!=_B:return
	D=C.brush_cats.get(E)
	if D is _A:print('no cat');return
	A=G.hm_data.layers.get(E)
	if A is _A:print('no layer');return
	print('[Sculpt+] brush_manager data initialized... filling default hotbar layer...');F=A.link_brush;G.hm_data.layers.select(A)
	for B in D.items:
		if B.name in _default_layer_brush_set_brushes:F(B,default_layer_brush_set_brushes.index(B.name))
	G.hm_data.save()
def on_addon_data_save(bm_data:bm_types.AddonDataByMode)->_A:
	if bm_data.mode==_B:G.hm_data.save()
BM_SUB.AddonData.INIT+=on_addon_data_init
BM_SUB.AddonData.SAVE+=on_addon_data_save
def on_cats_add(new_cat:bm_types.Category)->_A:
	A=new_cat
	if isinstance(A,bm_types.BrushCat)and A.collection.owner.mode==_B:0
def on_cats_remove(cat_to_remove:bm_types.Category)->_A:
	A=cat_to_remove
	if isinstance(A,bm_types.BrushCat)and A.collection.owner.mode==_B:
		for B in A.items:on_items_remove(B)
BM_SUB.Cats.ADD+=on_cats_add
BM_SUB.Cats.REMOVE+=on_cats_remove
def on_items_add(new_item:bm_types.Item)->_A:
	A=new_item
	if isinstance(A,bm_types.BrushItem)and A.cat.collection.owner.mode==_B:(A.hotbar_layers):dict[str,str]={}
def on_items_remove(item_to_remove:bm_types.Item)->_A:
	A=item_to_remove
	if isinstance(A,bm_types.BrushItem)and A.cat.collection.owner.mode==_B:
		for (B,D) in A.hotbar_layers.items():
			if(C:=G.hm_data.layers.get(B)):C.unlink_brush(A)
BM_SUB.Items.ADD+=on_items_add
BM_SUB.Items.REMOVE+=on_items_remove