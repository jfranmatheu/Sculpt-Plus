_C='unregister'
_B='register'
_A=None
import bpy,typing,inspect,pkgutil,importlib
from pathlib import Path
import sys,importlib
__all__='init',_B,_C
if __package__=='sculpt_plus':
	blender_version=bpy.app.version;modules=_A;ordered_classes=_A
	def init(USE_DEV_ENVIRONMENT):global modules;global ordered_classes;modules=get_all_submodules(Path(__file__).parent,USE_DEV_ENVIRONMENT);ordered_classes=get_ordered_classes_to_register(modules)
	def register():
		print('[Sculpt+] Registering...');global modules;global ordered_classes
		if ordered_classes is _A:init(False);print('init modules and classes...')
		for B in ordered_classes:bpy.utils.register_class(B)
		for A in modules:
			if A.__name__==__name__:continue
			if hasattr(A,_B):A.register()
	def unregister():
		print('[Sculpt+] Unregistering...');global modules;global ordered_classes
		for B in reversed(ordered_classes):print('[Sculpt+] Unregistering class %s'%B.__name__);bpy.utils.unregister_class(B)
		return
		for A in modules:
			if A.__name__==__name__:continue
			print('[Sculpt+] Unregistering module %s'%A.__name__)
			if hasattr(A,_C):A.unregister()
		C=sys.modules
		for A in modules:
			if A==__name__:continue
			if A.__name__ in C:print('[Sculpt+] Removing module %s'%A.__name__);del sys.modules[A.__name__]
	def get_all_submodules(directory,USE_DEV_ENVIRONMENT):A=directory;return list(iter_submodules(A,A.name,USE_DEV_ENVIRONMENT))
	def iter_submodules(path,package_name,USE_DEV_ENVIRONMENT):
		for B in sorted(iter_submodule_names(path)):
			A=__package__+'.'+B
			if not USE_DEV_ENVIRONMENT and A in sys.modules:yield importlib.reload(sys.modules[A])
			else:yield importlib.import_module(A)
	def iter_submodule_names(path,root=''):
		for (E,A,B) in pkgutil.iter_modules([str(path)]):
			if B:C=path/A;D=root+A+'.';yield from iter_submodule_names(C,D)
			else:yield root+A
	def get_ordered_classes_to_register(modules):return toposort(get_register_deps_dict(modules))
	def get_register_deps_dict(modules):
		A=set(iter_my_classes(modules));D={B.bl_idname:B for B in A if hasattr(B,'bl_idname')};B={}
		for C in A:B[C]=set(iter_my_register_deps(C,A,D))
		return B
	def iter_my_register_deps(cls,my_classes,my_classes_by_idname):yield from iter_my_deps_from_annotations(cls,my_classes);yield from iter_my_deps_from_parent_id(cls,my_classes_by_idname)
	def iter_my_deps_from_annotations(cls,my_classes):
		for B in typing.get_type_hints(cls,{},{}).values():
			A=get_dependency_from_annotation(B)
			if A is not _A:
				if A in my_classes:yield A
	def get_dependency_from_annotation(value):
		B='type';A=value
		if blender_version>=(2,93):
			if isinstance(A,bpy.props._PropertyDeferred):return A.keywords.get(B)
		elif isinstance(A,tuple)and len(A)==2:
			if A[0]in(bpy.props.PointerProperty,bpy.props.CollectionProperty):return A[1][B]
		return _A
	def iter_my_deps_from_parent_id(cls,my_classes_by_idname):
		if bpy.types.Panel in cls.__bases__:
			A=getattr(cls,'bl_parent_id',_A)
			if A is not _A:
				B=my_classes_by_idname.get(A)
				if B is not _A:yield B
	def iter_my_classes(modules):
		B=get_register_base_types()
		for A in get_classes_in_modules(modules):
			if any((C in B for C in A.__bases__)):
				if not getattr(A,'is_registered',False):yield A
	def get_classes_in_modules(modules):
		A=set()
		for B in modules:
			for C in iter_classes_in_module(B):A.add(C)
		return A
	def iter_classes_in_module(module):
		for A in module.__dict__.values():
			if inspect.isclass(A):yield A
	def get_register_base_types():return set((getattr(bpy.types,A)for A in['UIList','Panel','PropertyGroup','AddonPreferences','Gizmo','GizmoGroup','Operator']))
	def toposort(deps_dict):
		A=deps_dict;C=[];D=set()
		while len(A)>0:
			E=[]
			for (B,F) in A.items():
				if len(F)==0:C.append(B);D.add(B)
				else:E.append(B)
			A={B:A[B]-D for B in E}
		return C