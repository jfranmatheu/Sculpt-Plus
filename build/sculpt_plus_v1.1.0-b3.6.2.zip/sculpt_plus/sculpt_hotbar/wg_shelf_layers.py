from time import time
from typing import Set,List,Union
import bpy
from mathutils import Vector
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
from sculpt_plus.utils.cursor import Cursor,CursorIcon
from sculpt_plus.utils.math import ease_quad_in_out
from sculpt_plus.utils.math import clamp,point_inside_circle
from sculpt_plus.sculpt_hotbar.di import DiIcoCol,DiLine,DiText,DiRct,DiCage,DiBr,get_rect_from_text,get_text_dim,DiTriCorner,DiStar,DiIcoOpGamHl,DiBMType
from .wg_base import WidgetBase
from sculpt_plus.lib.icons import Icon
from sculpt_plus.globals import G
from sculpt_plus.management.hotbar_layer import HotbarLayer
from brush_manager.api import bm_types
from brush_manager.globals import GLOBALS
class ShelfLayers(WidgetBase):
	hovered_item:HotbarLayer;selected_item:HotbarLayer
	def init(A)->None:super().init();A.enabled=False
class ShelfLayerSets(WidgetBase):
	def init(A)->None:super().init();A.enabled=False
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences):C=cv.scale;B=cv.hotbar;D=B.item_size;E=B.size.x;F=B.pos.x;G=B.get_pos_by_relative_point(Vector((0,1))).y;A.label_height=24*C;A.pad=5*C;A.margin=6*C;A.pos=Vector((F,G+A.margin));A.size=Vector((E,D.y*2+A.label_height*2+A.pad*2))
	def poll(A,_context,cv:Canvas)->bool:return cv.shelf.expand
	def draw_poll(A,context,cv:Canvas)->bool:return cv.shelf.expand and cv.shelf.size.y>A.slot_size
	def draw_pre(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):return super().draw_pre(context,cv,mouse,scale,prefs)
	def draw_post(A,_context,cv:Canvas,mouse:Vector,scale:float,_prefs:SCULPTPLUS_AddonPreferences):0