from bpy.types import Operator
from bpy.props import IntProperty
from sculpt_plus.globals import G
class SCULPTHOTBAR_OT_set_brush(Operator):
	bl_idname='sculpt_hotbar.set_brush';bl_label='Set Active Brush';bl_description='Sets the current active brush into this hotbar slot';index:IntProperty(default=-1)
	@classmethod
	def poll(B,context):A=context;return A.mode=='SCULPT'and A.tool_settings.sculpt.brush
	def execute(A,context):
		if A.index==-1:return{'CANCELLED'}
		G.hm_data.select_brush(context,A.index);return{'FINISHED'}