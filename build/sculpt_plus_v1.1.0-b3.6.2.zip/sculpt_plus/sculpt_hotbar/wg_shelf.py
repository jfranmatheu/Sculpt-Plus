_D='shelf_grid_item_info'
_C=False
_B=True
_A=None
from time import time
from typing import Set,List,Union
import bpy
from mathutils import Vector
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
from sculpt_plus.utils.cursor import Cursor,CursorIcon
from sculpt_plus.utils.math import ease_quad_in_out
from sculpt_plus.utils.math import clamp,point_inside_circle
from sculpt_plus.sculpt_hotbar.di import DiIcoCol,DiLine,DiText,DiRct,DiCage,DiBr,get_rect_from_text,get_text_dim,DiTriCorner,DiStar,DiIcoOpGamHl,DiBMType
from sculpt_plus.sculpt_hotbar.wg_view import ViewWidget
from .wg_base import WidgetBase
from sculpt_plus.lib.icons import Icon
from sculpt_plus.globals import G
from sculpt_plus.props import SculptTool
from brush_manager.api import bm_types
from brush_manager.globals import GLOBALS
SLOT_SIZE=56
HEADER_HEIGHT=32
class Shelf(WidgetBase):
	interactable:bool=_C
	def init(A)->_A:A.max_height=600;(A._expand):bool=_C;(A.margin):int=6
	@property
	def expand(self):return self._expand
	@expand.setter
	def expand(self,state:bool):
		B=self;A=B.cv;A.shelf_drag.interactable=_C
		def C():
			A.refresh();A.shelf_drag.update(A,_A);A.shelf_search.update(A,_A);A.shelf_sidebar_actions.update(A,_A);A.shelf_sidebar.update(A,_A);A.shelf_ctx_switcher.update(A,_A)
			if hasattr(A,_D):A.shelf_grid_item_info.update(A,_A)
		if state==_C:
			A.shelf_grid.selected_item=_A
			if hasattr(A,_D):A.shelf_grid_item_info.enabled=_C
			def D():B._expand=_C;A.shelf_drag.interactable=_B
			B.resize(y=0,animate=_B,anim_change_callback=C,anim_finish_callback=D)
		else:
			B._expand=_B
			if hasattr(A,_D):
				A.shelf_grid_item_info.enabled=_B;A.shelf_grid_item_info.update(A,_A)
				if GLOBALS.is_context_texture_item:A.shelf_grid_item_info.expand=_B
			def E():B._expand=_B;A.shelf_drag.interactable=_B
			H:float=B.size.y*0.2;F=SLOT_SIZE*A.scale;G=F*5.25;B.resize(y=G,animate=_B,anim_change_callback=C,anim_finish_callback=E)
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences):
		B=cv;A.margin=6*B.scale;A.size.x=B.hotbar.size.x;A.pos.x=B.hotbar.pos.x;A.max_height=int(A.cv.size.y*0.65);C:float=B.hotbar.size.y*0.2;D=B.hotbar.get_pos_by_relative_point(Vector((0.0,1.0)));A.pos=D;A.pos.y+=C;A.size=Vector((B.hotbar.size.x,0))
		if A.expand:A._expand=_C;A.expand=_B
	def on_leftmouse_press(A,ctx,cv:Canvas,m:Vector)->_A:0
	def on_hover_stay(A,m:Vector)->_A:
		if A.cv.shelf_grid.on_hover(m):A.cv.shelf_grid.on_hover_stay(m)
	def on_hover_exit(A)->_A:A.cv.shelf_grid.on_hover_exit()
	def draw_poll(A,context,cv:Canvas)->bool:return A.expand
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):B=prefs;DiRct(A.pos,A.size,B.theme_shelf);DiCage(A.pos,A.size,3.2*scale,Vector(B.theme_shelf)*0.9)
class ShelfGrid(ViewWidget):
	use_scissor:bool=_B;grid_slot_size:int=56;hovered_item:Union[bm_types.BrushItem,bm_types.TextureItem];selected_item:Union[bm_types.BrushItem,bm_types.TextureItem]
	def init(A)->_A:super().init();(A.show_all_brushes):bool=_B
	def get_max_width(B,cv:Canvas,scale)->float:A=scale;return B.size.x;C=6*A;return SLOT_SIZE*A*5.25-C*2
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences):
		if hasattr(cv,_D):F=cv.shelf_grid_item_info.expand
		else:F=_C
		D=cv.scale;E=A.cv.shelf.pos.copy();B=A.cv.shelf.size.copy();C=6*D;H=6*D;I=HEADER_HEIGHT*D;B.y-=I+H*2;E+=Vector((C,C));B-=Vector((C,C))*2.0
		if F:G=cv.shelf_grid_item_info.size.x;E.x+=G;B.x-=G
		A.pos=E.copy();A.size=B
	def on_left_click(A,ctx,cv:Canvas,m:Vector)->_A:return super().on_left_click(ctx,cv,m)
	def on_leftmouse_release(A,ctx,cv:Canvas,m:Vector)->_A:super().on_leftmouse_release(ctx,cv,m);return _C
	def on_double_click(A,context,cv:Canvas,m:Vector)->_A:
		B=context
		if A.hovered_item is _A:return
		A.hovered_item.set_active(B);SculptTool.update_stored(B);cv.shelf.expand=_C
	def on_rightmouse_press(A,context,cv:Canvas,m:Vector)->int:
		if A.hovered_item is _A:return 0
		if G.bm_data.active_category is _A:return 0
		cv.ctx_shelf_item.show(cv,m,A.hovered_item);A.hovered_item=_A;return 1
	def on_numkey(A,ctx,number:int,cv:Canvas,m:Vector)->_A:
		B=number
		if not A.selected_item:return
		C=9 if B==0 else B-1
		if(D:=G.hm_data.layers.active):D.link_brush(A.selected_item,C)
		A.selected_item=_A
	def get_data(F,cv:Canvas)->list:
		C=G.bm_data.active_category
		if C is _A or C.items.count==0:return[]
		A=C.items;B=cv.shelf_search.search
		if B:B=B.lower();D={C for C in A if C.name.lower().startswith(B)};E=[C for C in A if C not in D and B in C.name.lower()];A=list(D)+E
		else:A=list(A)
		A.sort(key=lambda item:item.fav,reverse=_B);return A
	def poll(A,_context,cv:Canvas)->bool:return cv.shelf.expand
	def draw_poll(A,context,cv:Canvas)->bool:return cv.shelf.expand and cv.shelf.size.y>A.slot_size
	def get_draw_item_args(E,context,cv:Canvas,scale:float,prefs:SCULPTPLUS_AddonPreferences)->tuple:
		C=G.bm_data.active_category
		if C is _A:return _A
		D=Vector(prefs.theme_shelf_slot);A=G.bm_data.active_item;B=G.hm_data.layers.active;return D,B.uuid if B is not _A else'',A.uuid if A else _A,G.hm_data.brushes_ids
	def draw_item(P,slot_p:Vector,slot_s:Vector,item:Union[bm_types.BrushItem,bm_types.TextureItem],is_hovered:bool,slot_color:Vector,active_hm_layer_id,act_item:str,hotbar_ids:List[str],scale:float,prefs:SCULPTPLUS_AddonPreferences):
		O='TOP_LEFT';I=hotbar_ids;H=slot_color;G=is_hovered;F=prefs;D=scale;C=item;B=slot_p;A=slot_s;J=C.uuid==act_item;K=C==P.selected_item;DiRct(B,A,H)
		if G:DiRct(B,A,Vector(F.theme_hotbar_slot)+Vector((0.2,0.2,0.2,0)))
		DiBMType(B,A,C,G)
		if GLOBALS.is_context_brush_item:
			if C.uuid in I:
				E=I.index(C.uuid)+1;E=0 if E>9 else E;DiText(B+Vector((1,3)),str(E),12,D)
				if(L:=C.hotbar_layers.get(active_hm_layer_id,_A)):
					if L=='ALT':DiTriCorner(B+Vector((0.5,A.y-0.5)),A.x/5,O,(0.9607,0.949,0.3725,0.92))
					elif L=='MAIN':DiTriCorner(B+Vector((0.5,A.y-0.5)),A.x/5,O,(1,0.212,0.48,0.92))
		if C.fav:M=16*D;N=M/2;DiStar(B+A-Vector((N,N)),M)
		if J:DiCage(B,A,2.4*D,F.theme_active_slot_color)
		if K:DiCage(B,A,2.4*D,F.theme_selected_slot_color)
		if not J and not K:DiCage(B,A,2.4*D,H*1.3)
	def draw_post(A,_context,cv:Canvas,mouse:Vector,scale:float,_prefs:SCULPTPLUS_AddonPreferences):
		if cv.active_ctx_widget:DiRct(A.pos,A.size,(0.24,0.24,0.24,0.64))
		else:super().draw_post(_context,cv,mouse,scale,_prefs)
class ShelfDragHandle(WidgetBase):
	modal_trigger:Set[str]={'LEFTMOUSE'};msg_on_enter:str='Click, or Press & Drag up/down to expand or hide'
	def init(A)->_A:A.start_mouse=Vector((0,0));A.end_mouse=Vector((0,0));A.tx_pos=Vector((0,0));A.dragging=_C
	def update(B,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:A:float=cv.hotbar.size.y*0.2;C:Vector=cv.shelf.get_pos_by_relative_point(Vector((0.5,1.0)));C.y+=A*1.5;B.pos=C;B.size=Vector((A*1.5,A*1.5))
	def on_hover(A,m:Vector)->bool:return point_inside_circle(m,A.pos,A.size.x)
	def start_drag(A,cv:Canvas,m:Vector):
		A.dragging=_B;A.start_mouse=m.copy();A.end_mouse=m.copy()
		if not cv.shelf.expand:cv.shelf.size=Vector((cv.hotbar.size.x,0))
	def on_drag(B,cv:Canvas,m:Vector):
		A=cv;B.end_mouse=m.copy();D:float=A.hotbar.size.y*0.2;C=A.hotbar.get_pos_by_relative_point(Vector((0.0,1.0)));C.y+=D
		if A.shelf.expand:
			if B.end_mouse.y>B.start_mouse.y or B.end_mouse.y<C.y:return
			E=max(0,B.end_mouse.y-C.y-D)
		else:
			if B.end_mouse.y<B.start_mouse.y or B.end_mouse.y<C.y:return
			E=min(max(B.end_mouse.y-B.start_mouse.y,0),25*A.scale)
		A.shelf.pos=C.copy();A.shelf.size=Vector((A.hotbar.size.x,E));A.shelf_drag.update(A,_A);A.shelf_search.update(A,_A);A.shelf_sidebar_actions.update(A,_A);A.shelf_sidebar.update(A,_A);A.shelf_ctx_switcher.update(A,_A)
		if hasattr(A,_D):A.shelf_grid_item_info.update(A,_A)
	def end_drag(B,cv:Canvas):
		A=cv;B.dragging=_C;B._is_on_hover=_C;E=A.scale;C=abs(B.end_mouse.y-B.start_mouse.y);D=20*E
		if(C>D or C==0)and not A.shelf.expand:A.shelf.expand=_B
		elif(C>D or C==0)and A.shelf.expand:A.shelf.expand=_C
	def modal_enter(A,ctx,cv:Canvas,m:Vector)->_A:A.start_drag(cv,m)
	def on_mousemove(A,ctx,cv:Canvas,m:Vector)->_A:
		A.on_drag(cv,m)
		if cv.shelf.expand:ctx.area.header_text_set('Drag it down, then release to hide')
		else:ctx.area.header_text_set('Drag it up, then release to expand')
	def modal_exit(A,ctx,cv:Canvas,m:Vector,cancel:bool=_C)->_A:A.end_drag(cv)
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		G='color';F='margin';C=prefs;B=scale;H=C.theme_text if A._is_on_hover else Vector(C.theme_text)*0.75;I=(0.1,0.1,0.1,0.7)if A._is_on_hover else(0.1,0.1,0.1,0.35);J=abs(A.end_mouse.y-A.start_mouse.y);D=20*B;E=A.dragging and J>D;K=': : :'if not A.dragging else' ○ 'if E else' v 'if cv.shelf.expand else' ^ ';DiText(A.pos,K,SLOT_SIZE/4,B,H,pivot=(0.5,0),draw_rect_props={F:8,G:I},id=0)
		if not cv.shelf.expand and E:DiText(A.pos-Vector((0,D)),'Release to show Brush-Shelf',12,B,(0.92,0.92,0.92,0.7),pivot=(0.5,1),draw_rect_props={F:8,G:(0.1,0.1,0.1,0.3)})
class ShelfSearch(WidgetBase):
	use_scissor:bool=_B;cursor:CursorIcon=CursorIcon.TEXT
	def init(A)->_A:A.search='';A.type_index=0;A.modal_cancel=_C;A._expand=_C
	@property
	def expand(self):return self._expand
	@expand.setter
	def expand(self,state:bool):
		A=self
		def B():A.cv.refresh()
		if state==_C:A._expand=_C;A.resize(x=A.size.y,animate=_B,anim_change_callback=B)
		else:
			def C():A._expand=_B
			A.resize(x=A.cv.shelf_grid.size.x,animate=_B,anim_change_callback=B,anim_finish_callback=C)
	def on_hover(A,m:Vector,p:Vector=_A,s:Vector=_A)->bool:return super().on_hover(m,p,s)and A.cv.shelf.expand
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		B=HEADER_HEIGHT*cv.scale;C=6*cv.scale;A.pos=cv.shelf.get_pos_by_relative_point(Vector((0,1)));A.pos.x+=C;A.pos.y-=B+C;A.size.y=B
		if A.in_modal:A.size.x=cv.shelf_grid.size.x
		else:A.size.x=B
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		B=scale
		if not cv.shelf.expand or cv.shelf.size.y<60:return
		C=A.pos.copy();D=A.size.copy()
		if A.in_modal or A.anim_pool:
			F=0.08,0.08,0.08,0.9;DiRct(C,D,F);DiCage(C,D,2.2*B,(0.2,0.5,0.9,0.8));E=C+Vector((10,D.y*0.32));G=time();G=round(G%1,2);H=min(3,int(G/0.25));I=G<0.5;J='Start Typing '+''.join(['.']*H)+('|'if I else'');DiText(E,A.search if A.search else J,16,B)
			if A.search:K=get_text_dim(A.search[:A.type_index],16,B);E+=Vector((K[0],-4*B));DiLine(E,E+Vector((0,20*B)),1.6*B,(0.1,0.1,0.1,0.7));DiLine(E,E+Vector((0,20*B)),1.3*B,(0.7,0.7,0.7,0.7))
		elif A._is_on_hover:F=0.2,0.2,0.2,0.8;DiRct(C,D,F);DiCage(C,D,2.2*B,Vector(F)*0.8);DiIcoCol(C,D,Icon.SEARCH,(0.9,0.9,0.9,0.9))
		else:DiIcoCol(C,D,Icon.SEARCH,(0.9,0.9,0.9,0.6))
	def on_left_click(A,ctx,cv:Canvas,m:Vector)->bool:return _B
	def modal_enter(A,ctx,cv:Canvas,m:Vector)->_A:A.expand=_B
	def modal_exit(A,ctx,cv:Canvas,m:Vector,cancel:bool=_C)->_A:
		A.expand=_C
		if A.modal_cancel or cancel:A.modal_cancel=_C;A.search=''
	def modal(A,ctx,evt,cv:Canvas,m:Vector)->bool:
		C='RET';B=evt
		if B.type in{'ESC',C,'RIGHTMOUSE'}:
			A.modal_cancel=_B
			if B.type!=C:A.search=''
			return _C
		if B.value!='PRESS':return _B
		if B.type=='LEFT_ARROW':A.type_index=clamp(A.type_index-1,0,len(A.search));return _B
		if B.type=='RIGHT_ARROW':A.type_index=clamp(A.type_index+1,0,len(A.search));return _B
		if B.type=='DEL':
			if len(A.search)==A.type_index:return _B
			else:A.search=A.search[:A.type_index]+A.search[A.type_index+1:]
			return _B
		if B.type=='BACK_SPACE':
			if A.type_index==0:return _B
			if len(A.search)==A.type_index:A.search=A.search[:-1]
			else:A.search=A.search[:A.type_index-1]+A.search[A.type_index:]
			A.type_index-=1;return _B
		if not B.unicode and not B.ascii:return _B
		if len(A.search)==A.type_index:A.search+=B.unicode
		else:A.search=A.search[:A.type_index]+B.unicode+A.search[A.type_index:]
		A.type_index+=1;return _B
class ShelfGridItemInfo(WidgetBase):
	def init(A)->_A:A._expand=_C;A.max_width=1;A._anim_running=_C
	@property
	def expand(self)->bool:return self._expand
	@expand.setter
	def expand(self,value:bool)->_A:
		C=value;A=self;B=A.cv
		if C==A._expand:return
		def D():A.cv.refresh();B.shelf_grid.update(B,_A)
		if C:
			A._expand=_B
			def E():A._anim_running=_C;A.update(B,_A)
			A.resize(A.max_width,animate=_B,anim_change_callback=D,anim_finish_callback=E)
		else:
			def F():A._anim_running=_C;A._expand=_C;A.update(B,_A)
			A._anim_running=_B;A.resize(0,animate=_B,anim_change_callback=D,anim_finish_callback=F)
	def poll(A,_context,cv:Canvas)->bool:return A.expand and cv.shelf.expand and A.size.y>10
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		if not A.expand and not A.anim_running():A.pos=cv.shelf_grid.pos.copy();A.size=Vector((0,cv.shelf_grid.size.y));return
		C=cv.scale;B=A.cv.shelf.pos.copy();B.x+=6*C;B.y+=6*C;A.pos=B;A.size=Vector((A.size.x,cv.shelf_grid.size.y));A.max_width=A.cv.hotbar.size.x*0.215
	def draw(D,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		I=scale;A=min(max(D.size.x/D.max_width,0),1);A=ease_quad_in_out(-0.25,1,A);H=6*I*2;E=5*I;L=D.pos.copy()
		if D._anim_running:C=Vector((D.max_width-H,D.size.y))
		else:C=D.size.copy()-Vector((H,0))
		DiRct(D.pos,C,(0.04,0.04,0.04,0.32*A));DiLine(L+Vector((C.x,0)),L+C,2.4,(0.5,0.5,0.5,0.64*A));DiLine(L+Vector((C.x,0)),L+C,1.2,(0.1,0.1,0.1,0.64*A));M=G.bm_data.active_brush;C-=Vector((H+E*2,E*2));N=get_text_dim('O',12,I)[1]+H;J=(C.y-N*2-H*2)/2
		if J>C.x:J=C.x
		F=Vector((J,J));B=D.get_pos_by_relative_point(Vector((0,1)))-Vector((0,F.x));B+=Vector((E,-E))
		if M:DiBMType(B,F,M,_C,A);K=M.name
		else:DiRct(B,F,(0.05,0.05,0.05,0.4*A));DiCage(B,F,1.5,(0.05,0.05,0.65*A));DiIcoCol(B+Vector((E,E)),F-Vector((E,E))*2,Icon.PAINT_BRUSH,(0.8,0.8,0.8,1*A));K='No Active Brush'
		B-=Vector((0,N));DiText(B,K,12,I,(0.92,0.92,0.92,A));B-=Vector((0,J+H*2))
		def P(p,s,tex,act:bool,opacity:float):DiIcoOpGamHl(p,s,Icon.TEXTURE,opacity)
		O=G.bm_data.active_texture
		if O:K=O.name;DiBMType(B,F,O,_C,A,draw_fallback=P)
		else:K='No Texture';P(B,F,_A,_C,A)
		B-=Vector((0,N));DiText(B,K,12,I,(0.92,0.92,0.92,A))