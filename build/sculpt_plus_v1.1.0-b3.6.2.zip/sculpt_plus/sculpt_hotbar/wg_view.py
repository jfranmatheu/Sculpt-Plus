_C=True
_B=False
_A=None
from math import floor,ceil
from bpy.types import Brush as BlBrush,Texture as BlTexture,ImageTexture,Image
from mathutils import Vector
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.sculpt_hotbar.di import DiLine,DiText
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
from sculpt_plus.utils.cursor import Cursor,CursorIcon
from sculpt_plus.utils.math import clamp
from .wg_base import WidgetBase
from brush_manager.api import bm_types
HEADER_HEIGHT=32
class ViewWidget(WidgetBase):
	grid_slot_size:int=64
	def init(A)->_A:A.hovered_item=_A;A.selected_item=_A;A._press_time=_A;A._press_mouse=_A;(A.scroll_axis):str='Y';(A.scroll):float=0.0;A.view_size=Vector((0,0));A.view_pos=Vector((0,0));A.slot_size=0;A.tot_scroll=0;A.scroll_visible_range=0,0;A.use_smooth_scroll=_B
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences):
		B=prefs
		if B:A.use_smooth_scroll=B.use_smooth_scroll
		C=A.get_data(A.cv)
		if not C:return
		D:float=A.grid_slot_size;E:float=A.size.x;(A.item_size):Vector=Vector((E,D))
	def get_data(A,cv:Canvas)->list:return _A
	def get_max_width(A,cv:Canvas,scale)->float:return A.grid_slot_size*scale
	def iter_slots(A,scale:float,mouse:Vector=_A,loop_callback:callable=_A)->bm_types.BrushItem or bm_types.TextureItem or _A:
		R=loop_callback;Q=mouse;P=scale;A.update(A.cv,_A);G=A.pos.copy();D=A.size.copy();H=6*P;E=A.get_data(A.cv)
		if not E:return
		B=A.grid_slot_size*P;L=max(floor(D.y/B),1);C=max(floor(D.x/B),1);S=(C-1)*H
		if B*C+S>D.x:B=int((D.x-S)/C)
		A.slot_size=B+H;T=Vector((B,B));F=0;I=0;J=_A;M=L;V=len(E);K=floor(V/C)+1;W=K*A.slot_size;A.view_size=Vector((D.x,W));A.view_pos=G.copy();A.tot_scroll=(K-M)*A.slot_size
		if K>M:
			L=K;N=floor(A.scroll/A.slot_size);X=N+M+(0 if A.scroll%A.slot_size==0 else 1);Y=N*C;Z=X*C;E=E[Y:Z];F+=N
			if A.scroll!=0:G.y+=A.scroll
		for O in E:
			if I>=C:F+=1;I=0
			if F>=L:break
			U=Vector((int(G.x+(B+H)*I),int(G.y+D.y-B*(F+1)-H*F)))
			if Q and J is _A and WidgetBase.check_hover(_A,Q,U,T):J=O
			if R:R(U,T,O,O==J)
			I+=1
		return J
	def get_slot_at_pos(A,m)->bm_types.BrushItem or bm_types.TextureItem or _A:return A.iter_slots(A.cv.scale,m)
	def on_hover_exit(A)->_A:A.hovered_item=_A
	def on_hover_stay(A,m:Vector)->_A:A.hovered_item=A.get_slot_at_pos(m)
	def on_leftmouse_release(A,ctx,cv:Canvas,m:Vector)->_A:
		if not A.hovered_item:A.selected_item=_A
		else:A.selected_item=A.hovered_item
		return _B
	def on_left_click_drag(A,ctx,cv:Canvas,m:Vector)->bool:return _C
	def modal_enter(A,ctx,cv:Canvas,m:Vector)->_A:A._prev_mouse=m.copy();A._modal_scroll=_B;A.hovered_item=_A
	def modal_exit(A,ctx,cv:Canvas,m:Vector,cancel:bool=_B)->_A:del A._prev_mouse;del A._modal_scroll;Cursor.set_icon(ctx,CursorIcon.DEFAULT)
	def modal(A,ctx,evt,cv:Canvas,m:Vector)->bool:
		D='RELEASE';C='LEFTMOUSE';B=evt
		if A._modal_scroll:
			if B.type==C and B.value==D:return _B
			if B.type=='MOUSEMOVE':E=m.y-A._prev_mouse.y;A.do_scroll(cv,E);A._prev_mouse=m
			return _C
		if B.type==C and B.value==D:A.on_leftmouse_release(ctx,cv,m);return _B
		if abs(A._prev_mouse.y-m.y)>4*cv.scale:A._modal_scroll=_C;Cursor.set_icon(ctx,CursorIcon.SCROLL_Y)
		return _C
	def do_scroll(A,cv,off_y:float,anim:bool=_B):
		D='scroll';C=off_y
		if anim:
			B=clamp(A.scroll+C,0,A.tot_scroll)
			if A.scroll==B:
				if B==A.tot_scroll or B==0:return
			def E():A.update(cv,_A)
			def F():A.update(cv,_A)
			A.anim(D,A,D,B,0.2,smooth=_C,delay=0,change_callback=E,finish_callback=F)
		else:A.scroll=clamp(A.scroll+C,0,A.tot_scroll);A.update(cv,_A)
	def on_scroll_up(A,ctx,cv:Canvas):A.do_scroll(cv,-A.grid_slot_size*cv.scale if A.use_smooth_scroll else-10*cv.scale,anim=A.use_smooth_scroll)
	def on_scroll_down(A,ctx,cv:Canvas):A.do_scroll(cv,A.grid_slot_size*cv.scale if A.use_smooth_scroll else 10*cv.scale,anim=A.use_smooth_scroll)
	def draw_item(A,slot_p,slot_s,item,is_hovered:bool,scale:float,prefs:SCULPTPLUS_AddonPreferences):0
	def draw_poll(A,context,cv:Canvas)->bool:return _C
	def get_draw_item_args(A,context,cv:Canvas,scale:float,prefs:SCULPTPLUS_AddonPreferences)->tuple:return()
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		C=prefs;B=scale;D=A.get_draw_item_args(context,cv,B,C)
		if not D:return
		def E(*E):A.draw_item(*(E),*(D),B,C)
		A.iter_slots(B,mouse,loop_callback=E)
		if A.scroll!=0:DiLine(A.get_pos_by_relative_point(Vector((0,1))),A.get_pos_by_relative_point(Vector((1,1))),3.0*B,C.theme_shelf)
	def draw_post(B,_context,cv:Canvas,mouse:Vector,scale:float,_prefs:SCULPTPLUS_AddonPreferences):
		D=scale;C=mouse
		if not B.hovered_item:return
		A:str=B.hovered_item.name
		if'.'in A:A=A.rsplit('.',1)[0]
		if'_'in A:A=A.replace('_',' ')
		DiText(C,A,14,D,(0,0,0,1.0),pivot=(0.2,-2.0),draw_rect_props={'color':(0.92,0.92,0.92,0.8),'margin':6});DiText(C,A,14,D,(0.1,0.1,0.1,1.0),pivot=(0.2,-2.0))
class VerticalViewWidget(ViewWidget):
	num_cols:int=1;item_aspect_ratio:float=1/3;interactable:bool=_C
	def init(A)->_A:super().init();(A.item_margin):int=0;A.scroll_axis='Y';(A.item_pos):list[Vector]=[];(A.visible_range):tuple[int,int]=_A;A.view_height=0;(A.data_count):int=0
	def get_view_margins_vertical(A)->tuple:' 0 -> Bottom margin;\n            1 -> Top margin; ';return 0,0
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences):
		K,E=A.size.x,A.size.y;F:int=K;B:int=int(F*A.item_aspect_ratio);A.item_size=Vector((F,B));L=A.get_data(cv);C:int=len(L);A.data_count=C
		if C==0:A.tot_scroll=0;A.item_pos=_A;A.visible_range=_A;A.view_height=0;return
		D:int=C;G:float=E/B;O:float=D-G;H:float=D*B;A.view_height=H;A.tot_scroll=H-E;I=floor(abs(A.scroll)/B);M=ceil(I+G);(A.visible_range):tuple[int,int]=(max(I,0),min(M,D)+1);N:float=A.pos.x;J:float=A.pos.y+A.size.y-B;J+=A.scroll;A.item_pos=[Vector((N,J-B*A))for A in range(C)]
	def on_left_click_drag(A,ctx,cv:Canvas,m:Vector)->bool:return A.view_height>A.size.y
	def do_scroll(A,cv,off_y:float,anim:bool=_B):
		if A.view_height>A.size.y:super().do_scroll(cv,off_y,anim)
	def draw_poll(A,context,cv:Canvas)->bool:return A.size.y>A.item_size.y
	def draw_scissor_apply(D,_p:Vector,_s:Vector):B=_p.copy();C=_s.copy();A:tuple=D.get_view_margins_vertical();C.y-=A[0]+A[1];B.y+=A[0];super().draw_scissor_apply(B,C)
	def iter_slots(A,scale:float,mouse:Vector=_A,loop_callback:callable=_A):
		E=loop_callback;D=mouse;A.update(A.cv,_A);F=D.y;G=A.item_size;B=_A;H=A.get_visible_items(A.cv)
		if not H:return _A
		J=A.item_pos[A.visible_range[0]:A.visible_range[1]];K=F>=A.pos.y and F<=A.pos.y+A.size.y
		for (C,I) in zip(H,J):
			if A._is_on_hover and K and B is _A and super().on_hover(D,I,G):B=C
			if E is not _A:E(I,G,C,C==B)
		return B
	def get_visible_items(A,cv:Canvas)->list:
		if A.visible_range is _A:return[]
		B=A.get_data(cv);C:int=len(B)
		if A.data_count!=C:A.update(cv,_A)
		if A.visible_range is _A:return[]
		return B[A.visible_range[0]:A.visible_range[1]]