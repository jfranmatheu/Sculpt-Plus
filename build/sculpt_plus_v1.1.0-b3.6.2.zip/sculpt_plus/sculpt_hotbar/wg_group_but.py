_D='toggle'
_C='COLS'
_B='ROWS'
_A=None
from math import ceil
from telnetlib import SE
from time import time
from typing import Any,Dict,List,Set,Tuple
from uuid import uuid4
from bpy import ops as OP
from mathutils import Vector
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.sculpt_hotbar.di import DiCage,DiIma,DiImaco,DiRct,DiText
from sculpt_plus.lib.icons import BrushIcon,Icon
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
from sculpt_plus.sculpt_hotbar.wg_base import WidgetBase
SLOT_SIZE=22
class ButtonGroup(WidgetBase):
	fill_by:str=_B;relative_to_bar_pos=0,1;rows:int=2;items:Tuple[str,Dict[str,Any]];align_dir:str='LEFT'
	def init(A)->_A:A.opacity=1.0;A.hovered_item=_A;A.padding=4;A.items_pos=[];A.item_size=Vector((SLOT_SIZE,SLOT_SIZE));A.item_toggle=_A
	def get_hovered_item_data(A)->Dict[str,Any]:
		if A.hovered_item is not _A:return A.items[A.hovered_item]
		return _A
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		H:int=len(A.items);A.cols=ceil(H/A.rows);B=A.padding*cv.scale;C=SLOT_SIZE*cv.scale;A.size=I=Vector((C*A.cols+int((B-1)*A.cols),C*A.rows+int((B-1)*A.rows)));'\n        bar_pos = cv.hotbar.pos\n        bar_height = cv.hotbar.size.y\n        self.pos = p = Vector((\n            bar_pos.x,\n            bar_pos.y + bar_height + pad*2\n        ))\n        ';D=cv.hotbar.get_pos_by_relative_point(Vector(A.relative_to_bar_pos))
		if A.relative_to_bar_pos[0]!=0:
			D.x-=I.x*A.relative_to_bar_pos[0]
			if A.align_dir=='RIGHT':D.x+=I.x+B+C
		J:bool=not all(A.relative_to_bar_pos);A.pos=L=Vector((D.x-B*2 if J else D.x,D.y if J else D.y+B*2));A.item_size=Vector((C,C));E=0;F=0;K:List[Vector]=[]
		for M in range(H):
			G=L.copy()
			if E!=0:G.x+=(C+B)*E
			if F!=0:G.y+=(C+B)*F
			K.append(G)
			if A.fill_by==_B:
				E+=1
				if E>=A.cols:F+=1;E=0
			elif A.fill_by==_C:
				F+=1
				if F>=A.rows:E+=1;F=0
		A.items_pos=K
	def update_items(A):
		E=A.cv;I:int=len(A.items);F=A.padding*E.scale;G=SLOT_SIZE*E.scale;B=0;C=0 if A.fill_by==_B else A.rows-1;H:List[Vector]=[]
		for J in range(I):
			D=A.pos.copy()
			if B!=0:D.x+=(G+F)*B
			if C!=0:D.y+=(G+F)*C
			H.append(D)
			if A.fill_by==_B:
				B+=1
				if B>=A.cols:C+=1;B=0
			elif A.fill_by==_C:
				C-=1
				if C<0:B+=1;C=A.rows-1
		A.items_pos=H
	def on_hover_item(A,m,p,s):return m.x>p.x and m.x<p.x+s.x and m.y>p.y and m.y<p.y+s.y
	def on_hover_stay(A,m:Vector)->_A:
		for (B,C) in enumerate(A.items_pos):
			if A.on_hover_item(m,C,A.item_size):A.hovered_item=B;return
		A.hovered_item=_A
	def on_hover_enter(A)->_A:A.on_hover_stay(A.cv.mouse)
	def on_hover_exit(A)->_A:A.hovered_item=_A
	def on_left_click(B,ctx,cv:Canvas,m:Vector)->_A:
		D='post_func_ctx';C='pre_func_ctx'
		if B.hovered_item is _A:return
		A=B.items[B.hovered_item]
		if C in A:A[C](ctx)
		A['func'](*A['args'],**A['kwargs'])
		if D in A:A[D](ctx)
		if _D in A:B.item_toggle=A
	def poll(A,context,cv:Canvas)->bool:return cv.shelf.anim_running()and not cv.shelf.expand and not cv.shelf_drag.dragging
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		M=scale;C=prefs
		if A.item_toggle:
			if not A.item_toggle[_D](context):A.item_toggle=_A
		I,N=A.pos,A.size;J=A.hovered_item;DiText(I,'.',1,M,C.theme_text);DiRct(I,N,(0.12,0.12,0.12,0.75));D=A.item_size
		for (K,(E,F)) in enumerate(zip(A.items_pos,A.items)):
			if K==J or F==A.item_toggle:B=list(C.theme_hotbar_slot if K!=J and F!=A.item_toggle else C.theme_active_slot_color);B[-1]*=A.opacity*0.75;DiRct(E,D,B)
			B=list(Vector(C.theme_hotbar_slot)*0.9);B[-1]*=A.opacity*0.5;DiCage(E,D,1.3,B);G=F['icon']
			if isinstance(G,(Icon,BrushIcon)):
				O=F.get('icon_color',_A);L=F.get('icon_scale',1.0)
				if L!=1:P=D[0]*(1.0-L);H=Vector((P,P))
				else:H=Vector((2,2))
				if K==J or O:B=list(O or C.theme_text);B[-1]*=A.opacity;DiImaco(E+H,D-H*2,G(),B)
				else:DiIma(E+H,D-H*2,G())
				if L!=1:D=A.item_size
			elif isinstance(G,str):B=list(C.theme_text);B[-1]*=A.opacity;DiText(E+D/2,G,12,M,C.theme_text,(0.5,0.5))
		B=list(Vector(C.theme_hotbar_slot)*1.1);B[-1]*=A.opacity;DiCage(I,N,1.3,B)
class MultiButtonGroup(WidgetBase):
	fill_by:str=_C;relative_to_bar_pos=0,1;rows:int=2;group_items:Tuple[Tuple[Dict[str,Any]]]=()
	def init(A)->_A:
		A.hovered_group=_A;(A.groups):List[ButtonGroup]=[]
		for B in A.group_items:C:ButtonGroup=type('ButtonGroup_'+uuid4().hex,(ButtonGroup,),{'fill_by':A.fill_by,'relative_to_bar_pos':A.relative_to_bar_pos,'rows':A.rows,'items':B});A.groups.append(C(A.cv))
		'\n        for group in self.groups:\n            group.opacity = .5\n        '
	def get_hovered_item_data(A)->Dict[str,Any]:
		if A.hovered_group:return A.hovered_group.get_hovered_item_data()
		return _A
	def update(C,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		B:Vector=_A;E:Vector=_A;F:Vector=Vector((0,0));D:Vector=Vector((10000000,10000000));G:Vector=Vector((0,0));H:Vector=Vector((0,0));I:bool=not all(C.relative_to_bar_pos)
		for (J,A) in enumerate(C.groups):
			A.update(cv,prefs)
			if B:
				if C.relative_to_bar_pos[0]==0:A.pos.x+=F.x
				elif C.relative_to_bar_pos[0]==1:A.pos.x-=F.x
				A.size.x-=J*0.36*A.padding;A.update_items()
			B=A.pos.copy();E=A.size.copy();F.x+=E.x+10*cv.scale
			if B.x<D.x:D.x=B.x
			if B.y<D.y:D.y=B.y
			if B.x>G.x:G.x=B.x
			if B.y>G.y:G.y=B.y
			if E.y>H.y:H.y=E.y
		(C.pos):Vector=D;(C.size):Vector=Vector((F.x,H.y))
		if I:
			for A in C.groups:A.pos.x-=C.size.x;A.update_items()
	def on_hover(A,m:Vector,p:Vector=_A,s:Vector=_A)->bool:
		if A.hovered_group:
			if A.hovered_group._on_hover(A.cv.hover_ctx,m):return True
		for B in A.groups:
			if B._on_hover(A.cv.hover_ctx,m):A.hovered_group=B;return True
		return False
	'\n    def on_hover_enter(self) -> None:\n        for group in self.groups:\n            group.opacity = 1.0\n\n    def on_hover_exit(self) -> None:\n        for group in self.groups:\n            group.opacity = .5\n        self.hovered_group = None\n    '
	def on_left_click(A,ctx,cv:Canvas,m:Vector)->_A:
		if A.hovered_group:A.hovered_group.on_left_click(ctx,cv,m)
	def poll(A,context,cv:Canvas)->bool:return cv.shelf.anim_running()and not cv.shelf.expand and not cv.shelf_drag.dragging
	def draw(A,*B):
		for C in A.groups:C.draw(*(B))