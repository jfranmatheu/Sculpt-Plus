_C='BRUSH'
_B=False
_A=None
from math import floor,radians,ceil
from time import time
from typing import Set,Union,List
import bpy
from bpy.types import Brush,Texture
from mathutils import Vector
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
from sculpt_plus.utils.cursor import Cursor,CursorIcon
from sculpt_plus.utils.math import clamp,point_inside_circle
from sculpt_plus.sculpt_hotbar.di import DiIma,DiImaco,DiLine,DiText,DiRct,DiCage,DiBr,get_rect_from_text,get_text_dim,DiIco,DiIcoCol,DiBMType
from .wg_base import WidgetBase
from .wg_view import VerticalViewWidget
from sculpt_plus.lib.icons import Icon
from sculpt_plus.globals import G
from .wg_but import ButtonGroup
from brush_manager.api import bm_types,BM_OPS,BM_UI
from brush_manager.globals import GLOBALS
SLOT_SIZE=80
HEADER_HEIGHT=32
class ShelfSidebar(VerticalViewWidget):
	interactable:bool=True;use_scissor:bool=True;scissor_padding:Vector=Vector((3,3));hovered_item:Union[bm_types.BrushCat,bm_types.TextureCat];item_aspect_ratio:float=1/4.0
	def init(A)->_A:super().init();(A.margin):int=10;(A._is_on_hover_view):bool=_B;(A.type):str=_C;A.item_size=_A;A.footer_height=0;A.header_height=0
	def update(B,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:A=cv;D=A.hotbar.slot_size.x*3.5;C=24*A.scale;E:int=0;F=A.shelf.get_pos_by_relative_point(Vector((0,1))).y-A.hotbar.pos.y-C-E;B.margin=10*A.scale;B.size=Vector((D,F));B.pos=A.hotbar.get_pos_by_relative_point(Vector((0,0)))-Vector((B.margin+D,-C));B.footer_height=C;B.header_height=E;super().update(A,prefs)
	@property
	def expand(self):return self.cv.shelf.expand
	def on_hover(A,m:Vector,_p:Vector=_A,_s:Vector=_A)->bool:
		if not A.expand:return _B
		A._is_on_hover_view=super().on_hover(m,A.pos,A.size)
		if super().on_hover(m,A.pos,Vector((A.size.x+A.margin+1,A.size.y+A.item_size.y))):
			if not A._is_on_hover_view and super().on_hover(m,A.get_pos_by_relative_point(Vector((0,1))),A.item_size):A.hovered_item=G.bm_data.active_category
			else:A.hovered_item=_A
			return True
		return _B
	def on_double_click(A,ctx,cv:Canvas,m:Vector)->_A:return _B
	def on_leftmouse_release(A,ctx,cv:Canvas,_m:Vector)->_A:
		if not A._is_on_hover_view:return
		if not A.hovered_item:return _B
		G.bm_data.active_category=A.hovered_item;cv.refresh(ctx)
	def on_left_click_drag(A,ctx,cv:Canvas,m:Vector)->bool:
		if not A._is_on_hover_view:return _B
		return super().on_left_click_drag(ctx,cv,m)
	def on_rightmouse_press(A,ctx,cv:Canvas,m:Vector)->int:
		if A.hovered_item is _A and A._is_on_hover_view:return 0
		if A._is_on_hover_view:B=A.hovered_item
		else:B=G.bm_data.active_category
		if B is _A:return 0
		cv.ctx_shelf_sidebar_item.show(cv,m,B);A.hovered_item=_A;return 1
	def get_data(A,_cv:Canvas)->list:return list(G.bm_data.get_cats(skip_active=_B))
	def poll(A,_context,cv:Canvas)->bool:return cv.shelf.expand and A.size.y>A.item_size.y
	def draw_item(H,slot_p,slot_s,item:Union[bm_types.BrushCat,bm_types.TextureCat],is_hovered:bool,act_item:Union[bm_types.BrushCat,bm_types.TextureCat],thumb_size:Vector,color:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		G=is_hovered;F=thumb_size;E=scale;D=item;C=slot_s;B=slot_p;DiLine(B,B+Vector((C[0],0)),2,color);A=5*E
		def I(p,s,cat,act:bool,op:float):DiIcoCol(p,s,Icon.PENCIL_CASE_1 if H.type==_C else Icon.TEXTURE_SMALL,(0.9,0.9,0.9,1.0 if act else 0.82))
		if D.uuid=='DEFAULT':DiIcoCol(B+Vector((A,A)),F,Icon.BLENDER_COLOR,(0.9098,0.49019,0.05098,0.9))
		else:DiBMType(B+Vector((A,A)),F,D,G,draw_fallback=I)
		DiText(B+Vector((A*2+F.x,C.y/2)),D.name,13,E,pivot=(0,0.5))
		if G:DiRct(B,C,(0.6,0.6,0.6,0.25))
		if D==act_item:A=3*E;DiCage(B+Vector((A,A)),C-Vector((A,A))*2,2.4*E,Vector(prefs.theme_active_slot_color))
	def get_draw_item_args(D,_context,_cv:Canvas,scale:float,prefs:SCULPTPLUS_AddonPreferences)->tuple:A=5*scale;B=D.item_size;E=Vector((B.y-A*2,B.y-A*2));C=Vector(prefs.theme_shelf);C.w*=0.5;return G.bm_data.active_category,E,C
	def draw_post(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		D=prefs;C=scale;return;E=G.bm_data.active_category;B=A.get_pos_by_relative_point(Vector((0.0,1.0)));DiRct(B,A.item_size,(0.08,0.05,0.1,0.8))
		if E is _A:DiText(B+Vector((10,10))*C,'No Active Category',14,C,(0.95,0.4,0.2,0.9));DiCage(B,A.item_size,2,Vector(D.theme_sidebar));DiLine(B,B+Vector((A.item_size.x,0)),3.0,(0.08,0.08,0.08,0.8));return
		A.draw_item(B,A.item_size,E,super().on_hover(mouse,B,A.item_size),A.get_draw_item_args(context,cv,C,D)[0],Vector(D.theme_active_slot_color),C,D);B.y-=2*C;DiLine(B,B+Vector((A.item_size.x,0)),3.0,(0.08,0.08,0.08,0.8))
		if A.hovered_item:0
		if cv.active_ctx_widget:DiRct(A.pos,A.size,(0.24,0.24,0.24,0.64))
	def draw_pre(B,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):C,D=B.pos,B.size;A=Vector(prefs.theme_shelf);A.w*=0.5;DiRct(C,D,A);DiCage(C,D,3.2*scale,A*0.9)
	def draw_over(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):0
class ShelfSidebarActions(ButtonGroup):
	def init(A)->_A:B='SCULPT';super().init();A.new_button('New',Icon.ADD_ROW,lambda ctx,cv:BM_OPS.new_category(cat_name=_A,ui_context_mode=B));A.new_button('Import',Icon.DOWNLOAD,lambda ctx,cv:BM_OPS.import_library(ui_context_mode=B),draw_poll=lambda ctx,cv:BM_UI.get_data(ctx).ui_context_item==_C)
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:B=cv.shelf_sidebar;A.pos=B.pos;A.size.x=B.size.x;A.size.y=24*cv.scale;A.pos.y-=A.size.y;super().update(cv,prefs)
	def poll(A,_context,cv:Canvas)->bool:return cv.shelf.expand