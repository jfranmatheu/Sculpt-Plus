_M='Remove'
_L='DUPLICATE'
_K='Assign Icon'
_J='Change item name'
_I='Rename'
_H='SAVE_DEFAULT'
_G='REMOVE'
_F='RESET'
_E='ASSIGN_ICON'
_D='RENAME'
_C=False
_B=True
_A=None
from .wg_base import WidgetBase
from typing import Tuple,Union
import bpy
from bpy import ops as OPS
from math import radians,cos,sin
from mathutils import Vector
from sculpt_plus.sculpt_hotbar.di import DiRct,DiText,DiCircle,DiTri,get_text_dim
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
from sculpt_plus.utils.math import rotate_point_around_point,point_inside_circle,distance_between
from brush_manager.api import bm_types,BM_OPS
from brush_manager.globals import GLOBALS
from sculpt_plus.globals import G
item_types=Union[bm_types.BrushItem,bm_types.TextureItem,bm_types.BrushCat,bm_types.TextureCat]
class CtxPie(WidgetBase):
	interactable:bool=_B;target_item:item_types
	def get_options(A,item:item_types)->Tuple[Tuple[str,str,str]]:return()
	def init(A):A.enabled=_C;(A.safety_radius):int=20*A.cv.scale;(A.radius):int=A.safety_radius*3.5;A.hovered_option=_A;'\n        super().init()\n\n        self.add_defaults(\n            {\n                "value": 0,\n                "label": "",\n                "color": "black",\n                "background_color": "white",\n                "border_color": "black",\n                "border_width": 0,\n                "border_radius": 0,\n            })\n        '
	def show(A,cv,m:Vector,item:item_types)->_A:
		A.origin=m;A.options=A.get_options(item);(A.safety_radius):int=20*A.cv.scale;(A.radius):int=A.safety_radius*(3.32*A.cv.scale)
		if not A.options:return
		E=360/len(A.options);A.options_pos=[];F:Vector=A.origin+Vector((0,A.radius))
		for (G,H) in enumerate(A.options):
			D=Vector(get_text_dim(H[1],14,cv.scale))/2.0;I=radians(E*G);B=rotate_point_around_point(A.origin,F,I);J=B-A.origin;C=J/A.radius
			if C.x!=0:B.x+=D.x*C.x
			if C.y!=0:B.y+=D.y*C.y
			A.options_pos.append(B)
		A.target_item=item;A.enabled=_B;cv.inject_ctx_widget(A)
	def on_mousemove(A,ctx,cv,m:Vector)->_A:
		if point_inside_circle(m,A.origin,A.safety_radius):A.hovered_option=_A;return
		B=tuple((distance_between(m,B)for B in A.options_pos));C:float=min(B);D:int=B.index(C);(A.hovered_option):str=A.options[D][0];cv.mouse=m;return _B
	def modal_exit(A,ctx,cv,m:Vector,cancel:bool=_C)->_A:
		if not cancel:A.on_rightmouse_release(ctx,cv,m)
		A.enabled=_C;A.target_item=_A;A.hovered_option=_A
	def on_rightmouse_release(A,ctx,cv,m:Vector)->_A:
		if point_inside_circle(m,A.origin,A.safety_radius):return
		if A.hovered_option is _A:return
		A.execute_pie_option(ctx,A.hovered_option)
	def execute_pie_option(A,ctx,option_id:str)->_A:0
	def draw(A,context,cv,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		DiCircle(A.origin,2.0,A.safety_radius,16,(0.92,0.92,0.92,0.92)if A.hovered_option else(0.9,0.3,0.2,0.92))
		for (B,C) in zip(A.options,A.options_pos):DiText(C,B[1],14,scale,(1,1,1,1),pivot=(0.5,0.5),draw_rect_props={'color':(0.12,0.12,0.12,0.95),'margin':6,'outline_color':(0.05,0.05,0.05,0.92)if A.hovered_option!=B[0]else prefs.theme_active_slot_color})
class ShelfGridItemCtxPie(CtxPie):
	def get_options(C,item:Union[bm_types.BrushItem,bm_types.TextureItem])->Tuple[Tuple[str,str,str]]:
		if GLOBALS.is_context_brush_item:A:int=G.bm_data.brush_cats.count
		else:A:int=G.bm_data.texture_cats.count
		B=(_D,_I,_J),('UNFAV','Unmark Favourite','Unmark item as favourite')if item.fav else('FAV','Mark Favourite','Mark brush as favourite'),(_E,_K,'Set custom icon to the brush')if GLOBALS.is_context_brush_item else _A,(_L,'Duplicate','Make a brush copy')if GLOBALS.is_context_brush_item else _A,(_H,'Save Default','Save default state of the brush')if GLOBALS.is_context_brush_item else _A,(_F,'Reset to Default','Reset brush to default state')if GLOBALS.is_context_brush_item else _A,(_G,_M,'Remove item from category'),('MOVE','Move','Move item to another category')if A>1 else _A;return tuple((A for A in B if A is not _A))
	def execute_pie_option(B,ctx,option_id:str)->_A:
		A=option_id;C=B.target_item.uuid
		if A==_G:
			if GLOBALS.is_context_brush_item:G.bm_data.brush_cats.active.items.remove(C)
			else:G.bm_data.texture_cats.active.items.remove(C)
			B.cv.refresh(ctx)
		elif A=='MOVE':BM_OPS.deselect_all();BM_OPS.select_item(item_uuid=C);BM_OPS.move_selected_to_category()
		elif A==_E:BM_OPS.asign_icon_to_brush(brush_uuid=C)
		elif A=='FAV':B.target_item.fav=_B
		elif A=='UNFAV':B.target_item.fav=_C
		elif A==_D:BM_OPS.rename_item(item_uuid=C)
		elif A==_H:B.target_item.save_default()
		elif A==_F:B.target_item.reset()
		elif A==_L:
			if GLOBALS.is_context_brush_item:G.bm_data.brush_cats.active.items.duplicate(C)
			else:G.bm_data.texture_cats.active.items.duplicate(C)
			B.cv.refresh(ctx)
class ShelfSidebarCatCtxPie(CtxPie):
	def get_options(A,item:Union[bm_types.BrushCat,bm_types.TextureCat])->Tuple[Tuple[str,str,str]]:B=(_D,_I,_J),(_E,_K,'Set custom icon to the category'),('SAVE','Save Brushes Defaults','Save default state for every brush')if GLOBALS.is_context_brush_item else _A,(_F,'Reset Brushes to Defaults','Reset to default state for every brush')if GLOBALS.is_context_brush_item else _A,(_G,_M,'Remove category');return tuple((A for A in B if A is not _A))
	def execute_pie_option(C,ctx,option_id:str)->_A:
		A=option_id;B:str=C.target_item.uuid
		if A==_G:
			if GLOBALS.is_context_brush_item:G.bm_data.brush_cats.remove(B)
			else:G.bm_data.texture_cats.remove(B)
		elif A==_E:BM_OPS.asign_icon_to_category(cat_uuid=B)
		elif A==_D:BM_OPS.rename_cat(cat_uuid=B)
		elif A==_H:C.target_item.save_default(compress=_B)
		elif A==_F:C.target_item.reset()