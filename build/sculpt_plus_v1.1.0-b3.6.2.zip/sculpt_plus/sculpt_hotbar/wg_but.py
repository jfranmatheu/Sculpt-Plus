_K='separator_color'
_J='text_color'
_I='outline_color'
_H='label'
_G='HOVERED'
_F='text_size'
_E=True
_D='color'
_C='icon_color'
_B='icon'
_A=None
from .wg_base import WidgetBase,Vector,Canvas,SCULPTPLUS_AddonPreferences
from sculpt_plus.lib.icons import Icon
from sculpt_plus.sculpt_hotbar.di import DiRct,DiText,DiIco,get_text_dim,DiLine,DiIcoCol,DiCage
class Button(WidgetBase):
	interactable:bool=_E
	def __init__(A,canvas:Canvas,pos:Vector=Vector((0,0)),size:Vector=Vector((0,0)),on_click_callback:callable=_A,label:str='',color:tuple=(0.1,0.1,0.1,0.8),text_color:tuple=(0.92,0.92,0.92,0.92),text_size:int=12,icon:Icon=_A,icon_color:tuple=_A,outline_color:tuple=_A)->_A:super().__init__(canvas,pos,size);A.states={0};A.style={_H:label,_D:color,_J:text_color,_F:text_size,_B:icon,_C:icon_color,_I:outline_color};A.on_click_callback=on_click_callback
	def set_state(B,state:str,remove:bool=False):
		A=state
		if A=='IDLE':A=0
		elif A==_G:A=1
		elif A=='ENABLED':A=2
		elif A=='DISABLED':A=3
		else:A=0
		if remove:
			if A in B.states:B.states.remove(A)
		else:B.states.add(A)
	def on_left_click(A,ctx,cv:Canvas,m:Vector)->_A:A.action(ctx,cv);return
	def action(A,ctx,cv:Canvas)->_A:
		if A.on_click_callback:A.on_click_callback(ctx,cv)
	def draw(B,scale:float,prefs:SCULPTPLUS_AddonPreferences)->_A:
		J=scale;A=B.style;K=B.states
		if A[_D]:DiRct(B.pos,B.size,A[_D])
		if 3 in K:DiRct(B.pos,B.size,(0.1,0.1,0.1,0.5))
		elif 2 in K:DiRct(B.pos,B.size,prefs.theme_active_slot_color)
		elif 1 in K or B._is_on_hover:DiRct(B.pos,B.size,(0.64,0.64,0.64,0.25))
		else:0
		if A[_I]:DiCage(B.pos,B.size,1.5,A[_I])
		F=Vector((5,5))*J;G:Vector=B.pos+F;C:Vector=B.size-F*2
		if A[_H]:
			H:Vector=Vector(get_text_dim(A[_H],A[_F],J))
			if A[_B]is _A:L:Vector=B.get_pos_by_relative_point(Vector((0.5,0.5)))
			else:
				E:Vector=G.copy();D:Vector=Vector((C.y,C.y))
				if A[_C]:DiIcoCol(E,D,A[_B],A[_C])
				else:DiIco(E,D,A[_B])
				G.x+=D.x+F.x*0.5;C.x-=D.x+F.x;L:Vector=G+C*Vector((0.5,0.5))
			I=A[_H]
			if H.y>C.y:A[_F]-=1
			if H.x>C.x:M:int=len(I);N=H.x/max(1,M);O=H.x-C.x;P=M-int(O/max(1,N));I=I[:P]+'...'
			DiText(L,I,A[_F],J,A[_J],pivot=(0.5,0.5))
		elif A[_B]is not _A:
			E:Vector=G;D:Vector=Vector((C.y,C.y))
			if A[_C]:DiIcoCol(E,D,A[_B],A[_C])
			elif A[_C]:DiIcoCol(E,D,A[_B],A[_C])
			else:DiIco(E,D,A[_B])
class ButtonGroup(WidgetBase):
	buttons:list[Button];hovered_button:Button
	def __init__(A,canvas:Canvas,pos:Vector=Vector((0,0)),size:Vector=Vector((0,0)),but_spacing:int=0,bg_color:tuple=(0.1,0.1,0.1,0.8),text_color:tuple=(0.92,0.92,0.92,0.92),text_size:int=12,icon_color:tuple=(0.75,0.75,0.75,0.75),outline_color:tuple=_A,separator_color:tuple=(0.5,0.5,0.5,0.5))->_A:A.style={_D:bg_color,_K:separator_color};A.button_style={_D:_A,_J:text_color,_F:text_size,_C:icon_color,_I:outline_color};A.but_spacing=but_spacing;A.buttons=[];A.hovered_button=_A;super().__init__(canvas,pos,size)
	def init(A)->_A:0
	def new_button(A,label:str='',icon:Icon=_A,on_click_callback:callable=_A,draw_poll:callable=_A)->Button:
		C=draw_poll;B=Button(A.cv,Vector((0,0)),Vector((0,0)),on_click_callback=on_click_callback,label=label,icon=icon,**A.button_style)
		if C is not _A:B.draw_poll=lambda ctx,cv:C(ctx,cv)
		A.add_button(B);return B
	def add_button(A,button:Button)->_A:A.buttons.append(button);A.update(A.cv,_A)
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		G=A.pos.copy();E=A.size.copy();F=len(A.buttons)
		if A.but_spacing==0:B=_A
		else:B=A.but_spacing*cv.scale
		if A.but_spacing==0 or not all([B.style[_B]is not _A for B in A.buttons]):
			D:float=E.x/F
			if B:D-=(F-1)*B/F
		else:D=E.y
		for (H,C) in enumerate(A.buttons):
			C.pos.x=G.x+H*D
			if B:C.pos.x+=B*H
			C.pos.y=G.y;C.size.x=D;C.size.y=E.y
	def on_left_click(A,ctx,cv:Canvas,m:Vector)->_A:
		if not A.hovered_button:return
		A.hovered_button.on_left_click(ctx,cv,m)
	def on_hover_stay(A,m:Vector)->bool:
		for B in A.buttons:
			if B.on_hover(m):
				if B!=A.hovered_button:
					if A.hovered_button:A.hovered_button.set_state(_G,remove=_E)
					A.hovered_button=B;B.set_state(_G);return _E
				return False
		if A.hovered_button:A.hovered_button.set_state(_G,remove=_E)
		A.hovered_button=_A
	def on_hover_exit(A)->_A:
		if A.hovered_button:A.hovered_button.set_state(_G,remove=_E)
		A.hovered_button=_A
		for B in A.buttons:B.on_hover_exit()
	def draw_pre(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):DiRct(A.pos,A.size,A.style[_D])
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		for B in A.buttons:
			if B.draw_poll(context,cv):B.draw(scale,prefs)
		if A.style[_K]:
			for B in A.buttons[:-1]if A.but_spacing!=0 else A.buttons:C=B.get_pos_by_relative_point(Vector((1,1)));D=B.get_pos_by_relative_point(Vector((1,0)));DiLine(C,D,1.25,A.style[_K])