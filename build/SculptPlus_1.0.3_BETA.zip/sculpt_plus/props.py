_H='SIMPLIFY'
_G='DISPLACEMENT_SMEAR'
_F='DISPLACEMENT_ERASER'
_E='DRAW_FACE_SETS'
_D='TEXTURE'
_C='BRUSH'
_B=False
_A=None
from typing import Union,List,Dict,Set,Tuple
import bpy
from bpy.types import Context,Image as BlImage,ImageTexture as BlImageTexture,Brush as BlBrush,WorkSpace
from bpy.app import timers
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.management.manager import Manager,TextureCategory,BrushCategory,Brush,Texture,HotbarManager
from sculpt_plus.management.types.fake_item import FakeViewItem_Brush,FakeViewItem_Texture
from sculpt_plus.path import SculptPlusPaths
sculpt_tool_brush_name:Dict[str,str]={'BLOB':'Blob','BOUNDARY':'Boundary','CLAY':'Clay','CLAY_STRIPS':'Clay Strips','CLAY_THUMB':'Clay Thumb','CLOTH':'Cloth','CREASE':'Crease',_E:'Draw Face Sets','DRAW_SHARP':'Draw Sharp','ELASTIC_DEFORM':'Elastic Deform','FILL':'Fill/Deepen','FLATTEN':'Flatten/Contrast','GRAB':'Grab','INFLATE':'Inflate/Deflate','LAYER':'Layer','MASK':'Mask','MULTIPLANE_SCRAPE':'Multi-plane Scrape',_F:'Multires Displacement Eraser',_G:'Multires Displacement Smear','NUDGE':'Nudge','PAINT':'Paint','PINCH':'Pinch/Magnify','POSE':'Pose','ROTATE':'Rotate','SCRAPE':'Scrape/Peaks','DRAW':'SculptDraw',_H:'Simplify','TOPOLOGY':'Slide Relax','SMOOTH':'Smooth','SNAKE_HOOK':'Snake Hook','THUMB':'Thumb'}
builtin_brush_names:Tuple[str]=tuple(sculpt_tool_brush_name.values())
builtin_brushes:Set[str]=set(builtin_brush_names)
builtin_images:Set[str]={'Render Result','Viewer Node'}
manager_exclude_brush_tools:Set[str]={'MASK',_E,_H,_F,_G}
toolbar_hidden_brush_tools:Set[str]={A for A in sculpt_tool_brush_name.keys()if A not in manager_exclude_brush_tools}
exclude_brush_names:Set[str]={sculpt_tool_brush_name[A]for A in manager_exclude_brush_tools}
filtered_builtin_brush_names=tuple((A for A in builtin_brush_names if A not in exclude_brush_names))
class SculptToolUtils:
	@staticmethod
	def select_brush_tool(ctx:Context,brush:Brush):
		B=brush;D=sculpt_tool_brush_name[B.sculpt_tool];C:str='S+ | '+D;A=bpy.data.brushes.get(C,_A)
		if A is _A:A=bpy.data.brushes.new(C,mode='SCULPT');A.sculpt_tool=B.sculpt_tool
		B.to_brush(A);ctx.tool_settings.sculpt.brush=A
' Helper to get properties paths (with typing). '
class Props:
	@staticmethod
	def get_temp_thumbnail_image()->BlImage:
		A='.sculpt_plus_thumbnail'
		if(B:=bpy.data.images.get(A,_A)):return B
		return bpy.data.image.new(A,100,100)
	@staticmethod
	def Workspace(context=_A)->WorkSpace or _A:
		D='Sculpt+';C='sculpt_plus';B=context
		for A in bpy.data.workspaces:
			if C in A:
				if not A.use_filter_by_owner and bpy.context.workspace==A:
					A.use_filter_by_owner=True
					def E():bpy.ops.wm.owner_enable('INVOKE_DEFAULT',_B,owner_id=C)
					timers.register(E,first_interval=0.1)
				return A
		B=B if B else bpy.context;F=B.window.workspace
		try:Props.Temporal(B).test_context=True
		except RuntimeError as G:print(G);return _A
		bpy.ops.workspace.append_activate(_B,idname=D,filepath=SculptPlusPaths.BLEND_WORKSPACE());A:WorkSpace=bpy.data.workspaces.get(D,_A);B.window.workspace=A
		if C not in A:A[C]=1
		B.window.workspace=F;return A
	@staticmethod
	def Canvas()->Union[Canvas,_A]:
		if not hasattr(bpy,'sculpt_hotbar'):return _A
		return bpy.sculpt_hotbar._cv_instance
	@staticmethod
	def Scene(context:Context):return context.scene.sculpt_plus
	@staticmethod
	def Temporal(context:Context):return context.window_manager.sculpt_plus
	@classmethod
	def UI(A,context:Context):return A.Temporal(context).ui
	@classmethod
	def TextureSingleton(B,context:Context)->BlImageTexture:
		C=context;A:BlImageTexture=B.Scene(C).texture
		if A is _A:A=bpy.data.textures.new('...sculpt_plus_brush_tex','IMAGE');B.Scene(C).texture=A
		return A
	@classmethod
	def TextureImageSingleton(B,context:Context,use_sequence:bool=_B)->BlImage:
		G='...sculpt_plus_brush_tex_image';E=use_sequence;C=context;D:BlImageTexture=B.TextureSingleton(C);A:BlImage=B.Scene(C).image
		if A is _A:A:BlImage=bpy.data.images.new(G,1024,1024)
		if D.image!=A:D.image=A
		return A
		if E:A:BlImage=B.Scene(C).image_seq
		else:A:BlImage=B.Scene(C).image
		if A is _A:
			F=G
			if E:F+='_seq'
			A=bpy.data.images.new(F,1024,1024)
		if E:A.source='SEQUENCE'
		if D.image!=A:D.image=A
		return A
	@staticmethod
	def BrushManager()->'Manager':return Manager.get()
	@staticmethod
	def BrushManagerExists()->bool:return Manager._instance is not _A
	@classmethod
	def BrushManagerDestroy(A)->_A:
		if A.BrushManagerExists():del Manager._instance;Manager._instance=_A
	@classmethod
	def UpdateBrushProp(B,brush_id:str,attr:str,value)->_A:
		D=value;C=brush_id
		if C is _A:A=B.GetHotbarSelectedBrush()
		else:A=B.GetBrush(C)
		print(f"Update brush {A.name} attr {attr} value {D}");A.update_attr(attr,D)
	@classmethod
	def GetAllBrushCats(A)->List[BrushCategory]:return A.BrushManager().brush_cats.values()
	@classmethod
	def GetBrushCat(A,cat_idname:Union[str,int])->BrushCategory:return A.BrushManager().get_brush_cat(cat_idname)
	@classmethod
	def ActiveBrushCat(A)->BrushCategory:return A.BrushManager().active_brush_cat
	@classmethod
	def ActiveBrushCatIndex(B)->int:
		A=B.ActiveBrushCat()
		if A is _A:return-1
		return A.index
	@classmethod
	def GetActiveBrushCatBrushes(B)->List[Brush]:
		A=B.ActiveBrushCat()
		if A is _A:return[]
		return A.items
	@classmethod
	def BrushCatsCount(A)->int:return A.BrushManager().brush_cats_count
	@classmethod
	def TextureCatsCount(A)->int:return A.BrushManager().texture_cats_count
	@classmethod
	def NewCat(A,cat_type:str,cat_name:str=_A)->_A:
		D='Untitled Cat ';C=cat_type;B=cat_name
		if C==_C:return A.BrushManager().new_brush_cat(D+str(A.BrushCatsCount())if B is _A else B)
		elif C==_D:return A.BrushManager().new_texture_cat(D+str(A.TextureCatsCount())if B is _A else B)
	@classmethod
	def RemoveActiveCat(A,cat_type:str)->_A:
		C=cat_type
		if C==_C:B=A.ActiveBrushCat();return A.BrushManager().remove_brush_cat(B)
		elif C==_D:B=A.ActiveTextureCat();return A.BrushManager().remove_texture_cat(B)
	' Textures. '
	@classmethod
	def GetAllTextureCats(A)->List[TextureCategory]:return A.BrushManager().texture_cats.values()
	@classmethod
	def GetTextureCat(A,cat_idname:Union[str,int],ensure_create:bool=_B)->TextureCategory:
		B=cat_idname;C=A.BrushManager().get_texture_cat(B)
		if C is _A and ensure_create:return A.BrushManager().new_texture_cat(cat_id=B)
		return C
	@classmethod
	def ActiveTextureCat(A)->TextureCategory:return A.BrushManager().active_texture_cat
	@classmethod
	def ActiveTextureCatIndex(B)->int:
		A=B.ActiveTextureCat()
		if A is _A:return-1
		return A.index
	@classmethod
	def GetActiveTextureCatBrushes(B)->List[Texture]:
		A=B.ActiveTextureCat()
		if A is _A:return[]
		return A.items
	@classmethod
	def GetActiveCat(A,ctx_type:str)->Union[BrushCategory,TextureCategory,_A]:
		B=ctx_type
		if B==_C:return A.ActiveBrushCat()
		elif B==_D:return A.ActiveTextureCat()
		return _A
	@classmethod
	def SetActiveCat(C,ctx_type:str,cat:Union[BrushCategory,TextureCategory,_A])->_A:
		B=ctx_type;A=cat
		if A is _A:return
		if B==_C:Props.BrushManager().active_brush_cat=A
		elif B==_D:Props.BrushManager().active_texture_cat=A
	@classmethod
	def GetAllCats(C,ctx_type:str,skip_active:bool=_B)->Union[List[Union[BrushCategory,TextureCategory]],_A]:
		B=ctx_type
		if B==_C:A=Props.GetAllBrushCats()
		elif B==_D:A=Props.GetAllTextureCats()
		if skip_active:D=C.GetActiveCat(B);A=[B for B in A if B!=D]
		return A
	@classmethod
	def GetActiveCatItems(B,ctx_type:str)->Union[List[Union[Brush,Texture]],_A]:
		A=B.GetActiveCat(ctx_type)
		if A is not _A:return A.items
		return _A
	@classmethod
	def GetActiveCatItemIds(B,ctx_type:str)->List[str]:
		A=B.GetActiveCat(ctx_type)
		if A is not _A:return A.item_ids
		return _A
	' Get brush/texture item. '
	@classmethod
	def GetBrush(A,brush_id:str)->Brush:return A.BrushManager().get_brush(brush_id)
	@classmethod
	def GetTexture(A,texture_id:str)->Texture:return A.BrushManager().get_texture(texture_id)
	@classmethod
	def GetActiveBrush(A)->Brush:return A.GetBrush(A.BrushManager().active_brush)
	@classmethod
	def GetActiveTexture(A)->Texture:return A.GetTexture(A.BrushManager().active_texture)
	@classmethod
	def SetActiveBrush(A,brush:Union[Brush,str])->Brush:A.BrushManager().active_brush=brush
	' Hotbar. '
	@classmethod
	def Hotbar(A)->HotbarManager:return A.BrushManager().hotbar
	@classmethod
	def GetHotbarSelectedId(A)->Union[str,_A]:return A.Hotbar().selected
	@classmethod
	def GetHotbarSelectedIndex(A)->int:
		B:str=A.GetHotbarSelectedId()
		if B is _A:return-1
		return A.GetHotbarBrushIds().index(B)
	@classmethod
	def GetHotbarBrushIds(A)->List[str]:return A.Hotbar().brushes
	@classmethod
	def GetHotbarSelectedBrush(A)->Union[Brush,_A]:
		B:str=A.GetHotbarSelectedId()
		if B is _A:return _A
		return A.GetBrush(B)
	@classmethod
	def GetHotbarBrushAtIndex(B,brush_index:int)->Brush:
		A=brush_index
		if A<0 or A>9:return _A
		C=B.GetHotbarBrushIds()
		if not C:return _A
		D:str=C[A]
		if D is _A:return _A
		return B.GetBrush(D)
	@classmethod
	def SetHotbarBrush(B,slot_index:int,brush:Union[str,Brush])->_A:A=brush;C:str=A if isinstance(A,str)else A.id;B.Hotbar().brushes[slot_index]=C
	@classmethod
	def SwitchHotbarBrushIndices(D,index_A:int,index_B:int)->_A:C=index_B;B=index_A;A:HotbarManager=D.Hotbar();A.brushes[B],A.brushes[C]=A.brushes[C],A.brushes[B]
	@classmethod
	def SelectBrush(B,ctx:Context,brush:Union[str,Brush])->_A:
		C=ctx;A=brush
		if isinstance(A,str):A=B.GetBrush(A)
		if A is _A:return
		B.SetActiveBrush(A.id);SculptToolUtils.select_brush_tool(C,A)
		if A.texture_id is not _A:
			if(D:=B.GetTexture(A.texture_id)):D.to_brush(C);print(D.name,D.image.filepath_raw)
		E=B.UI(C);E.toolbar_brush_sections='BRUSH_SETTINGS'
	@classmethod
	def SetHotbarSelected(A,ctx:Context,selected:Union[int,str,Brush])->_A:A.Hotbar().selected=selected;B=A.GetHotbarSelectedBrush();A.SelectBrush(ctx,B)
	@classmethod
	def ToggleHotbarAlt(A):A.Hotbar().toggle_alt()
class FakeItemContextManager:
	items:List[Union[FakeViewItem_Brush,FakeViewItem_Texture]]
	def __init__(A,mode:str='w'):from .path import SculptPlusPaths as B;(A.items):List[Union[FakeViewItem_Brush,FakeViewItem_Texture]]=[];(A.mode):str=mode;A.json_filepath=B.APP__TEMP('fake_items.json')
	def __enter__(A):
		if A.mode=='r':
			import json
			with open(A.json_filepath,'r')as B:C:dict=json.load(B);A.deserialize_data(C)
		return A
	def deserialize_data(A,items_data:dict)->_A:0
	def __exit__(A,exc_type,exc_val,exc_tb):
		if A.mode=='w':
			with open(A.json_filepath,mode='w')as B:0
	def add_item(A,item:Union[FakeViewItem_Brush,FakeViewItem_Texture])->_A:A.items.append(item)
class CM_FakeItem_Brush(FakeItemContextManager):
	items:List[FakeViewItem_Brush]
	def deserialize_data(A,items_data:dict)->_A:
		for (B,C) in items_data.items():A.brush(B,C)
	def brush(B,name:str,id:str='')->FakeViewItem_Brush:
		A=FakeViewItem_Brush(name);B.add_item(A)
		if id:A.id=id
		return A
	def brush_from_datablock(B,bl_brush:BlBrush,generate_thumbnail:bool=True)->FakeViewItem_Brush:A=FakeViewItem_Brush.from_bl_brush(bl_brush,generate_thumbnail=generate_thumbnail);B.add_item(A);return A
class CM_FakeViewItem_Texture(FakeItemContextManager):items:List[FakeViewItem_Texture]