from ._socket_server import SocketServer
class PBarServer(SocketServer):
	progress:float;on_progress_update:callable
	def init(A):A.on_progress_update=None;A.progress=0
	def set_update_callback(A,callback:callable):A.on_progress_update=callback
	def process_data(A,_progress:int)->str:
		B=_progress;C:float=B/100.0;A.progress=round(C,2)
		if B>=100:A.progress=1;D='FINISHED'
		else:D='CONTINUE'
		if A.on_progress_update:A.on_progress_update(C)
		return D