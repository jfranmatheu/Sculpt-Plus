'\nCode executed from the PsdConverter object.\nPsdConverter is called from operators.pu in management after importing assets...\nwhen finding assets with PSD format, it will call some subprocess to convert all texture images to PNG\nas PSD is not really nice supported because sequence source instead of file and behaves strangely.\n'
import bpy
from bpy.types import Image as BlImage
import numpy as np,sys
from sculpt_plus.path import SculptPlusPaths
tex_items={A[32:]:A[:32]for A in sys.argv[sys.argv.index('--')+1:]}
tex_names=set(tex_items.keys())
def convert_to_jpg(image:BlImage,output:str):" Blender BUG. Doing it this way doesn't work as expected as image size is greater LOL.\n    image.pack()\n    image.file_format = 'JPEG'\n    image.filepath_raw = str(image_path.parent / (image_path.stem + '.jpg'))\n    image.save()\n    ";A=image;C=np.empty(len(A.pixels),dtype=np.float32);A.pixels.foreach_get(C);B=bpy.data.images.new(A.name+'.png',*A.size,alpha=True);B.pixels.foreach_set(C);B.file_format='PNG';B.save(filepath=output,quality=80)
for image in bpy.data.images:
	if image.name not in tex_names:continue
	convert_to_jpg(image,SculptPlusPaths.DATA_TEXTURE_IMAGES(tex_items[image.name]+'.png'))