_E='Thumbnail'
_D='PNG'
_C=True
_B=False
_A=None
from typing import List,Union,Tuple,Dict
import numpy as np
from pathlib import Path
from uuid import uuid4
from shutil import copyfile,move as movefile
from os.path import basename,splitext,exists,isfile
from PIL import Image as PILImage
import bpy
from bpy.types import Image as BlImage
from gpu.types import Buffer,GPUTexture
import imbuf
from bpy.path import abspath
from sculpt_plus.utils import gpu as gpu_utils
from sculpt_plus.path import SculptPlusPaths,ThumbnailPaths
from sculpt_plus.sculpt_hotbar.di import DiImaOpGamHl
from sculpt_plus.utils.toast import Notify
from sculpt_plus.utils.gpu import gputex_from_image_file
thumb_image_size=100,100
thumb_px_size=40000
cache_tex:Dict[str,GPUTexture]=dict()
cache_thumbnail:Dict[str,GPUTexture]=dict()
class Image:
	bl_type='IMAGE';_bl_attributes='filepath_raw','source','use_half_precision';pixels:np.ndarray;filepath:str;source:str;use_half_precision:bool;id:str;use_optimize:bool;px_size:int;image_size:Tuple[int,int];is_valid:bool;file_format:str;extension:str
	def __init__(A,input_image:Union[BlImage,str],tex_id:str=_A,optimize=_B):
		" We'll be using the idname here to get the optimized image. ";D=optimize;C=tex_id;B=input_image;(A.id):str=C if C else uuid4().hex;(A.pixels):np.ndarray=_A;A.use_optimize=D
		if isinstance(B,BlImage):A.name=B.name;A.from_image(B);(A.filepath):str=B.filepath_from_user()
		else:(A.filepath):str=B
		if D:A.image_size=thumb_image_size;A.px_size=thumb_px_size
		else:A.image_size=_A;A.px_size=_A
		if A.filepath:(A.extension):str=Path(A.filepath).suffix;A.file_format=A.extension[1:].upper()
		else:A.extension=_A;A.file_format=_A
	def from_image(B,input_image:BlImage):
		for A in Image._bl_attributes:setattr(B,A,getattr(input_image,A))
	def save_to_addon_data(A,move:bool=_B):
		if A.use_optimize:return
		C=Path(A.filepath)
		if not C.exists()or not C.is_file():print('ERROR! Image file does not exist! -> ',A.filepath);return
		D=Path(A.filepath).suffix;A.extension=D;E=A.filepath;B:str=SculptPlusPaths.DATA_TEXTURE_IMAGES(A.id+D)
		if move:movefile(E,B)
		else:copyfile(E,B)
		A.filepath=B
	def to_image(A,to_image:BlImage)->BlImage or _A:
		E='Invalid Image';B=to_image
		if A.use_optimize:return
		print('Is about to copy pixels from Image to BlImage',A,B)
		if B is _A:print('WARN! Invalid image in texture image destination');return
		C=A.get_bl_image()
		if A.image_size is _A:'\n            if self.source == \'SEQUENCE\':\n                # first time.\n                for key in Image._bl_attributes:\n                    setattr(from_image, key, getattr(self, key))\n                from_image.filepath = self.filepath_raw\n                # from_image.reload()\n                print("Image is dirty:", from_image.is_dirty)\n                print("Image has data:", from_image.has_data)\n                print("Image is float:", from_image.is_float)\n                if not from_image.has_data or not from_image.is_float:\n                    from_image.update()\n            ';A.image_size=tuple(C.size);A.px_size=A.image_size[0]*A.image_size[1]*4
		if A.px_size==0:print(f"WARN! Image '{C.name}' with invalid pixel size {len(B.pixels)}/{A.px_size} (given/expected)");Notify.WARNING('Invalid Source Image',f"Can't find any pixel data from {C.name}:\n- Invalid size: {A.image_size[0]}x{A.image_size[1]} px.\n- Image Source: {str(A.source)}.\n- Image Path: {A.filepath_raw}.");return
		if A.source=='SEQUENCE':return C
		if B.size[0]!=A.image_size[0]or B.size[1]!=A.image_size[1]:B.scale(*A.image_size);print('Scaling image...')
		if A.px_size!=len(B.pixels):print(f"WARN! Image '{C.name}' with invalid pixel size {len(B.pixels)}/{A.px_size} (given/expected)");Notify.WARNING(E,f"{C.name} with invalid pixel size:\n- Given {len(B.pixels)} pixel size.\n- Expected {A.px_size} pixel size.");return
		if C.pixels is _A or len(C.pixels)==0:print(f"WARN! Image '{B.name}' has no pixel data! Requires a pixel size of",A.px_size);Notify.WARNING(E,f"{B.name} has no pixel data, requires:\n- Pixel size of {len(A.px_size)}.\n- Image size of {A.image_size[0]}x{A.image_size[1]} px.");return
		D=np.empty(A.px_size,dtype=np.float32);C.pixels.foreach_get(D);B.pixels.foreach_set(D);del D;del C;print('Nice image pixels are given!');return B
	def get_bl_image(B,paste_attributes:bool=_B,ensure_float_buffer:bool=_B)->BlImage:
		if(A:=bpy.data.images.get('.'+B.id,_A)):return A
		A=bpy.data.images.load(B.filepath_raw,check_existing=_B);A.name='.'+B.id
		if paste_attributes:B.paste_bl_attributes(A)
		if ensure_float_buffer and A.is_float:A.update()
		return A
	def paste_bl_attributes(B,bl_image:BlImage)->_A:
		' In another world will be to_image. lol. '
		for A in Image._bl_attributes:setattr(bl_image,A,getattr(B,A))
	def load_image(A,input_image:Union[BlImage,str]):
		' Load the image. ';K='.thumb_image';B=input_image
		if not B:print('WARN! Thumbnail::load_image : BlImage or image filepath is null');return _A
		if A.use_optimize:
			type=A.id_type;id=A.id
			if type=='BRUSH':C:Path=ThumbnailPaths.BRUSH(id)
			elif type=='CAT_BRUSH':C:Path=ThumbnailPaths.BRUSH_CAT(id)
			elif type=='TEXTURE':C:Path=ThumbnailPaths.TEXTURE(id)
			elif type=='CAT_TEXTURE':C:Path=ThumbnailPaths.TEXTURE_CAT(id)
			else:print('WARN! Thumbnail::load_image : What ID type is this?',A.id,A.filepath);return _A
			C=str(C);B=bpy.data.images.load(str(B),check_existing=_C)
		if not B.pixels:
			if A.use_optimize:bpy.data.images.remove(B)
			return _A
		if isinstance(B,BlImage):
			D:str=B.filepath_from_user()
			if A.use_optimize:
				'\n                import imbuf\n                img = imbuf.load(filepath)\n                if img.size.x <= 128 and img.size.y <= 128:\n                    optimized = True\n                else:\n                    optimized = False\n                img.free()\n                ';"\n                import imbuf\n                img = imbuf.load(filepath)\n                img.resize(thumb_image_size, method='BILINEAR')\n                imbuf.write(img, filepath=out_filepath)\n                img.free()\n                ";H:BlImage=B.copy();H.scale(*(thumb_image_size));E=bpy.data.images.get(K,_A)
				if E is _A:E=bpy.data.images.new(K,*(thumb_image_size));E.file_format=_D
				G=E.copy();I=gpu_utils.get_nparray_from_image(H);G.pixels.foreach_set(I);G.filepath_raw=C;G.save();bpy.data.images.remove(H);bpy.data.images.remove(G);A.pixels=I;"\n                from PIL import Image as PilImage\n                with PilImage.open(thumb_image.filepath_from_user()) as pil_img:\n                    pil_img = pil_img.resize(thumb_image_size, PilImage.Resampling.BILINEAR)\n                    pil_img.save(out_filepath, format='PNG')\n                ";bpy.data.images.remove(E)
			else:A.image_size=list(B.size);(A.pixels):np.ndarray=gpu_utils.get_nparray_from_image(B)
			del B
		elif isinstance(B,(str,Path)):
			D:Path=Path(B)if isinstance(B,str)else B
			if not D.exists()or not D.is_file():print('WARN! Thumbnail::load_image : image not found at',D);return _A
			from PIL import Image as J
			with J.open(D)as F:
				if A.use_optimize:F=F.resize(thumb_image_size,J.Resampling.NEAREST);F.save(C,format=_D)
				else:A.image_size=list(F.size)
				(A.pixels):np.ndarray=np.asarray(F).flatten()
		else:print('WARN! Thumbnail::load_image : Input image type is invalid (should be BlImage or str)')
		if A.use_optimize:A.filepath=C
		else:A.filepath=D
	def get_gputex(A):
		if A.use_optimize:B:GPUTexture=cache_thumbnail.get(A.id,_A)
		else:return;B:GPUTexture=cache_tex.get(A.id,_A)
		if B is not _A:return B
		if A.pixels is _A:
			if A.filepath:print('[Sculpt+] Loading image data from filepath...',A.filepath);B,C=gputex_from_image_file(A.filepath,A.image_size,A.id,get_pixels=_C);A.pixels=C
			return _A
		if len(A.pixels)!=A.px_size:print(f"WARN! Image '{A.id}' at path '{A.filepath}' with invalid pixel size {len(A.pixels)}/{A.px_size}");return _A
		D:Buffer=Buffer('FLOAT',A.px_size,A.pixels);B:GPUTexture=GPUTexture(A.image_size,layers=0,is_cubemap=_B,format='RGBA16F'if A.file_format in{_D}else'RGB16F',data=D)
		if A.use_optimize:cache_thumbnail[A.id]=B
		else:cache_tex[A.id]=B
		return B
	def __del__(A):
		if A.id in cache_tex:del cache_tex[A.id]
		if A.id in cache_thumbnail:del cache_thumbnail[A.id]
		del A.id;del A.pixels;del A.filepath
class Thumbnail(Image):
	is_valid:bool;id_type:str;format:str
	@classmethod
	def empty(A,item)->_E:return A(_A,item.id,item.bl_type)
	@classmethod
	def from_fake_item(C,fake_item,type:str)->_E:
		A=fake_item;B:Thumbnail=C(_A,A.id,type);B.filepath=A.icon_filepath;B.pixels=A.icon_pixels
		if A.id in gpu_utils.cache_tex:gpu_utils.cache_tex.pop(A.id)
		if A.icon:cache_thumbnail[B.id]=A.icon
		return B
	def __init__(A,image_path:Union[BlImage,str],idname:str,_type:str)->_A:A.id_type=_type;(A._status):str='NONE';super().__init__(image_path,idname,optimize=_C)
	@property
	def is_valid(self)->bool:A=self;return A.pixels is not _A and A.filepath and A.status=='READY'
	@property
	def is_loading(self)->bool:return self.status=='LOADING'
	@property
	def is_unsupported(self)->bool:return self.status=='UNSUPPORTED'
	@property
	def status(self)->str:return self._status
	@status.setter
	def status(self,status:str):self._status=status
	def set_filepath(A,filepath:str,lazy_generate:bool=_C)->_A:
		A.filepath=filepath;(A.extension):str=Path(A.filepath).suffix;A.file_format=A.extension[1:].upper();A.status='NONE'
		if A.id in cache_thumbnail:B=cache_thumbnail.pop(A.id);del B
		if lazy_generate:from ..thumbnailer import Thumbnailer as C;C.push(A)
	def draw(A,p,s,act:bool=_B,opacity:float=1)->_A:
		if not A.use_optimize:print('WARN! Only optimized images are supported for drawing!');return
		DiImaOpGamHl(p,s,A.get_gputex(),_op=opacity,_hl=int(act))