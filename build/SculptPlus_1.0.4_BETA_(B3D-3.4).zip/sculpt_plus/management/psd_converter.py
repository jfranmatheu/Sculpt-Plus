_A=None
from .types import Texture
from sculpt_plus.path import ScriptPaths,SculptPlusPaths
from bpy.app import binary_path
from time import time,sleep
from math import floor
from threading import Thread
from multiprocessing import cpu_count
import subprocess
MAX_PROCESSES=max(1,cpu_count()/2)
MAX_ITEMS_PER_PROCESS=20
class PsdConverter:
	def __init__(A,blendlib_path:str,texture_items:list[Texture])->_A:
		B=texture_items;A.texture_items=B;A.processes=[];A.process_items={}
		for K in B:K.thumbnail.status='LOADING'
		F:int=len(B);C:int=min(MAX_PROCESSES,max(1,int(F/MAX_ITEMS_PER_PROCESS)));D=F/C;G=[floor(D)]*C
		if D%1!=0:G[0]+=int(D%1*C)
		E=0
		for H in G:I=B[E:E+H];J=subprocess.Popen([binary_path,blendlib_path,'--background','--python',ScriptPaths.CONVERT_TEXTURES_TO_PNG_FROM_BLENDLIB,'--',*([A.id+A.name for A in I])],stdin=_A,stdout=_A,stderr=subprocess.DEVNULL,shell=False);A.processes.append(J);A.process_items[J.pid]=I;E+=H
		A.process_controller=Thread(target=A.controller_loop,name='PsdConverterController');A.process_controller.start()
	def controller_loop(A):
		print('Starting PsdConverter...')
		while 1:
			if all([B.poll()is not _A for B in A.processes]):break
			sleep(0.1)
		A.finish();del A.texture_items;del A.processes;del A.process_items;print('Stopping PsdConverter...')
	def finish(D):
		C='PNG';B='.png'
		for A in D.texture_items:print('\t- PSD Texture converted to PNG: ',A.name);A.image_user=_A;A.image.filepath_raw=SculptPlusPaths.DATA_TEXTURE_IMAGES(A.id+B);A.image.source='FILE';A.image.extension=B;A.image.file_format=C;A.thumbnail.file_format=C;A.image_user=_A;A.thumbnail.set_filepath(A.image.filepath_raw,lazy_generate=True)