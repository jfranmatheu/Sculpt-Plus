_B='brush_capabilities'
_A=None
import bpy
from bpy.types import Brush,Property,BrushCapabilitiesSculpt,BrushCapabilities,BrushCurvesSculptSettings,BrushTextureSlot,Image,Texture
from bpy.app import timers
from bpy.types import PointerProperty,CollectionProperty
from bpy.app.handlers import load_post,persistent
import functools
from time import time
from typing import Union,Dict,Tuple,List,Set
from sculpt_plus.props import Props
sculpt_brush_types:Tuple[Tuple[type,str]]=((Brush,''),(BrushCapabilitiesSculpt,_B),(BrushCapabilities,_B),(BrushCurvesSculptSettings,'curves_sculpt_settings'),(BrushTextureSlot,'texture_slot'))
exclude_prop_types=PointerProperty,CollectionProperty
props_being_updated:Dict[str,float]={}
def update_brush_after_time(brush:Brush,attr:str)->Union[float,_A]:
	B=brush;A=attr
	if B is _A:return _A
	if time()-props_being_updated[A]<2.0:return 0.5
	print(f"Brush {B.name} attribute {A} is updated");Props.UpdateBrushProp(B['id'],A,getattr(B,A));del props_being_updated[A];return _A
def on_update_brush_prop(brush:Brush,attr:str,data_path:str)->_A:
	B=brush;A=attr
	if bpy.context.mode!='SCULPT':return
	if'id'not in B:return
	props_being_updated[A]=time()
	if A in props_being_updated:return
	timers.register(functools.partial(update_brush_after_time,B,A),first_interval=1.0)
subscribers=[]
def new_owner():A=object();subscribers.append(A);return A
def subscribe_rna(_type,key:str='',data_path:str=_A):bpy.msgbus.subscribe_rna(key=(_type,key),owner=new_owner(),args=(bpy.context.tool_settings.sculpt,key),notify=lambda _sculpt,_key:on_update_brush_prop(_sculpt.brush,_key,data_path),options={'PERSISTENT'})
@persistent
def on_load_post(dummy):
	A=Brush;C=''
	for (D,B) in A.bl_rna.properties.items():
		if isinstance(B,exclude_prop_types)and not isinstance(B.fixed_type,(Texture,Image)):continue
		subscribe_rna(A,D,C)
def register():load_post.append(on_load_post)
def unregister():
	if on_load_post in load_post:load_post.remove(on_load_post)
	if subscribers:
		for A in subscribers:bpy.msgbus.clear_by_owner(A)
		subscribers.clear()