_C=True
_B=False
_A=None
from math import floor,radians,ceil
from time import time
from typing import Set,Union,List
import bpy
from bpy.types import Brush,Texture
from mathutils import Vector
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
from sculpt_plus.utils.cursor import Cursor,CursorIcon
from sculpt_plus.utils.math import clamp,point_inside_circle
from sculpt_plus.sculpt_hotbar.di import DiIma,DiImaco,DiLine,DiText,DiRct,DiCage,DiBr,get_rect_from_text,get_text_dim,DiIco,DiIcoCol
from .wg_base import WidgetBase
from .wg_view import VerticalViewWidget
from sculpt_plus.lib.icons import Icon
from sculpt_plus.props import Props,BrushCategory,TextureCategory
from .wg_but import ButtonGroup
SLOT_SIZE=80
HEADER_HEIGHT=32
class ShelfSidebar(VerticalViewWidget):
	interactable:bool=_C;use_scissor:bool=_C;scissor_padding:Vector=Vector((3,3));hovered_item:Union[BrushCategory,TextureCategory];item_aspect_ratio:float=1/3.5
	def init(A)->_A:super().init();(A.margin):int=10;(A._is_on_hover_view):bool=_B;(A.type):str='BRUSH';A.item_size=_A;A.footer_height=0;A.header_height=0
	def update(B,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:A=cv;C=A.hotbar.slot_size.x*3*A.scale;D=24*A.scale;E:int=int(C*B.item_aspect_ratio);F=A.shelf.get_pos_by_relative_point(Vector((0,1))).y-A.hotbar.pos.y-D-E;B.margin=10*A.scale;B.size=Vector((C,F));B.pos=A.hotbar.get_pos_by_relative_point(Vector((0,0)))-Vector((B.margin+C,-D));B.footer_height=D;B.header_height=E;super().update(A,prefs)
	@property
	def expand(self):return self.cv.shelf.expand
	def on_hover(A,m:Vector,_p:Vector=_A,_s:Vector=_A)->bool:
		if not A.expand:return _B
		A._is_on_hover_view=super().on_hover(m,A.pos,A.size)
		if super().on_hover(m,A.pos,Vector((A.size.x+A.margin+1,A.size.y+A.item_size.y))):
			if not A._is_on_hover_view and super().on_hover(m,A.get_pos_by_relative_point(Vector((0,1))),A.item_size):A.hovered_item=Props.GetActiveCat(A.type)
			else:A.hovered_item=_A
			return _C
		return _B
	def on_leftmouse_release(A,ctx,cv:Canvas,_m:Vector)->_A:
		if not A._is_on_hover_view:return
		if not A.hovered_item:return _B
		Props.SetActiveCat(A.type,A.hovered_item);cv.refresh(ctx)
	def on_left_click_drag(A,ctx,cv:Canvas,m:Vector)->bool:
		if not A._is_on_hover_view:return _B
		return super().on_left_click_drag(ctx,cv,m)
	def on_rightmouse_press(A,ctx,cv:Canvas,m:Vector)->int:
		if A.hovered_item is _A and A._is_on_hover_view:return 0
		if A._is_on_hover_view:B=A.hovered_item
		else:B=Props.GetActiveCat(A.type)
		if B is _A:return 0
		cv.ctx_shelf_sidebar_item.show(cv,m,B);A.hovered_item=_A;return 1
	def get_data(A,_cv:Canvas)->list:return Props.GetAllCats(A.type,skip_active=_C)
	def poll(A,_context,cv:Canvas)->bool:return cv.shelf.expand and A.size.y>A.item_size.y
	def draw_item(G,slot_p,slot_s,item:Union[BrushCategory,TextureCategory],is_hovered:bool,thumb_size:Vector,color:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		F=scale;E=thumb_size;D=item;C=slot_s;B=slot_p;DiCage(B,C,2,color);A=5*F
		def H(p,s,act:bool):DiIcoCol(p,s,Icon.PENCIL_CASE_1 if G.type=='BRUSH'else Icon.TEXTURE_SMALL,(0.9,0.9,0.9,0.92))
		D.draw_preview(B+Vector((A,A)),E,fallback=H);DiText(B+Vector((A*2+E.x,C.y/2+A)),D.name,13,F,pivot=(0,0));DiText(B+Vector((A*2+E.x,A*2)),'( '+str(D.items_count)+' )',11,F,(0.5,0.5,0.5,0.5),pivot=(0,0))
		if is_hovered:DiRct(B,C,(0.6,0.6,0.6,0.25))
	def get_draw_item_args(D,_context,_cv:Canvas,scale:float,prefs:SCULPTPLUS_AddonPreferences)->tuple:A=5*scale;B=D.item_size;E=Vector((B.y-A*2,B.y-A*2));C=Vector(prefs.theme_shelf);C.w*=0.5;return E,C
	def draw_post(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		D=prefs;C=scale;E=Props.GetActiveCat(A.type);B=A.get_pos_by_relative_point(Vector((0.0,1.0)));DiText(B,'.',1,1);DiRct(B,A.item_size,(0.08,0.05,0.1,0.8))
		if E is _A:DiText(B+Vector((10,10))*C,'No Active Category',14,C,(0.95,0.4,0.2,0.9));DiCage(B,A.item_size,2,Vector(D.theme_sidebar));DiLine(B,B+Vector((A.item_size.x,0)),3.0,(0.08,0.08,0.08,0.8));return
		A.draw_item(B,A.item_size,E,super().on_hover(mouse,B,A.item_size),A.get_draw_item_args(context,cv,C,D)[0],Vector(D.theme_active_slot_color),C,D);B.y-=2*C;DiLine(B,B+Vector((A.item_size.x,0)),3.0,(0.08,0.08,0.08,0.8))
		if A.hovered_item:0
		if cv.active_ctx_widget:DiRct(A.pos,A.size,(0.24,0.24,0.24,0.64))
	'\n    def draw(self, context, cv: Canvas, mouse: Vector, scale: float, prefs: SCULPTPLUS_AddonPreferences):\n        bg_color = Vector(prefs.theme_shelf)\n        bg_color.w *= 0.5\n        isize = Vector((self.size.x, self.size.x / 3))\n        pad = 3 * scale\n        isize_thumb = Vector((isize.y - pad*2, isize.y - pad*2))\n        ioff = Vector((0, self.size.x / 3))\n        p = self.get_pos_by_relative_point(Vector((0.0, 1.0))) - ioff\n\n        # apply scroll\n        brushes = context.scene.sculpt_hotbar.get_brushes()\n        br_count: int = len(brushes)\n        max_cats_in_view: int = floor(self.size.y / isize.y)\n        max_scroll: int = br_count * isize.y - max_cats_in_view * isize.y\n        if self.scroll > max_scroll:\n            self.scroll = max_scroll\n        p += Vector((0, self.scroll))\n        for idx, br in enumerate(brushes):\n            if p.y > self.size.y:\n                p -= ioff\n                continue\n\n            #DiRct(p, isize, bg_color)\n            DiCage(p, isize, 2, bg_color)\n            DiBr(p+Vector((pad, pad)), isize_thumb, br)\n            DiText(p+Vector((pad + isize_thumb.x, isize.y/2+pad)), "Brush Category %i" % idx, 12, scale, pivot=(0, 0))\n            DiText(p+Vector((pad + isize_thumb.x, pad*3)), br.name, 11, scale, (.5, .5, .5, .5), pivot=(0, 0))\n            p -= ioff\n\n            if p.y < (-isize.y+5):\n                break\n    '
	def draw_pre(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):C,D=A.pos,A.size;DiText(C,'.',1,1);B=Vector(prefs.theme_shelf);B.w*=0.5;DiRct(A.pos,A.size,B);DiCage(A.pos,A.size,3.2*scale,B*0.9)
	def draw_over(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):0
class ShelfSidebarActions(ButtonGroup):
	def init(A)->_A:B='INVOKE_DEFAULT';super().init();A.new_button('New',Icon.ADD_ROW,lambda ctx,cv:bpy.ops.sculpt_plus.new_cat(B,cat_type=cv.shelf_sidebar.type));A.new_button('Import',Icon.DOWNLOAD,lambda ctx,cv:bpy.ops.sculpt_plus.import_create_cat(B,cat_type=cv.shelf_sidebar.type));'\n        self.new_button(\n            None,\n            Icon.MOVE_UP_ROW,\n            # lambda ctx, cv: Props.MoveCat(cv.shelf_sidebar.type, direction=1),\n        )\n        self.new_button(\n            None,\n            Icon.MOVE_DOWN_ROW,\n            # lambda ctx, cv: Props.MoveCat(cv.shelf_sidebar.type, direction=-1),\n        )\n        self.new_button(\n            None,\n            Icon.REMOVE_TRASH,\n            lambda ctx, cv: Props.RemoveActiveCat(cv.shelf_sidebar.type),\n        )\n        '
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:B=cv.shelf_sidebar;A.pos=B.pos;A.size.x=B.size.x;A.size.y=24*cv.scale;A.pos.y-=A.size.y;super().update(cv,prefs)
	def poll(A,_context,cv:Canvas)->bool:return cv.shelf.expand