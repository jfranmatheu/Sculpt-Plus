_D='Context'
_C='sculpt_plus'
_B='Sculpt+'
_A=None
from bpy.types import Operator,Context,Event,WorkSpace
from sculpt_plus.props import Props
from sculpt_plus.path import SculptPlusPaths
import bpy
from bpy.app import timers
from bl_ui.space_view3d import VIEW3D_HT_header
from sculpt_plus.previews import Previews
from sculpt_plus.core.data.cy_structs import CyBlStruct
class SCULPTPLUS_OT_setup_workspace(Operator):
	bl_idname='sculpt_plus.setup_workspace';bl_label='Setup Sculpt+ Workspace';bl_description="Add the 'Sculpt+' Workspace to your .blend and set it up to start using Sculpt+ in your project!"
	def invoke(C,context:'Context',event:'Event'):
		B=context;A=Props().Workspace(B)
		if A is not _A:return{'CANCELLED'}
		try:Props.Temporal(B).test_context=True
		except RuntimeError as D:print(D);return _A
		bpy.ops.workspace.append_activate(False,idname=_B,filepath=SculptPlusPaths.BLEND_WORKSPACE());A:WorkSpace=bpy.data.workspaces.get(_B,_A);B.window.workspace=A
		if _C not in A:A[_C]=1
		A['first_time']=1;A.use_filter_by_owner=True;B.window_manager.modal_handler_add(C);return{'RUNNING_MODAL'}
	def modal(A,context:'Context',event:'Event'):bpy.ops.wm.owner_enable('INVOKE_DEFAULT',False,owner_id=_C);return{'FINISHED'}
def draw_workspace_setup_op(self,context):
	A=context
	if A.mode=='SCULPT'and Props.Workspace(A)is _A:self.layout.operator(SCULPTPLUS_OT_setup_workspace.bl_idname,text=_B,icon_value=Previews.Main.BRUSH())
def register():VIEW3D_HT_header.append(draw_workspace_setup_op)
def unregister():VIEW3D_HT_header.remove(draw_workspace_setup_op)