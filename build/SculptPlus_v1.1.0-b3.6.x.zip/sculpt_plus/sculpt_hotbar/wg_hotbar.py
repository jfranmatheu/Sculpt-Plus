_C=True
_B=False
_A=None
from copy import copy,deepcopy
from math import dist
from time import time
from typing import Set,Tuple
from bpy import ops as OP
from mathutils import Vector
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.sculpt_hotbar.di import DiArrowSolid,DiBr,DiCage,DiRct,DiText,DiBMType
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
from sculpt_plus.utils.math import clamp,ease_quad_in_out,ease_quadratic_out,lerp_smooth,map_value
from sculpt_plus.sculpt_hotbar.wg_base import WidgetBase
from sculpt_plus.props import bm_types,Props,SculptTool
from sculpt_plus.globals import G
SLOT_SIZE=48
class Hotbar(WidgetBase):
	def init(A)->_A:A.slot_pos=[Vector((0,0))]*10;A.slot_on_hover=_A;A.slot_size=Vector((0,0));A._press_time=0;A._press_slot=Vector((0,0));A._moving_slot=_B;A.item_size=Vector((SLOT_SIZE,SLOT_SIZE));A.tooltip_data_pool=[];A.curr_tooltip_data=_A;A.curr_tooltip_opacity=0.8;A.prev_tooltip_opacity=0.8;A.prev_tooltip_data=_A;A.tooltip_timer=0.0;A.use_secondary=_B;A.brush_rolling=_B;A.brush_scrolling_m=Vector((0,0))
	@property
	def moving_slot(self)->bool:return self._moving_slot
	@moving_slot.setter
	def moving_slot(self,value:bool)->_A:
		B=value;A=self;A._moving_slot=B
		if B:
			def C():
				if not A.moving_slot:return _A
				A.cv.refresh();return 0.1
			A.time_fun(C)
	def update(C,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		D=prefs;B=cv;E:Vector=B.pos;A=SLOT_SIZE*B.scale;C.size=H=Vector((A*10,A));I=B.size.x;C.pos=J=Vector((E.x+I/2-H.x/2,E.y+D.margin_bottom*B.scale));C.slot_size=K=Vector((A,A));L=Vector((K.x,0));F=Vector((D.padding*B.scale,D.padding*B.scale));A-=F.x*2;C.item_size=Vector((A,A))
		for G in range(10):C.slot_pos[G]=J+L*G+F
	def on_hover_enter(A)->_A:A.on_hover_stay(A.cv.mouse)
	def on_hover_stay(A,m:Vector)->_A or int:
		if A.moving_slot:return
		if A.brush_rolling:
			if dist(A.brush_scrolling_m,m)<5*A.cv.scale:return
			A.brush_rolling=_B;A.brush_scrolling_m=Vector((0,0))
		B=A.get_slot_at_pos(m)
		if B is not _A and B!=A.slot_on_hover:A.slot_on_hover=B;return 1
	def on_hover_exit(A)->_A:
		A.brush_rolling=_B
		if A.moving_slot:return
		A.slot_on_hover=_A
	def on_hover_slot(A,m,p,s):return m.x>p.x and m.x<p.x+s.x and m.y>p.y and m.y<p.y+s.y
	def get_slot_at_pos(A,m)->int or _A:
		for (B,C) in enumerate(A.slot_pos):
			if A.on_hover_slot(m,C,A.slot_size):return B
		return _A
	def get_brush_item_on_hover(A)->bm_types.BrushItem|_A:return A.get_brush_item_at_index(A.slot_on_hover)
	def get_brush_item_at_index(B,index:int)->bm_types.BrushItem|_A:
		A=index
		if A<0 or A>9:return _A
		if G.hm_data.layers.active is _A:return _A
		return G.hm_data.brushes[A]
	def update_active_brush(B,ctx)->_A:
		A=B.get_brush_item_on_hover()
		if A is _A:return
		OP.wm.tool_set_by_id(name='builtin_brush.'+A.type.replace('_',' ').title());A.set_active(ctx);SculptTool.update_stored(ctx)
	def on_leftmouse_press(A,ctx,cv:Canvas,m:Vector)->bool:
		B=cv
		if B.shelf.expand:
			' Assign brush from grid to hotbar. '
			if B.shelf_grid.selected_item is not _A:
				if(C:=G.hm_data.layers.active):C.link_brush(B.shelf_grid.selected_item,A.slot_on_hover)
				B.shelf_grid.selected_item=_A
			return
		if A.slot_on_hover is _A or A.get_brush_item_on_hover()is _A:A.moving_slot=_B;A._press_time=_A;return
		A.update_active_brush(ctx)
		def D(reg):
			if not A._press_time:return _A
			if time()-A._press_time>=0.3:A.moving_slot=_C;A._press_slot=A.slot_pos[A.slot_on_hover].copy();B.refresh();return _A
			return 0.05
		A._press_time=time();A.time_fun(D,0.15,ctx.region)
	def on_left_click_drag(A,ctx,cv:Canvas,m:Vector)->_A:
		if A.slot_on_hover is _A:return
		if not A._press_time:return
		if time()-A._press_time>=0.32:A.moving_slot=_C;A._press_time=_A;A._press_slot=A.slot_pos[A.slot_on_hover].copy();A._press_off_x=m.x-A._press_slot.x;A._press_clamp_x=A.slot_pos[0].x,A.slot_pos[9].x;return _C
		A._press_time=_A
	def on_scroll_up(A,ctx,cv:Canvas):
		if A.slot_on_hover is _A:return
		if not A.brush_rolling:A.brush_scrolling_m=cv.mouse.copy();A.brush_rolling=_C
		A.slot_on_hover+=1
		if A.slot_on_hover>=len(A.slot_pos):A.slot_on_hover=0
		A.update_active_brush(ctx)
	def on_scroll_down(A,ctx,cv:Canvas):
		if A.slot_on_hover is _A:return
		if not A.brush_rolling:A.brush_scrolling_m=cv.mouse.copy();A.brush_rolling=_C
		A.slot_on_hover-=1
		if A.slot_on_hover<0:A.slot_on_hover=len(A.slot_pos)-1
		A.update_active_brush(ctx)
	def modal(A,ctx,evt,cv:Canvas,m:Vector)->bool:
		C=evt
		if A.brush_rolling:A.brush_rolling=_B;return _B
		if C.type in{'ESC','RIGHTMOUSE'}:A.slot_pos[A.slot_on_hover].x=A._press_slot.x;A.moving_slot=_B;return _B
		if C.type=='LEFTMOUSE'and C.value=='RELEASE':D=A.slot_pos[A.slot_on_hover].copy();A.slot_pos[A.slot_on_hover]=Vector((-100,-100));F=A.slot_pos[A.get_slot_at_pos(m)];A.slot_pos[A.slot_on_hover]=D;D.x=A._press_slot.x;A.moving_slot=_B;return _B
		if C.type=='MOUSEMOVE':
			E=A.slot_on_hover;B=A.get_slot_at_pos(m)
			if E==B or B==_A:return _C
			G.hm_data.layers.active.switch(E,B);A._press_slot.x=A.slot_pos[B].x;A.slot_on_hover=B
		return _C
	def on_leftmouse_release(A,ctx,cv:Canvas,m:Vector)->_A:A.moving_slot=_B;A._press_time=_A
	def modal_exit(A,ctx,cv:Canvas,m:Vector,cancel:bool=_B)->_A:A.moving_slot=_B;A._press_time=_A
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		O='uuid';F=scale;D=prefs;I=A.pos.copy();J=A.size.copy();P=cv.shelf.expand and A.slot_on_hover is not _A and cv.shelf_grid.selected_item;N=D.padding;G=Vector((N,N));E=A.item_size;Q=10;DiRct(I,J,D.theme_hotbar);DiCage(I,J,3.2*F,Vector(D.theme_hotbar)*0.9);DiCage(I,J,2.0*F,Vector(D.theme_hotbar_slot)*0.9);K=context.tool_settings.sculpt.brush;R=K[O]if K and O in K else _A
		if A.moving_slot:L=A.slot_pos.copy();L[A.slot_on_hover]=_A
		else:L=A.slot_pos
		for (B,C) in enumerate(L):
			if C is _A:continue
			if B==A.slot_on_hover:DiRct(C,E,Vector(D.theme_hotbar_slot)+Vector((0.1,0.1,0.1,0)))
			else:DiRct(C,E,D.theme_hotbar_slot)
			if B<Q:
				H=A.get_brush_item_at_index(B)
				if H:
					if not cv.shelf.expand and R==H.uuid or P and B==A.slot_on_hover:DiRct(C+Vector((0,E.y)),Vector((E.x,int(5*F))),D.theme_active_slot_color)
					DiBMType(C+G,E-G*2,H,B==A.slot_on_hover)
			M=str(B+1);DiText(C+G,'0'if B==9 else M,10,F,D.theme_text)
		if A.moving_slot:B=A.slot_on_hover;H=A.get_brush_item_at_index(B);C=A._press_slot;DiRct(C,E,(0.4,0.4,0.4,0.25));DiBMType(C+G,E-G*2,H,_C);DiCage(C,E,2.2*F,(0.2,0.6,1.0,1.0));M=str(B+1);DiText(C+G,'0'if B==9 else M,10,F,D.theme_text)
		if cv.active_ctx_widget:DiRct(A.pos,A.size,(0.24,0.24,0.24,0.64))
	def draw_over(A,ctx,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		I='margin';H='color';F=scale
		if A.moving_slot:
			B=A.slot_on_hover;C=time();C=abs((round(C%1,2)-0.5)*2);D=Vector(prefs.theme_active_slot_color);D.w=C;G=A.slot_pos[B];E=Vector((A.slot_size.x-1,A.slot_size.y/2))
			if B<9:DiArrowSolid(G+E,E*0.2,D,_B)
			if B>0:J=Vector((0,A.slot_size.y/2));DiArrowSolid(G+J,E*0.2,D,_C)
			return
		A.update_tooltip(ctx,cv)
		if A.prev_tooltip_data and A.prev_tooltip_opacity>0:DiText(*A.prev_tooltip_data,12,F,(0.9,0.9,0.9,A.prev_tooltip_opacity),pivot=(0.5,-1),draw_rect_props={H:(0.1,0.1,0.1,A.prev_tooltip_opacity),I:4})
		if A.curr_tooltip_data and A.curr_tooltip_opacity>0:DiText(*A.curr_tooltip_data,12,F,(0.9,0.9,0.9,A.curr_tooltip_opacity),pivot=(0.5,-1),draw_rect_props={H:(0.1,0.1,0.1,A.curr_tooltip_opacity),I:4})
	def update_tooltip(A,ctx,cv:Canvas)->Tuple[str,Vector]:
		I='label';B=cv;C=_A;E=_A;G=0.5,1;J=B.shelf.expand and A.slot_on_hover is not _A and B.shelf_grid.selected_item
		if J:
			D=A.slot_on_hover;F=A.get_brush_item_at_index(D);H=B.shelf_grid.selected_item
			if not F:K=0 if D==9 else D+1;C='Sets [ %s ] in Slot %i'%(H.name,K)
			else:C='Replace [ %s ] with [ %s ]'%(F.name,H.name)
			E=A.get_pos_by_relative_point(Vector(G))
		elif A.slot_on_hover is not _A:
			D=A.slot_on_hover;L=A.slot_pos[D];F=A.get_brush_item_at_index(D)
			if F:C=F.name
			else:C='[ Empty Slot ] - %i'%(0 if D==9 else D+1)
			E=L+Vector((A.slot_size.x/2.0,A.slot_size.y))
		elif B.group_t and B.group_t.get_hovered_item_data():C=B.group_t.get_hovered_item_data()[I];E=B.group_t.get_pos_by_relative_point(Vector(G))
		elif B.group_mask and B.group_mask.get_hovered_item_data():C=B.group_mask.get_hovered_item_data()[I];E=B.group_mask.hovered_group.get_pos_by_relative_point(Vector(G))
		if not C:A.curr_tooltip_data=_A;A.prev_tooltip_data=_A;return _A
		A.curr_tooltip_data=E,C;" NEW FADE IN OUT\n        if self.curr_tooltip_data is None:\n            self.curr_tooltip_opacity = 0.8\n            self.curr_tooltip_data = pos, text\n            self.prev_tooltip_opacity = 0.0\n\n        elif self.curr_tooltip_data[1] != text:\n            ''' New tooltip. Reset states. '''\n            self.prev_tooltip_data = deepcopy(self.curr_tooltip_data)\n            self.prev_tooltip_opacity = 0.8\n\n            self.curr_tooltip_opacity = 0.0\n            self.curr_tooltip_data = pos, text\n\n            self.tooltip_timer = time()\n\n        elif self.prev_tooltip_opacity != 0:\n            ''' Anim opacity. '''\n            passed_time = time() - self.tooltip_timer\n            if passed_time > 0.2:\n                self.curr_tooltip_opacity = 0.8\n                self.prev_tooltip_opacity = 0.0\n                self.prev_tooltip_data = None\n                return\n\n            self.curr_tooltip_opacity = map_value(passed_time, (0.0, 0.2), (0.0, 0.8))\n            self.prev_tooltip_opacity = map_value(passed_time, (0.0, 0.2), (0.8, 0.0))\n        ";" OLD FADE-IN-OUT\n        if not text and not self.brush_rolling:\n            if self.curr_tooltip_data:\n                self.prev_tooltip_opacity = 0.8\n                self.prev_tooltip_data = deepcopy(self.curr_tooltip_data)\n                self.anim('tooltip__prev',\n                        self, 'prev_tooltip_opacity', target_value=0.0,\n                        duration=0.2, smooth=True, delay=0.0,\n                        finish_callback=self.disable_tooltip)\n                self.curr_tooltip_data = None\n            return None\n\n        if self.curr_tooltip_data and not self.brush_rolling:\n            if self.curr_tooltip_data[1] == text:\n                return\n\n            self.prev_tooltip_opacity = 0.8\n            self.prev_tooltip_data = deepcopy(self.curr_tooltip_data)\n            self.anim('tooltip__prev',\n                      self, 'prev_tooltip_opacity', target_value=0.0,\n                      duration=0.15, smooth=True, delay=0.0,\n                      finish_callback=self.disable_tooltip)\n        ";" OLD FADE-IN-OUT\n        self.curr_tooltip_data = pos, text\n\n        if self.brush_rolling:\n            self.prev_tooltip_data = None\n            self.prev_tooltip_opacity = 0.0\n            self.curr_tooltip_opacity = 0.8\n        else:\n            self.curr_tooltip_opacity = 0.0\n            self.anim('tooltip__curr',\n                    self, 'curr_tooltip_opacity', target_value=0.8,\n                    duration=0.2, smooth=True, delay=0.0)\n        "
	def disable_tooltip(A):A.prev_tooltip_data=_A