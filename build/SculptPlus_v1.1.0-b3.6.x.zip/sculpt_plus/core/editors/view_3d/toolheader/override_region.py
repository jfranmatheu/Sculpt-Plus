_E='draw_mode_settings'
_D='draw_tool_settings'
_C='SCULPT'
_B='sculpt_plus'
_A=True
from bl_ui.space_view3d import VIEW3D_HT_tool_header
from bpy.types import Brush as BlBrush,UILayout
from bl_ui.properties_paint_common import UnifiedPaintPanel
from ...backup_cache import get_attr_from_cache,VIEW3D_PT_tools_active,set_cls_attribute
def draw_error(self,context):self.layout.label(text='ERROR!')
def draw_toolheader_tool_settings(self:VIEW3D_HT_tool_header,context):
	F=self;D=None;A=context
	if A.mode!=_C or _B not in A.workspace:get_attr_from_cache(VIEW3D_HT_tool_header,_D,draw_error)(F,A);return
	T=_B not in A.workspace;H=A.space_data.type;I=VIEW3D_PT_tools_active._tool_active_from_context(A,H)
	if not I:return D
	J:str=getattr(I,'idname',D);N,J=J.split('.');O:bool=N=='builtin_brush';K,U,P=VIEW3D_PT_tools_active._tool_get_active(A,H,_C,with_icon=_A)
	if K is D:return D
	C:UILayout=F.layout;C.label(text='    '+K.label,icon_value=P)
	if O:
		B:BlBrush=A.tool_settings.sculpt.brush
		if B is D:C.label(text='No active brush !');return
		'\n        UnifiedPaintPanel.prop_unified(layout, context, brush, \'size\', \'size\', \'use_pressure_size\', text="Radius", slider=True, header=True)\n        UnifiedPaintPanel.prop_unified(layout, context, brush, \'strength\', \'strength\', \'use_pressure_strength\', text="Strength", slider=True, header=True)\n        if not brush.sculpt_capabilities.has_direction:\n            layout.prop(brush, \'direction\', expand=True, text="")\n        ';Q=A.tool_settings;G=B.sculpt_capabilities;L=Q.unified_paint_settings
		if G.has_color:E=C.row(align=_A);E.ui_units_x=4;UnifiedPaintPanel.prop_unified_color(E,A,B,'color',text='');UnifiedPaintPanel.prop_unified_color(E,A,B,'secondary_color',text='');E.separator();C.prop(B,'blend',text='',expand=False)
		M='size';R=L if L.use_unified_size else B
		if R.use_locked_size=='SCENE':M='unprojected_radius'
		UnifiedPaintPanel.prop_unified(C,A,B,M,pressure_name='use_pressure_size',unified_name='use_unified_size',text='Radius',slider=_A,header=_A);S='use_pressure_strength'if G.has_strength_pressure else D;UnifiedPaintPanel.prop_unified(C,A,B,'strength',pressure_name=S,unified_name='use_unified_strength',text='Strength',header=_A)
		if not G.has_direction:C.row().prop(B,'direction',expand=_A,text='')
	else:get_attr_from_cache(VIEW3D_HT_tool_header,_D,draw_error)(F,A)
def draw_toolheader_mode_settings(self,context):
	A=context
	if A.mode!=_C or _B not in A.workspace:get_attr_from_cache(VIEW3D_HT_tool_header,_E,draw_error)(self,A);return
	E=_B not in A.workspace;D:UILayout=self.layout;C=D.row(align=_A);C.box().label(icon='MOD_MIRROR');B=C.row(align=_A);B.scale_x=0.7;B.prop(A.object,'use_mesh_mirror_x',text='X',toggle=_A);B.prop(A.object,'use_mesh_mirror_y',text='Y',toggle=_A);B.prop(A.object,'use_mesh_mirror_z',text='Z',toggle=_A);B=C.row(align=_A);B.popover('VIEW3D_PT_sculpt_symmetry_for_topbar',text='');D.popover('VIEW3D_PT_sculpt_options',text='Options')
def register():set_cls_attribute(VIEW3D_HT_tool_header,_D,draw_toolheader_tool_settings);set_cls_attribute(VIEW3D_HT_tool_header,_E,draw_toolheader_mode_settings)