_D='Loading...'
_C='TEXTURE'
_B=False
_A=None
from uuid import uuid4
from copy import deepcopy
from colorsys import hsv_to_rgb
from mathutils import Vector
from .image import Thumbnail
from ..thumbnailer import Thumbnailer
from sculpt_plus.path import DBShelf
from sculpt_plus.lib import Icon
from sculpt_plus.utils.math import map_value
from sculpt_plus.sculpt_hotbar.di import DiIcoCol,DiText,DiRct,DiCage,DiBr,DiIcoOpGamHl
class CategoryItem:
	fav:bool;id:str;cat_id:str;type:str='NONE';db_idname:str='undefined';thumbnail:Thumbnail
	def __init__(A,cat=_A,_save=_B,custom_id:str=_A):
		B=custom_id;A.id=uuid4().hex if B is _A else B;A.fav=_B;A.cat_id=cat;(A.thumbnail):Thumbnail=Thumbnail.empty(A)
		if _save:A.save_default()
		A.init()
	def init(A):0
	def rename(A,new_name:str)->_A:A.name=new_name
	def copy(B)->'CategoryItem':A=deepcopy(B);A.name=B.name+' copy';A.id=uuid4().hex;A.save_default();A.cat_id=_A;B.cat.link_item(A);return A
	@property
	def cat(self):
		' Property utility to get the brush category from Manager.instance. ';A=self;from ..manager import Manager as B
		if A.type=='BRUSH':return B.get().get_brush_cat(A)
		elif A.type==_C:return B.get().get_texture_cat(A)
	def _save(A)->_A:A.save_default()
	def save(A)->_A:' Save the brush category to the database. '
	def save_default(A)->_A:0
	def draw_preview(A,p:Vector,s:Vector,act:bool=_B,opacity:float=1,parent_widget=_A,fallback=_A)->_A:
		C=fallback;B=opacity
		if A.thumbnail and A.thumbnail.is_valid:A.thumbnail.draw(p,s,act,opacity=B)
		elif C is not _A:C(p,s,act,B)
class BrushCatItem(CategoryItem):
	type:str='BRUSH';db_idname:str='brushes'
	def save(A)->_A:' Save the brush category to the database. ';DBShelf.BRUSH_SETTINGS.write(A)
	def save_default(A)->_A:DBShelf.BRUSH_DEFAULTS.write(A)
	def draw_preview(A,p:Vector,s:Vector,act:bool=_B,opacity:float=1,view_widget=_A,fallback=_A)->_A:
		D=fallback;C=opacity;B=act
		if A.thumbnail and A.thumbnail.is_valid:A.thumbnail.draw(p,s,B,opacity=C)
		elif D is not _A:D(p,s,B,C)
		else:
			DiBr(p,s,A.sculpt_tool,B)
			if A.thumbnail.is_loading:DiRct(p,s,(0,0,0,0.5*C));DiText(p+Vector((2,2)),_D,12,1,shadow_props={})
			elif A.use_custom_icon and A.icon_filepath:A.thumbnail.set_filepath(A.icon_filepath,lazy_generate=True)
class TextureCatItem(CategoryItem):
	type:str=_C;db_idname:str='textures'
	def save(A)->_A:' Save the brush category to the database. ';DBShelf.TEXTURES.write(A)
	def save_default(A)->_A:0
	def draw_preview(A,p:Vector,s:Vector,act:bool=_B,opacity:float=1,view_widget=_A,fallback=_A)->_A:
		F=fallback;D=act;C=view_widget;B=opacity
		if A.thumbnail and A.thumbnail.is_valid:A.thumbnail.draw(p,s,D,B)
		elif F is not _A:F(p,s,D,B)
		elif A.thumbnail is not _A:
			if A.thumbnail.is_unsupported:
				format=A.thumbnail.file_format
				if format=='PSD':DiIcoOpGamHl(p,s,Icon.FILE_PSD_1,0.8*B,int(D))
			else:
				if C:G=p-C.view_pos;E=G.x/C.view_size.x;I=(G.y+C.scroll)/C.view_size.y;E=map_value(E,(0,1),(0.2,0.8));H=*hsv_to_rgb(I,E,0.9),0.9*B
				else:H=0.9,0.9,0.9,0.9*B
				DiIcoCol(p,s,Icon.TEXTURE_OPACITY,H)
				if A.thumbnail.is_loading:DiRct(p,s,(0,0,0,0.5*B));DiText(p+Vector((2,2)),_D,12,1,shadow_props={})
				else:Thumbnailer.push(A.thumbnail)