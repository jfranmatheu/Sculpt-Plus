_D='GPU_SHADER'
_C='GPU_SHADER_INTERFACE_INFO'
_B=None
_A='GPU_SHADER_CREATE_INFO'
from gpu.types import GPUShaderCreateInfo,GPUStageInterfaceInfo,GPUShader
from gpu.shader import create_from_info
from sculpt_plus.path import SculptPlusPaths
class GPU_SHADER:
	' Wrapper for GPUShader type. ';idname:str;gpu_shader:GPUShader;_instances={}
	@classmethod
	def get(A,idname:str)->_D:
		B=idname
		if B not in A._instances:A._instances[B]=A.from_info(B)
		return A._instances[B]
	@classmethod
	def push(B,gpu_shader:'GPU_SHADER')->_B:A=gpu_shader;B._instances[A.idname]=A
	@classmethod
	def from_info(B,shader_info:str or _A)->_D:A=shader_info;return B(A if isinstance(A,str)else A.idname,GPU_SHADER_CREATE_INFO.create_shader(A))
	def __init__(A,idname:str,gpu_shader:GPUShader):A.idname=idname;A.gpu_shader=gpu_shader;GPU_SHADER.push(A)
	@property
	def name(self)->str:return self.gpu_shader.name
class GPU_SHADER_INTERFACE_INFO:
	' Wrapper for GPUShaderInterfaceInfo type. ';_instances={}
	@classmethod
	def get(A,idname:str)->_C:return A._instances[idname]
	@classmethod
	def push(B,interface:'GPU_SHADER_INTERFACE_INFO')->_B:A=interface;B._instances[A.idname]=A.shader_interface
	def __init__(A,idname:str)->_B:B=idname;A.idname=B;A.shader_interface=GPUStageInterfaceInfo(B);GPU_SHADER_INTERFACE_INFO.push(A)
	def flat(A,type:str,name:str)->_C:A.shader_interface.flat(type,name);return A
	def no_perspective(A,type:str,name:str)->_C:A.shader_interface.no_perspective(type,name);return A
	def smooth(A,type:str,name:str)->_C:A.shader_interface.smooth(type,name);return A
def record_action(method):
	B=method
	def A(ref,*C,**D):
		A=ref
		if A.use_record:A.record_def(B,*(C),**D)
		return B(A,*(C),**D)
	return A
class GPU_SHADER_CREATE_INFO:
	' Wrapper for GPUShaderCreateInfo type. ';_instances={}
	@classmethod
	def create_shader(B,idname:str or _A)->GPUShader:A=idname;C=A if isinstance(A,GPU_SHADER_CREATE_INFO)else B.get(A);return create_from_info(C.shader_info)
	@classmethod
	def get(A,idname:str)->_A:return A._instances[idname]
	@classmethod
	def push(A,info:'GPU_SHADER_CREATE_INFO')->_B:A._instances[info.idname]=info
	def compile(A)->GPU_SHADER:' Create shader from this shader info object, as well as compile it. ';return GPU_SHADER.from_info(A)
	def record_def(A,method:callable,*B,**C)->_B:A.record_history.append((method.__name__,B,C))
	def __init__(A,idname:str,record:bool=False,based_on:str=_B)->_B:
		C=based_on;B=record;A.idname=idname;A.use_record=B
		if B:A.record_history=[]
		A.shader_info=GPUShaderCreateInfo()
		if C is not _B:
			D=GPU_SHADER_CREATE_INFO.get(C)
			for (E,F,G) in D.record_history:getattr(A,E)(*(F),**G)
		GPU_SHADER_CREATE_INFO.push(A)
	@record_action
	def define(self,name:str,value:str='')->_A:'Add a preprocessing define directive. In GLSL it would be something like:\n\n            #define name value\n\n            :arg name: Token name.\n            :type name: str\n            :arg value: Text that replaces token occurrences.\n            :type value: str\n        ';self.shader_info.define(name,value);return self
	@record_action
	def fragment_out(self,attr_index:int,type:str,name:str,blend:str='NONE')->_A:' Specify a fragment output corresponding to a framebuffer target slot. ';self.shader_info.fragment_out(attr_index,type,name,blend=blend);return self
	@record_action
	def fragment_source(self,source:str)->_A:
		' Fragment shader source code written in GLSL. ';A=source
		if A.endswith('.frag'):A=SculptPlusPaths.LIB_SHADERS_FRAG.read(A)
		elif A.endswith('.glsl'):A=SculptPlusPaths.LIB_SHADERS_BUILTIN.read(A)
		self.shader_info.fragment_source(A);return self
	@record_action
	def push_constant(self,type:str,name:str,size=0)->_A:' Specify a global access constant. ';self.shader_info.push_constant(type,name,size);return self
	@record_action
	def sampler(self,index:int,type:str,name:str)->_A:' Specify an image texture sampler. ';self.shader_info.sampler(index,type,name);return self
	@record_action
	def typedef_source(self,source:str)->_A:' Source code included before resource declaration. Useful for defining structs used by Uniform Buffers.\n            Example:\n\n            "struct MyType {int foo; float bar;};"\n\n            :arg source: The source code defining types.\n            :type source: str ';self.shader_info.typedef_source(source);return self
	@record_action
	def uniform_buf(self,index:int,type:str,name:str)->_A:' Specify a uniform variable whose type can be one of those declared in typedef_source. ';self.shader_info.uniform_buf(index,type,name);return self
	@record_action
	def vertex_in(self,index:int,type:str,name:str)->_A:' Add a vertex shader input attribute. ';self.shader_info.vertex_in(index,type,name);return self
	@record_action
	def vertex_out(self,interface:GPUStageInterfaceInfo or GPU_SHADER_INTERFACE_INFO)->_A:
		' Add a vertex shader output interface block. ';A=interface
		if isinstance(A,str):A=GPU_SHADER_INTERFACE_INFO.get(A)
		self.shader_info.vertex_out(A);return self
	@record_action
	def vertex_source(self,source:str)->_A:
		' Vertex shader source code written in GLSL.\n            Example:\n\n            "void main {gl_Position = vec4(pos, 1.0);}" ';A=source
		if A.endswith('.vert'):A=SculptPlusPaths.LIB_SHADERS_VERT.read(A)
		elif A.endswith('.glsl'):A=SculptPlusPaths.LIB_SHADERS_BUILTIN.read(A)
		self.shader_info.vertex_source(A);return self
class Type:FLOAT='FLOAT';INT='INT';UINT='UINT';VEC2='VEC2';VEC3='VEC3';VEC4='VEC4';MAT3='MAT3';MAT4='MAT4';UVEC2='UVEC2';UVEC3='UVEC3';UVEC4='UVEC4';IVEC2='IVEC2';IVEC3='IVEC3';IVEC4='IVEC4';BOOL='BOOL';' Additionally supported types to enable data optimization and native\n    * support in some GPU back-ends.\n    * NOTE: These types must be representable in all APIs. E.g. `VEC3_101010I2` is aliased as vec3\n    * in the GL back-end, as implicit type conversions from packed normal attribute data to vec3 is\n    * supported. UCHAR/CHAR types are natively supported in Metal and can be used to avoid\n    * additional data conversions for `GPU_COMP_U8` vertex attributes. ';VEC3_101010I2='VEC3_101010I2';UCHAR='UCHAR';UCHAR2='UCHAR2';UCHAR3='UCHAR3';UCHAR4='UCHAR4';CHAR='CHAR';CHAR2='CHAR2';CHAR3='CHAR3';CHAR4='CHAR4'