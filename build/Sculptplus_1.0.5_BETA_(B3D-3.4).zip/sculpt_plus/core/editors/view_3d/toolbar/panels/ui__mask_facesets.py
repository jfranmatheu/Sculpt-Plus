_J='TRIA_DOWN'
_I='Lasso Tool'
_H='Box Tool'
_G='SHRINK'
_F='Shrink'
_E='INVERT'
_D='Invert'
_C=None
_B=False
_A=True
from bpy.types import UILayout
from sculpt_plus.props import Props
from sculpt_plus.previews import Previews
from sculpt_plus.prefs import get_prefs
from sculpt_plus.core.data.cy_structs import CyBlStruct
def _draw_mask_filters(content,only_icons:bool=_B):D=content;C='sculpt.mask_filter';B=only_icons;A=D.row(align=_A);A.operator(C,text=''if B else'Smooth',icon_value=Previews.Mask.SMOOTH()).filter_type='SMOOTH';A.operator(C,text=''if B else'Sharpen',icon_value=Previews.Mask.SHARP()).filter_type='SHARPEN';A=D.row(align=_A);A.operator(C,text=''if B else'Grow',icon_value=Previews.Mask.GROW()).filter_type='GROW';A.operator(C,text=''if B else _F,icon_value=Previews.Mask.SHRINK()).filter_type=_G;A=D.row(align=_A);A.operator(C,text=''if B else'Contrast (+)',icon_value=Previews.Mask.CONTRAST_UP()).filter_type='CONTRAST_INCREASE';A.operator(C,text=''if B else'Contrast (--)',icon_value=Previews.Mask.CONTRAST_DOWN()).filter_type='CONTRAST_DECREASE'
def _draw_mask_expand(content,keep_previous_mask,invert_mask,align=_B):C=invert_mask;B=keep_previous_mask;D=content.row(align=align);A=D.operator('sculpt_plus.mask_expand_wrapper',icon='MONKEY',text='By Topology');A.keep_previous_mask=B;A.invert=C;A=D.operator('sculpt_plus.mask_expand_normal_wrapper',icon='SNAP_NORMAL',text='By Normals');A.keep_previous_mask=B;A.invert=C
def _draw_mask_effects(content,align:bool=_B):A=content.row(align=align);A.operator('sculpt.mask_init',icon_value=Previews.Mask.RANDOM(),text='Random').mode='RANDOM_PER_VERTEX';A.operator('sculpt.mask_from_cavity',icon_value=Previews.Mask.CAVITY(),text='Cavity').settings_source='OPERATOR'
def _draw_mask_to_mesh(content,align:bool=_B):A=content.row(align=align);A.operator('mesh.paint_mask_extract',icon_value=Previews.Mask.EXTRACT());A.operator('sculpt_plus.mask_slice_wrapper',icon_value=Previews.Mask.SLICE())
def draw_mask(layout:UILayout,context):
	h='mask_op_invert';g='mask_op_clear_previous_mask';b='paint.mask_lasso_gesture';a='paint.mask_box_gesture';Z='Clear';Y='Fill';X='paint.mask_flood_fill';T=context;Q=layout;H='VALUE';Q.use_property_decorate=_B;D=Props.Scene(T);F=D.mask_op_use_front_faces_only;U=not D.mask_op_clear_previous_mask;V=D.mask_op_invert;c=get_prefs(T);B=Q.row();B.scale_y=1.25;I=B.operator(X,text=Y,icon_value=Previews.Main.FILL());I.mode=H;I.value=1;I=B.operator(X,text=Z,icon_value=Previews.Mask.CLEAR());I.mode=H;I.value=0;B.operator(X,text=_D,icon_value=Previews.Mask.INVERT()).mode=_E;J=Q.column();B=J.split(factor=0.37,align=_A);K=B.box();K.scale_y=0.5;K.label(text=_H);A=B.operator(a,text=Y);A.mode=H;A.value=0;A.use_front_faces_only=F;A=B.operator(a,text=Z);A.mode=H;A.value=1;A.use_front_faces_only=F;A=B.operator(a,text=_D);A.mode=_E;A.use_front_faces_only=F;B=J.split(factor=0.37,align=_A);K=B.box();K.scale_y=0.5;K.label(text=_I);A=B.operator(b,text=Y);A.mode=H;A.value=1;A.use_front_faces_only=F;A=B.operator(b,text=Z);A.mode=H;A.value=0;A.use_front_faces_only=F;A=B.operator(b,text=_D);A.mode=_E;A.use_front_faces_only=F;B=J.row();B.use_property_split=_A;B.prop(D,'mask_op_use_front_faces_only',text='Front Faces Only')
	if c.toolbar_panel_mask_layout=='COMPACT':
		i=J.column(align=_A)
		def R(title:str,icon:str='NONE',header_inject=_C)->UILayout:
			B=header_inject;C=i.column(align=_A);A=C.box().row(align=_B);A.scale_y=0.66;A.alignment='EXPAND';A.label(text='\t'+title,icon=icon)
			if B is not _C:B(A)
			return C
		def j(layout):A=layout.row(align=_A);A.scale_x=1.2;A.prop(D,g,text='',icon_value=Previews.Mask.CLEAR());A.prop(D,h,text='',icon_value=Previews.Mask.INVERT())
		_draw_mask_filters(R('Mask Filters'),only_icons=_B);_draw_mask_expand(R('Mask Expand',header_inject=j),U,V,align=_A);_draw_mask_effects(R('Mask Generator'),align=_A);_draw_mask_to_mesh(R('Mask to Mesh'),align=_A);return
	G:bool=c.toolbar_panel_mask_layout=='TABS'
	if not G:E=J.column(align=_A)
	' MASK FILTERS. '
	if G:0
	else:L=E.column(align=_A);C=L.box();C.scale_y=0.8;C.label(text='M a s k   F i l t e r s :');L=L.column(align=_A);L.scale_y=1.25;_draw_mask_filters(L)
	' MASK EXPAND. '
	if G:0
	else:E.separator(factor=1.25);M=E.column(align=_A);C=M.box().row();C.label(text='M a s k   E x p a n d :');C.scale_y=0.8;W=C.row(align=_A);W.scale_x=1.2;W.prop(D,g,text='',icon_value=Previews.Mask.CLEAR());W.prop(D,h,text='',icon_value=Previews.Mask.INVERT());M=M.column(align=_A);M.scale_y=1.25;_draw_mask_expand(M.column(align=_A),U,V,align=_A)
	' MASK EFFECTS. '
	if G:0
	else:E.separator(factor=1.25);N=E.column(align=_A);C=N.box();C.scale_y=0.8;C.label(text='M a s k   G e n e r a t o r :');N=N.column(align=_A);N.scale_y=1.25;_draw_mask_effects(N.column(align=_A),align=_A)
	' MASK TO MESH. '
	if G:0
	else:E.separator(factor=1.25);O=E.column(align=_A);C=O.box();C.scale_y=0.8;C.label(text='M a s k   to   M e s h :');O=O.column(align=_A);O.scale_y=1.25;_draw_mask_to_mesh(O,align=_A)
	if G:
		d=Props.UI(T);S=d.mask_panel_tabs;e=Q.column(align=_A);f=e.row(align=_A);f.prop(d,'mask_panel_tabs',text='Filters',expand=_A);f.scale_y=1.4;P=e.box();P.scale_y=1.2
		if S=='MASK_EXPAND':_draw_mask_expand(P.column(),U,V)
		elif S=='MASK_EFFECTS':_draw_mask_effects(P.column())
		elif S=='MASK_FILTERS':_draw_mask_filters(P.column(align=_A))
		elif S=='MASK_TO_MESH':_draw_mask_to_mesh(P.column())
def draw_facesets(layout:UILayout,context):
	N='FACE_MAPS';M='HIDE_OFF';L='sculpt_plus.select_tool__face_set_edit';G=context;F='sculpt.face_sets_create';C=layout;B='sculpt.face_sets_init';H=Props.UI(G);I=Props.Scene(G);J=I.facesets_op_use_front_faces_only;C=C.column()
	def D(title:str,icon:str='NONE',toggle_prop:str=_C,columns:int=2,align:bool=_A,use_content_box:bool=_B,scale_y=1.25):
		G=columns;F=title;D=toggle_prop;C.separator(factor=0.4);B=C.column(align=_A);A=B.box().row(align=_A);A.scale_y=0.8
		if D is _C:A.label(text=F,icon=icon)
		else:
			A.alignment='LEFT';I=getattr(H,D);A.prop(H,D,text=F,icon=_J if I else'TRIA_RIGHT',emboss=_B)
			if not I:return A,_C
		if use_content_box:B=B.box()
		if G is not _C:E=B.grid_flow(align=align,columns=G,even_columns=_A,even_rows=_A,row_major=_A)
		else:E=B
		E.scale_y=scale_y;return A,E
	C.operator('sculpt.face_sets_randomize_colors',text='Random Colors');C.separator(factor=0.5);E,A=D('T o o l s :',icon='TOOL_SETTINGS',align=_A,use_content_box=_B,columns=2);K=E.row(align=_A);K.scale_x=1.2;K.prop(I,'facesets_op_use_front_faces_only',text='',icon_value=Previews.Main.FRONT_FACES());A.operator(L,text='Grow',icon_value=Previews.FaceSets.GROW()).mode='GROW';A.operator(L,text=_F,icon_value=Previews.FaceSets.SHRINK()).mode=_G;A.operator('sculpt.face_set_box_gesture',text=_H,icon_value=Previews.FaceSets.BOX()).use_front_faces_only=J;A.operator('sculpt.face_set_lasso_gesture',text=_I,icon_value=Previews.FaceSets.LASSO()).use_front_faces_only=J;E,A=D('V i s i b i l i t y :',icon='CAMERA_STEREO',align=_A,use_content_box=_B,columns=2);A.operator('sculpt.reveal_all',text='Reveal All',icon=M);A.operator('sculpt.face_set_change_visibility',text=_D,icon='HOLDOUT_ON').mode=_E;E,A=D('C r e a t e   F a c e - S e t   f r o m ...',toggle_prop='show_facesets_panel_createfrom_section')
	if A:A.operator(F,text='Mask',icon='MOD_MASK').mode='MASKED';A.operator(F,text='Visible',icon=M).mode='VISIBLE';A.operator(F,text='EditMode Selection',icon='RESTRICT_SELECT_OFF').mode='SELECTION'
	E,A=D('I n i t   F a c e - S e t s   B y ...',toggle_prop='show_facesets_panel_initialize_section',columns=2,scale_y=1)
	if A:A.operator(B,text='Loose Parts',icon='GP_CAPS_FLAT').mode='LOOSE_PARTS';A.operator(B,text='Materials',icon='MATERIAL').mode='MATERIALS';A.operator(B,text='Normals',icon='ORIENTATION_NORMAL').mode='NORMALS';A.operator(B,text='FaceSet Boundaries',icon='CLIPUV_DEHLT').mode='FACE_SET_BOUNDARIES';A.operator(B,text='Face Maps',icon=N).mode=N;A.operator(B,text='UV Seams',icon='UV').mode='UV_SEAMS';A.operator(B,text='Edge Creases',icon='BRUSH_CREASE').mode='CREASES';A.operator(B,text='Bevel Weight',icon='MOD_VERTEX_WEIGHT').mode='BEVEL_WEIGHT';A.operator(B,text='Sharp Edges',icon='SHARPCURVE').mode='SHARP_EDGES'
	E,A=D('F a c e  S e t   t o   M e s h :',icon='MESH_GRID',columns=2);A.operator('mesh.face_set_extract',text='Extract',icon_value=Previews.Mask.EXTRACT())
def draw_mask_facesets(layout:UILayout,context):
	K='show_mask_facesets_panel';H='toolbar_maskfacesets_sections';C=context;from sculpt_plus.core.data.wm import SCULPTPLUS_PG_ui_toggles as L;A:L=Props.UI(C);E=Props.UI(C);I:str=E.toolbar_maskfacesets_sections;M:str=UILayout.enum_item_description(E,H,I);N:int=UILayout.enum_item_icon(E,H,I);D=layout.column(align=_A);B=D.box();B=B.row(align=_A);B.scale_y=1.5;F=B.row(align=_A);F.scale_y=0.5;F.scale_x=0.75;F.template_icon(icon_value=N,scale=2.0);O=_J if A.show_mask_facesets_panel else'TRIA_LEFT';B.prop(A,K,expand=_A,text=M,emboss=_B);B.prop(A,K,expand=_A,text='',icon=O,emboss=_B)
	if not A.show_mask_facesets_panel:return
	J=D.row(align=_A);J.prop(A,H,text='Mask',expand=_A);J.scale_y=1.35;P=D.box();P.ui_units_y=0.1;'\n    cy_layout = CyBlStruct.UI_LAYOUT(selector)\n    print("Align:", cy_layout.align, "Type:", cy_layout.item.type)\n    print("Pos:", cy_layout.position, "Size:", cy_layout.size)\n    print("Scale", tuple(cy_layout.scale), "Units:", tuple(cy_layout.units))\n    cy_children_layout = cy_layout.children_layout\n    if cy_children_layout:\n        print("__Children Layout__")\n        print("\tAlign:", cy_children_layout.align, "Type:", cy_children_layout.item.type)\n        print("\tPos:", cy_children_layout.position, "Size:", cy_children_layout.size)\n        print("\tScale", tuple(cy_children_layout.scale))\n    for child in cy_layout.children:\n        print("__Children__")\n        print("\tType:", child.type)\n        print("\tSize:", child.to_layout().size)\n    ';G=D.box();G.separator(factor=0.1)
	if A.toolbar_maskfacesets_sections=='MASK':draw_mask(G,C)
	elif A.toolbar_maskfacesets_sections=='FACESETS':draw_facesets(G,C)