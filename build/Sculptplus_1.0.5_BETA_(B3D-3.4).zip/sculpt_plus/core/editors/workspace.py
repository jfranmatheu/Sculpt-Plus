_C='Context'
_B='sculpt_plus'
_A=None
from bpy.types import Operator,Context,Event,WorkSpace,Menu
from sculpt_plus.props import Props
from sculpt_plus.path import SculptPlusPaths
import bpy
from bpy.app import timers
from bl_ui.space_view3d import VIEW3D_HT_header
from bl_ui.space_topbar import TOPBAR_MT_workspace_menu,TOPBAR_HT_upper_bar
from sculpt_plus.previews import Previews
from sculpt_plus.core.data.cy_structs import CyBlStruct
class SCULPTPLUS_OT_setup_workspace(Operator):
	bl_idname='sculpt_plus.setup_workspace';bl_label='Setup Sculpt+ Workspace';bl_description="Add the 'Sculpt+' Workspace to your .blend and set it up to start using Sculpt+ in your project!"
	def invoke(D,context:'Context',event:'Event'):
		C='Sculpt+';B=context;A=Props().Workspace(B)
		if A is not _A:return{'CANCELLED'}
		try:Props.Temporal(B).test_context=True
		except RuntimeError as E:print(E);return _A
		bpy.ops.workspace.append_activate(False,idname=C,filepath=SculptPlusPaths.BLEND_WORKSPACE());A:WorkSpace=bpy.data.workspaces.get(C,_A);B.window.workspace=A
		if _B not in A:A[_B]=1
		A['first_time']=1;A.use_filter_by_owner=True;B.window_manager.modal_handler_add(D);return{'RUNNING_MODAL'}
	def modal(A,context:'Context',event:'Event'):bpy.ops.wm.owner_enable('INVOKE_DEFAULT',False,owner_id=_B);return{'FINISHED'}
def draw_workspace_setup_op(self,context:Context):
	B=context;A=self
	if B.region.alignment=='RIGHT'and Props.Workspace(B)is _A:
		if issubclass(A.__class__,Menu):A.layout.separator();A.layout.operator(SCULPTPLUS_OT_setup_workspace.bl_idname,text='Sculpt +',icon_value=Previews.Main.BRUSH_BROOM())
		else:A.layout.operator(SCULPTPLUS_OT_setup_workspace.bl_idname,text='S+',icon_value=Previews.Main.BRUSH_BROOM())
def register():TOPBAR_HT_upper_bar.append(draw_workspace_setup_op)
def unregister():TOPBAR_HT_upper_bar.remove(draw_workspace_setup_op)