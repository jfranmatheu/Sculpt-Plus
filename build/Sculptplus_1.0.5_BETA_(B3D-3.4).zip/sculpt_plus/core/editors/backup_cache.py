from bl_ui.space_view3d import VIEW3D_HT_tool_header
from bl_ui.properties_paint_common import UnifiedPaintPanel,BrushSelectPanel,BrushPanel
from bpy.types import VIEW3D_PT_tools_brush_select,VIEW3D_PT_tools_active,VIEW3D_PT_tools_brush_settings,VIEW3D_PT_tools_brush_settings_advanced,VIEW3D_PT_tools_brush_falloff,VIEW3D_PT_tools_brush_stroke,VIEW3D_PT_tools_brush_texture
classes_to_reset=VIEW3D_PT_tools_active,VIEW3D_HT_tool_header,VIEW3D_PT_tools_brush_select,VIEW3D_PT_tools_brush_settings
_cache_reset={}
def get_attr_from_cache(cls,attr,default=None):return _cache_reset[cls.__name__].get(attr,default)
def register():
	for A in classes_to_reset:_cache_reset[A.__name__]=A.__dict__.copy()
def unregister():
	for A in classes_to_reset:
		B=_cache_reset[A.__name__]
		for (C,D) in B.items():
			try:setattr(A,C,D)
			except AttributeError:pass