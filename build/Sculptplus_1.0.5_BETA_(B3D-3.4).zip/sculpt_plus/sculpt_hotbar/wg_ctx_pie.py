_P='DUPLICATE'
_O='Change item name'
_N='Rename'
_M='Assign Icon'
_L='Remove'
_K='RESET'
_J='SAVE'
_I='RENAME'
_H='ASSIGN_ICON'
_G='REMOVE'
_F='TEXTURE'
_E=True
_D='INVOKE_DEFAULT'
_C='BRUSH'
_B=False
_A=None
from .wg_base import WidgetBase
from typing import Tuple,Union
import bpy
from bpy import ops as OPS
from math import radians,cos,sin
from mathutils import Vector
from sculpt_plus.sculpt_hotbar.di import DiRct,DiText,DiCircle,DiTri,get_text_dim
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
from sculpt_plus.utils.math import rotate_point_around_point,point_inside_circle,distance_between
from sculpt_plus.props import Props,Brush,Texture,BrushCategory,TextureCategory
item_types=Union[Brush,Texture,BrushCategory,TextureCategory]
class CtxPie(WidgetBase):
	interactable:bool=_E;target_item:item_types
	def get_options(A,item:item_types)->Tuple[Tuple[str,str,str]]:return()
	def init(A):A.enabled=_B;(A.safety_radius):int=20*A.cv.scale;(A.radius):int=A.safety_radius*3.5;A.hovered_option=_A;'\n        super().init()\n\n        self.add_defaults(\n            {\n                "value": 0,\n                "label": "",\n                "color": "black",\n                "background_color": "white",\n                "border_color": "black",\n                "border_width": 0,\n                "border_radius": 0,\n            })\n        '
	def show(A,cv,m:Vector,item:item_types)->_A:
		A.origin=m;A.options=A.get_options(item);(A.safety_radius):int=20*A.cv.scale;(A.radius):int=A.safety_radius*(3.32*A.cv.scale)
		if not A.options:return
		E=360/len(A.options);A.options_pos=[];F:Vector=A.origin+Vector((0,A.radius))
		for (G,H) in enumerate(A.options):
			D=Vector(get_text_dim(H[1],14,cv.scale))/2.0;I=radians(E*G);B=rotate_point_around_point(A.origin,F,I);J=B-A.origin;C=J/A.radius
			if C.x!=0:B.x+=D.x*C.x
			if C.y!=0:B.y+=D.y*C.y
			A.options_pos.append(B)
		A.target_item=item;A.enabled=_E;cv.inject_ctx_widget(A)
	def on_mousemove(A,ctx,cv,m:Vector)->_A:
		if point_inside_circle(m,A.origin,A.safety_radius):A.hovered_option=_A;return
		B=tuple((distance_between(m,B)for B in A.options_pos));C:float=min(B);D:int=B.index(C);(A.hovered_option):str=A.options[D][0];cv.mouse=m;return _E
	def modal_exit(A,ctx,cv,m:Vector,cancel:bool=_B)->_A:
		if not cancel:A.on_rightmouse_release(ctx,cv,m)
		A.enabled=_B;A.target_item=_A;A.hovered_option=_A
	def on_rightmouse_release(A,ctx,cv,m:Vector)->_A:
		if point_inside_circle(m,A.origin,A.safety_radius):return
		if A.hovered_option is _A:return
		A.execute_pie_option(ctx,A.hovered_option)
	def execute_pie_option(A,ctx,option_id:str)->_A:0
	def draw(A,context,cv,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		DiCircle(A.origin,2.0,A.safety_radius,16,(0.92,0.92,0.92,0.92)if A.hovered_option else(0.9,0.3,0.2,0.92))
		for (B,C) in zip(A.options,A.options_pos):DiText(C,B[1],14,scale,(1,1,1,1),pivot=(0.5,0.5),draw_rect_props={'color':(0.12,0.12,0.12,0.95),'margin':6,'outline_color':(0.05,0.05,0.05,0.92)if A.hovered_option!=B[0]else prefs.theme_active_slot_color})
class ShelfGridItemCtxPie(CtxPie):
	def get_options(B,item:Union[Brush,Texture])->Tuple[Tuple[str,str,str]]:
		type:str=B.cv.shelf_grid.type
		if type==_C:C:str=Props.ActiveBrushCat().id;A:int=Props.BrushCatsCount()
		elif type==_F:C:str=Props.ActiveTextureCat().id;A:int=Props.TextureCatsCount()
		else:return()
		D=('MOVE','Move','Move item to another category')if A>1 else _A,('UNFAV','Unmark Favourite','Unmark item as favourite')if item.fav else('FAV','Mark Favourite','Mark brush as favourite'),(_G,_L,'Remove item'),(_J,'Save Default','Save default state'),(_K,'Reset to Default','Reset to default state'),(_H,_M,'Set custom icon to the brush')if type==_C else _A,(_I,_N,_O),(_P,'Duplicate','Make a brush copy')if type==_C else _A;return tuple((A for A in D if A is not _A))
	def execute_pie_option(A,ctx,option_id:str)->_A:
		B=option_id;type:str=A.cv.shelf_grid.type
		if B==_G:
			if type==_C:Props.BrushManager().remove_brush_item(A.target_item)
			elif type==_F:Props.BrushManager().remove_texture_item(A.target_item)
		elif B=='MOVE':OPS.sculpt_plus.move_item_to_another_cat(_D,_B,cat_type=type,item_id=A.target_item.id)
		elif B==_H:OPS.sculpt_plus.assign_icon_to_brush(_D,_B,brush_id=A.target_item.id)
		elif B=='FAV':A.target_item.fav=_E
		elif B=='UNFAV':A.target_item.fav=_B
		elif B==_I:OPS.sculpt_plus.rename_item(_D,_B,item_type=type,item_id=A.target_item.id,item_name=A.target_item.name)
		elif B==_P:Props.BrushManager().duplicate_brush(A.target_item)
class ShelfSidebarCatCtxPie(CtxPie):
	def get_options(B,item:Union[BrushCategory,TextureCategory])->Tuple[Tuple[str,str,str]]:
		type:str=B.cv.shelf_grid.type
		if type==_C:A:str=Props.ActiveBrushCat();C:int=Props.BrushCatsCount()-1
		elif type==_F:A:str=Props.ActiveTextureCat();C:int=Props.TextureCatsCount()-1
		else:return()
		E=item==A;D=(_G,_L,'Remove category'),(_J,'Save Brushes Defaults','Save default state for every brush')if type==_C else _A,(_K,'Reset Brushes to Defaults','Reset to default state for every brush')if type==_C else _A,(_H,_M,'Set custom icon to the category'),(_I,_N,_O);return tuple((A for A in D if A is not _A))
	def execute_pie_option(A,ctx,option_id:str)->_A:
		B=option_id;type:str=A.cv.shelf_grid.type
		if B==_G:
			if type==_C:Props.BrushManager().remove_brush_cat(A.target_item)
			elif type==_F:Props.BrushManager().remove_texture_cat(A.target_item)
		elif B=='MOVE_UP':0
		elif B=='MOVE_DOWN':0
		elif B==_H:OPS.sculpt_plus.assign_icon_to_cat(_D,_B,cat_type=type,cat_id=A.target_item.id)
		elif B==_J:0
		elif B==_K:Props.BrushManager().reset_brush_cat(A.hovered_option)
		elif B==_I:OPS.sculpt_plus.rename_item(_D,_B,item_type='CAT_'+type,item_id=A.target_item.id,item_name=A.target_item.name)