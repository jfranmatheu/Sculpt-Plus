_B='COLLECTION_COLOR_0%i'
_A=None
from typing import List,Set
from uuid import uuid4
import bpy
from bpy.types import Scene as scn,PropertyGroup,Brush
from bpy.props import CollectionProperty,PointerProperty,BoolProperty,StringProperty,IntProperty,EnumProperty
def with_target_set_index(f):
	def A(self,target_set,*C,**D):
		B=self;A=target_set
		if isinstance(A,SculptHotbarBrushSet):
			for (E,F) in enumerate(B.sets):
				if F==A:A=E;break
		if not isinstance(A,int):return _A
		if A==-1:
			if B.active_set_index==-1:return _A
			A=B.active_set_index
		return f(B,A,*(C),**D)
	return A
def with_active_set(f):
	def A(self,*C,**D):
		A=self
		if bpy.sculpt_hotbar._cv_instance:E=bpy.sculpt_hotbar._cv_instance;B=A.alt_set_index if E.hotbar.use_secondary and A.alt_set_index!=-1 else A.active_set_index
		else:B=A.active_set_index
		if B==-1:return _A
		return f(A,A.sets[B],*(C),**D)
	return A
class SculptHotbarBrush(PropertyGroup):
	def update_brush(A,context):
		if A.slot is _A:return
		if not A.slot.use_paint_sculpt:A.slot=_A
	slot:PointerProperty(type=Brush,update=update_brush,name='Brush Slot')
set_icon_items=tuple(((_B%A,'','',_B%A,A)for A in range(1,9)))
class SculptHotbarBrushSet(PropertyGroup):
	def update_set_name(A,context):
		D:Set[str]={set.name for set in context.scene.sculpt_hotbar.sets if set!=A};B=A.name;C:int=1
		while B in D:B=A.name+'.'+str(C).zfill(3);C+=1
		if B!=A.name:A.name=B
	name:StringProperty(default='Brush Set',update=update_set_name);uid:StringProperty(default='');version:IntProperty(default=0);brushes:CollectionProperty(type=SculptHotbarBrush);icon:EnumProperty(name='Brush Set Icon',items=set_icon_items)
class SculptHotbarPG(PropertyGroup):
	def update_active_set_index(A,ctx=_A)->_A:
		if A.active_set_index==-1:return
		A.active_set=A.sets[A.active_set_index];print('Update active set')
	show_gizmo_sculpt_hotbar:BoolProperty(default=True,description='Enable Sculpt Hotbar');active_set_index:IntProperty(default=-1,name='Select Brush Set');alt_set_index:IntProperty(default=-1,name='Secondary Selected Brush Set');sets:CollectionProperty(type=SculptHotbarBrushSet)
	@property
	def active_set(self)->SculptHotbarBrushSet:
		A=self
		if bpy.sculpt_hotbar._cv_instance:C=bpy.sculpt_hotbar._cv_instance;B=A.alt_set_index if C.hotbar.use_secondary else A.active_set_index
		else:B=A.active_set_index
		if B==-1 or not A.sets:return _A
		return A.sets[B]
	@property
	def active_brushes(self)->List[SculptHotbarBrush]:
		if not self.active_set:return _A
		return self.active_set.brushes
	def new_set(A)->SculptHotbarBrushSet:
		B:SculptHotbarBrushSet=A.sets.add();B.uid=uuid4().hex;B.name='New Brush-Set';A.active_set_index=len(A.sets)-1
		for C in range(10):A.add_brush()
		return B
	@with_target_set_index
	def remove_set(self,target_brush_set:int=-1)->_A:
		B=target_brush_set;A=self;A.sets.remove(B)
		if B>=len(A.sets):A.active_set_index-=1
		if A.alt_set_index>=len(A.sets):A.alt_set_index-=1
		if A.alt_set_index==A.active_set_index:
			if len(A.sets)<2:return
			if A.alt_set_index!=0:A.alt_set_index-=1
			else:A.alt_set_index+=1
	@with_target_set_index
	def move_set(self,target_brush_set:int=-1,direction:int=0)->_A:
		C=direction;A=self
		if C==0:return
		D=target_brush_set;B=D+C
		if B>=len(A.sets):return
		A.sets.move(D,B);A.active_set_index=B
	@with_target_set_index
	def select_set(self,target_brush_set:int=-1,secondary:bool=False)->_A:
		A=target_brush_set
		if secondary:self.alt_set_index=A
		else:self.active_set_index=A
	def init_brushes(A):
		if not A.sets or len(A.sets)==0:
			import bpy;C='Clay Strips','Blob','Inflate/Deflate','Draw Sharp','Crease','Pinch/Magnify','Grab','Elastic Deform','Snake Hook','Scrape/Peaks';B=A.new_set();B.name='Default'
			for (D,E) in zip(B.brushes,C):D.slot=bpy.data.brushes.get(E,_A)
	@with_active_set
	def add_brush(self,act_set:SculptHotbarBrushSet):
		A=act_set
		if len(A.brushes)>=10:return
		return A.brushes.add()
	@with_active_set
	def set_brush(self,act_set:SculptHotbarBrushSet,i,br):act_set.brushes[i].slot=br
	@with_active_set
	def get_brush(self,act_set:SculptHotbarBrushSet,i):
		A=act_set
		if i>=len(A.brushes):return _A
		return A.brushes[i].slot
	@with_active_set
	def get_brushes(self,act_set:SculptHotbarBrushSet):return[A.slot for A in act_set.brushes]
	@with_active_set
	def get_brush_and_icon(self,act_set:SculptHotbarBrushSet,i):
		B=act_set
		if i>=len(B.brushes):return _A,_A
		A=B.brushes[i].slot
		if not A:return _A,_A
		return A,A.preview.icon_id
	@with_active_set
	def get_brush_icon(self,act_set:SculptHotbarBrushSet,i):return act_set.brushes[i].slot.preview.icon_id
	@with_active_set
	def draw_brush(self,act_set:SculptHotbarBrushSet,layout,i):layout.prop(act_set.brushes[i],'slot',text='',icon=self.get_brush_icon(i))
def register():scn.sculpt_hotbar=PointerProperty(type=SculptHotbarPG)