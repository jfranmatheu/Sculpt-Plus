_L='New Set'
_K='INTERFACE'
_J='TEXTURE'
_I='BRUSH'
_H='NONE'
_G=True
_F='SCULPT'
_E='HIDDEN'
_D='SKIP_SAVE'
_C='FINISHED'
_B=None
_A='CANCELLED'
from typing import Tuple,Set,List
from pathlib import Path
import bpy
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper
from bpy.props import IntProperty,EnumProperty,BoolProperty,StringProperty
from sculpt_plus.prefs import get_prefs
from sculpt_plus.props import Props
enum_items=[(_H,_H,'')]
op_pointer=_B
class SCULPTPLUS_OT_move_item_to_another_cat(Operator):
	'Move an item to another category';bl_idname='sculpt_plus.move_item_to_another_cat';bl_label='Move Item To Another Category';bl_description='Move an item to another category';bl_options={'REGISTER','UNDO'};item_id:StringProperty(options={_D,_E});cat_type:StringProperty(options={_D,_E})
	def get_enum_items(A,context)->List[Tuple[str,str,str]]:
		global op_pointer
		if op_pointer is not _B and op_pointer==A.as_pointer():return enum_items
		enum_items.clear()
		if A.cat_type==_I:C=Props.GetAllBrushCats();D=Props.ActiveBrushCat()
		elif A.cat_type==_J:C=Props.GetAllTextureCats();D=Props.ActiveTextureCat()
		else:return[(_H,_H,'')]
		for B in C:
			if D==B:continue
			enum_items.append((B.id,B.name,''))
		op_pointer=A.as_pointer();return enum_items
	bl_property='enum';enum:EnumProperty(name='Category List',items=get_enum_items,options={_D})
	@classmethod
	def poll(B,context):A=context;return A.active_object is not _B and A.mode==_F
	def invoke(A,context,event)->Set[str]:
		global op_pointer;op_pointer=_B
		if not A.item_id or not A.cat_type:return{_A}
		if A.cat_type==_I:
			if Props.BrushCatsCount()<=1:return{_A}
			B=Props.ActiveBrushCat()
		elif A.cat_type==_J:
			if Props.TextureCatsCount()<=1:return{_A}
			B=Props.ActiveTextureCat()
		else:return{_A}
		if A.item_id not in B.item_ids:return{_A}
		context.window_manager.invoke_search_popup(A);return{_K}
	def execute(A,context)->Set[str]:
		global op_pointer;op_pointer=_B
		if A.cat_type==_I:Props.BrushManager().move_brush(A.item_id,from_cat=_B,to_cat=A.enum)
		elif A.cat_type==_J:Props.BrushManager().move_texture(A.item_id,from_cat=_B,to_cat=A.enum)
		return{_C}
class SCULPTPLUST_OT_assign_icon_to_brush(Operator,ImportHelper):
	'Assign an icon to a brush';bl_idname='sculpt_plus.assign_icon_to_brush';bl_label='Assign Icon To Brush';bl_description='Assign an icon to a brush';brush_id:StringProperty(options={_D,_E})
	def execute(B,context):
		if not B.filepath:return{_A}
		A:Path=Path(B.filepath)
		if not A.exists()or not A.is_file():return{_A}
		if A.suffix not in{'.png','.jpg','jpeg'}:return{_A}
		C=Props.GetBrush(B.brush_id)
		if C is not _B:C.use_custom_icon=_G;C.icon_filepath=str(A)
		return{_C}
class SCULPTPLUS_OT_assign_icon_to_cat(Operator,ImportHelper):
	'Assign an icon to a brush';bl_idname='sculpt_plus.assign_icon_to_cat';bl_label='Assign Icon To Category';bl_description='Assign an icon to a category';cat_id:StringProperty(options={_D,_E});cat_type:StringProperty(options={_D,_E})
	def execute(A,context):
		if not A.filepath:return{_A}
		B:Path=Path(A.filepath)
		if not B.exists()or not B.is_file():return{_A}
		if B.suffix not in{'.png','.jpg','jpeg'}:return{_A}
		if A.cat_type==_I:C=Props.GetBrushCat(A.cat_id)
		elif A.cat_type==_J:C=Props.GetTextureCat(A.cat_id)
		if C is not _B:C.icon.set_filepath(str(B),lazy_generate=_G)
		return{_C}
class SCULPTHOTBAR_OT_set_brush(Operator):
	bl_idname='sculpt_hotbar.set_brush';bl_label='Set Active Brush';bl_description='Sets the current active brush into this hotbar slot';index:IntProperty(default=-1)
	@classmethod
	def poll(B,context):A=context;return A.mode==_F and A.tool_settings.sculpt.brush
	def execute(A,context):
		if A.index==-1:return{_A}
		Props.SetHotbarSelected(context,A.index);return{_C}
class SCULPTHOTBAR_OT_select_brush(Operator):
	bl_idname='sculpt_hotbar.select_brush';bl_label='Select Sculpt Hotbar Brush';bl_description='Selects a brush from hotbar slot';index:IntProperty(default=-1)
	@classmethod
	def poll(B,context):A=context;return A.mode==_F and A.scene.sculpt_hotbar.show_gizmo_sculpt_hotbar and A.scene.sculpt_hotbar.active_set
	def execute(A,context):
		B=context
		if A.index==-1:return{_A}
		C=B.scene.sculpt_hotbar.active_set
		if A.index>=len(C.brushes):return{_A}
		D=C.brushes[A.index].slot
		if not D:return{_A}
		B.tool_settings.sculpt.brush=D;return{_C}
class SCULPTHOTBAR_OT_show_sets(Operator):
	bl_idname='sculpt_hotbar.show_sets';bl_label="Show Sculpt Hotbar's Sets";bl_description='Switch Brush-Set'
	@classmethod
	def poll(B,context):A=context;return A.mode==_F and A.scene.sculpt_hotbar.show_gizmo_sculpt_hotbar and A.scene.sculpt_hotbar.active_set
	@staticmethod
	def draw(self,context):B='render.render';self.layout.prop(get_prefs(context),'set_list');A=self.layout.column(align=_G);A.operator(B,text='Save and Create Set');A.alert=_G;A.operator(B,text='Clear Current Set');A.operator(B,text='Remove Current Set')
	def invoke(C,context,event):B=event;A=context;A.window.cursor_warp(B.mouse_region_x,B.mouse_region_y+100);A.window_manager.popover(C.__class__.draw,ui_units_x=12);return{_K}
	def execute(A,context):return{_C}
class BrushSetAction:
	bl_description='';index:IntProperty(default=-1)
	@classmethod
	def poll(B,context):A=context;return A.mode==_F and A.scene.sculpt_hotbar.sets
	def execute(A,context):A.__class__.action(context.scene.sculpt_hotbar,A.index,*A.get_action_args());return{_C}
	def get_action_args(A)->Tuple:return()
	@staticmethod
	def action(hotbar,set_index:int,*A):0
class SCULPTHOTBAR_OT_remove_set(Operator,BrushSetAction):
	bl_idname='sculpt_hotbar.remove_set';bl_label='Remove Set';bl_description='Removes Active Brush Set'
	@staticmethod
	def action(hotbar,set_index:int):hotbar.remove_set(set_index)
class SCULPTHOTBAR_OT_select_set(Operator,BrushSetAction):
	bl_idname='sculpt_hotbar.select_set';bl_label='Select Set';bl_description='Selects Brush Set'
	@staticmethod
	def action(hotbar,set_index:int):hotbar.select_set(set_index)
class SCULPTHOTBAR_OT_new_set(Operator,BrushSetAction):
	bl_idname='sculpt_hotbar.new_set';bl_label=_L;bl_description='Creates a new Brush Set'
	@staticmethod
	def action(hotbar,*A):print(_L);hotbar.new_set()
class SCULPTHOTBAR_OT_move_set(Operator,BrushSetAction):
	bl_idname='sculpt_hotbar.move_set';bl_label='Move Set';bl_description='Moves Up/Down Active Brush Set';direction:IntProperty(default=0)
	def get_action_args(A)->Tuple:return A.direction,
	@staticmethod
	def action(hotbar,set_index:int,move_direction:int):hotbar.move_set(set_index,move_direction)
class SCULPTHOTBAR_OT_set_secondary_set(Operator,BrushSetAction):
	bl_idname='sculpt_hotbar.set_secondary_set';bl_label='Set Secondary Brush-Set';bl_description='Set Secondary/Alternative Brush-Set to switch on air with [Alt] key'
	@staticmethod
	def action(hotbar,set_index:int):hotbar.select_set(set_index,secondary=_G)
class SCULPTHOTBAR_OT_swap_set(Operator,BrushSetAction):
	bl_idname='sculpt_hotbar.swap_set';bl_label='Swap Secondary Brush-Set';bl_description='Swap to Secondary/Alternative Brush-Set';enabled:BoolProperty(default=False)
	def get_action_args(A)->Tuple:return A.enabled,
	@staticmethod
	def action(hotbar,set_index:int,enabled:bool):
		if bpy.sculpt_hotbar._cv_instance:bpy.sculpt_hotbar._cv_instance.hotbar.use_secondary=enabled;bpy.context.area.tag_redraw()