bl_info={'name':'Sculpt +','author':'J. Fran Matheu (@jfranmatheu)','description':'','blender':(3,3,1),'version':(1,0,0),'location':'3D Viewport > Sculpt Mode','warning':'BETA VERSION! May be unstable!','category':'General'}
if __package__!='sculpt_plus':import sys;print("[Sculpt+] Please, rename the addon folder as 'sculpt_plus'");sys.exit(0)
import bpy
if bpy.app.background:
	print("[Sculpt+] Addon doesn't work in background!")
	def register():0
	def unregister():0
else:
	from .  import auto_load;auto_load.init()
	def register():auto_load.register()
	def unregister():auto_load.unregister()