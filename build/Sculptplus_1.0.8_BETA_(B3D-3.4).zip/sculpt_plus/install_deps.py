import subprocess,sys,os
PILL_IMPORT_ERROR=False
PILL_UPDATE_ERROR=False
def is_pil_ok()->bool:global PILL_IMPORT_ERROR;return PILL_IMPORT_ERROR
class VersionError(Exception):0
def install():
	'\n    os.system("pip3 install -r requirements.txt")\n    os.system("pip3 install -r requirements-dev.txt")\n    os.system("pip3 install -r requirements-test.txt")\n    ';G='Pillow>=9.3.0';E='install';C='pip';B='-m';A=os.path.join(sys.prefix,'bin','python.exe');F=os.path.join(sys.prefix,'lib','site-packages')
	try:
		import PIL
		if not hasattr(PIL,'__version__')or float(PIL.__version__[:-2])<9.3:print('Pillow version is too old! Requires to install a recent version...');raise VersionError('Pillow version is too old!')
	except ImportError:
		subprocess.call([A,B,'ensurepip']);subprocess.call([A,B,C,E,'--upgrade',C])
		try:subprocess.call([A,B,C,E,G,'-t',F])
		except PermissionError as D:print(D);global PILL_IMPORT_ERROR;PILL_IMPORT_ERROR=True
	except VersionError:
		try:subprocess.call([A,B,C,E,'--ignore-installed',G,'-t',F])
		except PermissionError as D:print(D);global PILL_UPDATE_ERROR;PILL_UPDATE_ERROR=True