_D=1.0
_C=True
_B=None
_A=False
from math import floor
import functools
from time import time
from datetime import datetime
from .di import DiCage,DiRct,DiBr,DiText
from mathutils import Vector
from gpu import state
from bpy.app import timers
import bpy
from bpy.app import timers
from bpy import ops as OP
from bpy.types import Brush
import functools
from sculpt_plus.utils.math import distance_between,ease_quad_in_out,lerp,lerp_smooth,map_value,point_inside_circle,smoothstep,vector
from .types import Return
from sculpt_plus.prefs import get_prefs
from .di import set_font
from sculpt_plus.lib.fonts import Fonts
from sculpt_plus.utils.gpu import OffscreenBuffer
from ..utils.gpu import LiveView
start_time=0
counter=0
fps_count=0
class Canvas:
	def __init__(A,reg)->_B:B=reg;A.size=Vector((B.width,B.height));A.pos=Vector((0,0));A.scale=_D;A.reg=B;A.mouse=Vector((0,0));A.hover_ctx=_B;A.tag_redraw=_A;A.modal_override_all=_A;A.init_ui();set_font(Fonts.NUNITO);A.draw_progress=_A;A.progress=0;A.progress_label=''
	def progress_start(A,label:str=''):A.progress=0;A.draw_progress=_C;A.progress_label=label;A.progress_time=time()
	def progress_stop(A):A.draw_progress=_A;A.progress_label='';print('[TIME] Progress Spent -> %.2f seconds'%(time()-A.progress_time))
	def progress_update(A,progress:float,label:str=''):
		B=label;A.progress=progress
		if B:A.progress_label=B
	def init_ui(A):from .wg_base import WidgetBase as B;from .wg_hotbar import Hotbar as C;from .wg_shelf import Shelf as D,ShelfDragHandle as E,ShelfSearch as F,ShelfGrid as G,ShelfGridItemInfo as H;from .wg_group_mask import MaskGroup,MaskMultiGroup as I;from .wg_group_t import TransformGroup as J;from .wg_shelf_sidebar import ShelfSidebar as K,ShelfSidebarActions as L;from .wg_ctx_switcher import SidebarContextSwitcher as M;from .wg_ctx_pie import ShelfGridItemCtxPie as N,ShelfSidebarCatCtxPie as O;from ..management.wg_modal_importer import AssetImporterModal as P,AssetImporterGrid_Inputs as Q,AssetImporterGrid_Outputs as R,AssetImporterActions as S,AssetImporterCatSelector;(A.wg_on_hover):B=_B;(A.active_wg):B=_B;(A.active_ctx_widget):B=_B;(A.hotbar):C=C(A);(A.shelf):D=D(A);(A.shelf_drag):E=E(A);(A.shelf_search):F=F(A);(A.shelf_grid):G=G(A);(A.shelf_grid_item_info):H=H(A);(A.group_mask):I=I(A);(A.group_t):J=J(A);(A.shelf_sidebar):K=K(A);(A.shelf_sidebar_actions):L=L(A);(A.shelf_ctx_switcher):M=M(A);(A.ctx_shelf_item):N=N(A);(A.ctx_shelf_sidebar_item):O=O(A);(A.mod_asset_importer):P=P(A);(A.mod_asset_importer_inputs):Q=Q(A,(0,0.5,0.0,0.85));(A.mod_asset_importer_outputs):R=R(A,(0.5,1,0.0,0.85));(A.mod_asset_importer_actions):S=S(A,text_size=16,but_spacing=32,separator_color=_B);A.children=A.hotbar,A.shelf,A.shelf_drag,A.shelf_search,A.shelf_grid,A.shelf_grid_item_info,A.shelf_sidebar,A.shelf_sidebar_actions,A.shelf_ctx_switcher,A.group_mask,A.group_t,A.ctx_shelf_item,A.ctx_shelf_sidebar_item,A.mod_asset_importer,A.mod_asset_importer_inputs,A.mod_asset_importer_outputs,A.mod_asset_importer_actions;global start_time;start_time=time()
	def update(A,off:tuple,dimensions:tuple,scale:float,prefs)->'Canvas':
		B=dimensions
		if B:A.size=Vector(B)
		if off:A.pos=Vector(off)
		A.scale=scale
		for C in A.children:C.update(A,prefs)
		return A
	def refresh(A,ctx=_B):
		if ctx:ctx.region.tag_redraw()
		else:A.reg.tag_redraw()
		A.tag_redraw=_C
	def test(A,ctx,m):return 1 if not get_prefs(ctx).first_time and A._on_hover(ctx,m)else-1
	@staticmethod
	def set_cursor(_state=_C):import bpy;bpy.context.tool_settings.sculpt.show_brush=_state
	def _on_hover(A,ctx,m):
		B=ctx
		if A.tag_redraw:OffscreenBuffer.tag_redraw(B);A.tag_redraw=_A
		A.mouse=Vector(m);A.hover_ctx=B
		if A.active_ctx_widget:A.active_ctx_widget._on_hover(B,A.mouse);return _C
		C=_A
		if A.wg_on_hover and A.wg_on_hover._is_on_hover:
			if A.wg_on_hover._on_hover(B,A.mouse):
				if A.wg_on_hover.interactable:return _C
				C=_C
		for D in reversed(A.children):
			if C and D==A.wg_on_hover:continue
			if D._on_hover(B,A.mouse):
				if C:A.wg_on_hover._is_on_hover=_A;A.wg_on_hover.on_hover_exit()
				if not A.wg_on_hover:timers.register(functools.partial(Canvas.set_cursor,_A),first_interval=0.05)
				else:A.refresh(B)
				A.wg_on_hover=D;return _C
		if C:return _C
		if A.wg_on_hover:A.refresh(B);timers.register(functools.partial(Canvas.set_cursor,_C),first_interval=0.05);A.wg_on_hover=_B
		if A.shelf.expand:return _C
		return _A
	def invoke(A,ctx,evt):
		C=ctx;B=evt
		if B.type=='LEFT_ALT':
			from sculpt_plus.props import Props as D
			if B.alt and B.value=='PRESS':D.Hotbar().use_alt=_C
			elif not B.alt and B.value=='RELEASE':D.Hotbar().use_alt=_A
			A.refresh(C);return Return.FINISH()
		if not A.wg_on_hover:
			if A.shelf.expand and not A.shelf.anim_pool and B.type in{'LEFTMOUSE','RIGHTMOUSE','ESC'}:A.shelf.expand=_A
			return Return.FINISH()
		if not A.wg_on_hover.interactable:return Return.FINISH()
		A.refresh(C);E=Vector((B.mouse_region_x,B.mouse_region_y))
		if A.wg_on_hover.invoke(C,B,A,E):A.inject_submodal(C,A.wg_on_hover);return Return.RUN()
		return Return.FINISH()
	def modal(A,ctx,evt,tweak):
		C=evt;B=ctx;A.refresh(B);D=Vector((C.mouse_region_x,C.mouse_region_y))
		if A.active_wg:
			if not A.active_wg.modal(B,C,A,D):
				A.active_wg.in_modal=_A;A.active_wg.modal_exit(B,A,A.mouse);A.active_wg=_B
				if A.active_ctx_widget is _B:return Return.FINISH()
		if A.active_ctx_widget:
			if not A.active_ctx_widget.modal(B,C,A,D):
				A.active_ctx_widget.in_modal=_A;A.active_ctx_widget.modal_exit(B,A,A.mouse);A.active_ctx_widget=_B
				if A.active_wg:A.active_wg.in_modal=_A;A.active_wg.modal_exit(B,A,A.mouse,cancel=_C);A.active_wg=_B
				return Return.FINISH()
		return Return.RUN()
	def exit(A,ctx,cancel:bool=_A):
		B=ctx;B.area.header_text_set(_B)
		if A.active_wg:A.refresh(B);A.active_wg.in_modal=_A;A.active_wg.modal_exit(B,A,A.mouse,cancel=cancel);A.active_wg=_B
		if A.active_ctx_widget:A.active_ctx_widget=_B
	def inject_submodal(A,ctx,widget):B=widget;A.active_wg=B;A.wg_on_hover=B;B.in_modal=_C;B.modal_enter(ctx,A,A.mouse);A.refresh(ctx)
	def inject_ctx_widget(A,widget,override_all:bool=_A)->_B:B=widget;A.wg_on_hover=B;B.in_modal=_C;A.active_ctx_widget=B;A.modal_override_all=override_all;A.refresh()
	def draw(A,ctx):
		B=ctx
		if get_prefs(B).first_time:DiText(Vector((10,10)),'Please, restart Blender to complete Sculpt+ installation!',32,_D,(_D,0.2,0.1,_D));return
		from gpu import state as H;H.blend_set('ALPHA');D=get_prefs(B)
		if A.active_ctx_widget and A.modal_override_all:A.active_ctx_widget._draw(B,A,A.mouse,A.scale,D);A.active_ctx_widget.draw_over(B,A,A.mouse,A.scale,D);return
		global counter;global fps_count;global start_time
		for E in A.children:E._draw(B,A,A.mouse,A.scale,D)
		for E in A.children:E.draw_over(B,A,A.mouse,A.scale,D)
		if A.draw_progress:
			F=Vector((B.region.width,B.region.height))*0.5;C=Vector((B.region.width*0.6,32*A.scale));G=F-C*0.5;DiRct(G,C,(0.05,0.05,0.05,_D));DiRct(G+Vector((3,3))*A.scale,Vector((C.x*A.progress,C.y))-Vector((6,6))*A.scale,(0.3,0.5,0.95,_D));DiCage(G,C,3.0,(0.1,0.1,0.1,_D));I=time()-A.progress_time;"\n            m = timer / 60\n            m = int(m) if m >= 1 else 0\n            if m >= 1:\n                timer -= m\n            s = int(timer)\n            ms = int((timer - s) * 100)\n            print('%i:%i:%i' % (m, s, ms))\n            ";J=datetime.fromtimestamp(I).strftime('%M:%S.%f')[:-4];DiText(F,str(int(A.progress*100))+'%  /  '+J,16,A.scale,pivot=(0.5,0.5),shadow_props={})
			if A.progress_label:DiText(F+Vector((0,(16+8)*A.scale)),A.progress_label,20,A.scale,pivot=(0.5,0),draw_rect_props={},shadow_props={})
		DiText(Vector((10,10)),'FPS: '+str(fps_count),16,_D,(_D,0.2,0.1,_D));counter+=1
		if time()-start_time>_D:fps_count=int(counter/(time()-start_time));counter=0;start_time=time()
		H.blend_set('NONE')