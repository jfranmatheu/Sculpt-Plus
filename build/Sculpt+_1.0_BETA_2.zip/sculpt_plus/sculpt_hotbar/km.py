_E='WINDOW'
_D='RELEASE'
_C='LEFT_ALT'
_B=True
_A='Sculpt'
keys='ONE','TWO','THREE','FOUR','FIVE','SIX','SEVEN','EIGHT','NINE','ZERO'
hotkeys='A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','ZERO','ONE','TWO','THREE','FOUR','FIVE','SIX','SEVEN','EIGHT','NINE','LEFT_ARROW','DOWN_ARROW','RIGHT_ARROW','UP_ARROW','LEFTMOUSE','MIDDLEMOUSE','RIGHTMOUSE','PEN','ERASER','WHEELUPMOUSE','WHEELDOWNMOUSE','WHEELINMOUSE','WHEELOUTMOUSE','RET','SPACE','BACK_SPACE','DEL','TIMER'
op='gizmogroup.gizmo_tweak'
def register():
	E='PRESS';B=False;from .ops import SCULPTHOTBAR_OT_set_brush as I;from sculpt_plus.management.operators import SCULPTPLUS_OT_set_hotbar_alt as C;from bpy import context as J;D=J.window_manager.keyconfigs.addon;F=I.bl_idname
	for (G,H) in enumerate(keys):
		if not D.keymaps.__contains__(_A):D.keymaps.new(_A,space_type='EMPTY',region_type=_E)
		A=D.keymaps[_A].keymap_items;A.new(F,H,E).properties.index=G;A.new(F,H,E,alt=_B).properties.index=G
	A.new(C.bl_idname,_C,E,alt=_B).properties.enabled=_B;A.new(C.bl_idname,_C,_D,alt=B).properties.enabled=B;A.new(C.bl_idname,_C,_D,alt=B).properties.enabled=B
def unregister():
	from .ops import SCULPTHOTBAR_OT_set_brush as C;from sculpt_plus.management.operators import SCULPTPLUS_OT_set_hotbar_alt as D;from bpy import context as E;A=E.window_manager.keyconfigs.addon;F={C.bl_idname,D.bl_idname}
	if A.keymaps.__contains__(_A):
		for B in A.keymaps[_A].keymap_items:
			if B.idname==F:A.keymaps[_A].keymap_items.remove(B)
class WidgetKM:
	@classmethod
	def setup_keymap(B,keyconfig):
		E='ANY';C=keyconfig;A=C.keymaps.get(B.bl_idname,None)
		if A and A.keymap_items and len(A.keymap_items)>1:return A
		A=C.keymaps.new(name=B.bl_idname,space_type='VIEW_3D',region_type=_E)
		for D in hotkeys:A.keymap_items.new(op,D,E,any=_B);A.keymap_items.new(op,D,_D,any=_B)
		A.keymap_items.new(op,_C,E,alt=_B);return A