_E='TEXTURE'
_D='BRUSH'
_C=False
_B=True
_A=None
from time import time
from typing import Set,List,Union
import bpy
from mathutils import Vector
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
from sculpt_plus.utils.cursor import Cursor,CursorIcon
from sculpt_plus.utils.math import ease_quad_in_out
from sculpt_plus.utils.math import clamp,point_inside_circle
from sculpt_plus.sculpt_hotbar.di import DiIcoCol,DiLine,DiText,DiRct,DiCage,DiBr,get_rect_from_text,get_text_dim,DiTriCorner,DiStar,DiIcoOpGamHl
from sculpt_plus.sculpt_hotbar.wg_view import ViewWidget
from .wg_base import WidgetBase
from sculpt_plus.lib.icons import Icon
from sculpt_plus.props import Props,Brush,Texture
SLOT_SIZE=56
HEADER_HEIGHT=32
class Shelf(WidgetBase):
	interactable:bool=_C
	def init(A)->_A:A.max_height=600;(A._expand):bool=_C;(A.margin):int=6
	@property
	def expand(self):return self._expand
	@expand.setter
	def expand(self,state:bool):
		A=self;A.cv.shelf_drag.interactable=_C
		def B():A.cv.refresh();A.cv.shelf_drag.update(A.cv,_A);A.cv.shelf_search.update(A.cv,_A);A.cv.shelf_sidebar_actions.update(A.cv,_A);A.cv.shelf_sidebar.update(A.cv,_A);A.cv.shelf_ctx_switcher.update(A.cv,_A);A.cv.shelf_grid_item_info.update(A.cv,_A)
		if state==_C:
			A.cv.shelf_grid.selected_item=_A;A.cv.shelf_grid_item_info.enabled=_C
			def C():A._expand=_C;A.cv.shelf_drag.interactable=_B
			A.resize(y=0,animate=_B,anim_change_callback=B,anim_finish_callback=C)
		else:
			A._expand=_B;A.cv.shelf_grid_item_info.enabled=_B;A.cv.shelf_grid_item_info.update(A.cv,_A)
			if A.cv.shelf_grid.type==_E:A.cv.shelf_grid_item_info.expand=_B
			def D():A._expand=_B;A.cv.shelf_drag.interactable=_B
			G:float=A.size.y*0.2;E=SLOT_SIZE*A.cv.scale;F=E*5.25;A.resize(y=F,animate=_B,anim_change_callback=B,anim_finish_callback=D)
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences):
		B=cv;A.margin=6*B.scale;A.size.x=B.hotbar.size.x;A.pos.x=B.hotbar.pos.x;A.max_height=int(A.cv.size.y*0.65);C:float=B.hotbar.size.y*0.2;D=B.hotbar.get_pos_by_relative_point(Vector((0.0,1.0)));A.pos=D;A.pos.y+=C;A.size=Vector((B.hotbar.size.x,0))
		if A.expand:A._expand=_C;A.expand=_B
	def on_leftmouse_press(A,ctx,cv:Canvas,m:Vector)->_A:0
	def on_hover_stay(A,m:Vector)->_A:
		if A.cv.shelf_grid.on_hover(m):A.cv.shelf_grid.on_hover_stay(m)
	def on_hover_exit(A)->_A:A.cv.shelf_grid.on_hover_exit()
	def draw_poll(A,context,cv:Canvas)->bool:return A.expand
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):B=prefs;DiRct(A.pos,A.size,B.theme_shelf);DiCage(A.pos,A.size,3.2*scale,Vector(B.theme_shelf)*0.9)
class ShelfGrid(ViewWidget):
	use_scissor:bool=_B;grid_slot_size:int=56;hovered_item:Union[Brush,Texture];selected_item:Union[Brush,Texture];type:str
	def init(A)->_A:super().init();(A.type):str=_D;(A.show_all_brushes):bool=_B
	def get_max_width(B,cv:Canvas,scale)->float:A=scale;return B.size.x;C=6*A;return SLOT_SIZE*A*5.25-C*2
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences):
		G=cv.shelf_grid_item_info.expand;D=cv.scale;E=A.cv.shelf.pos.copy();B=A.cv.shelf.size.copy();C=6*D;H=6*D;I=HEADER_HEIGHT*D;B.y-=I+H*2;E+=Vector((C,C));B-=Vector((C,C))*2.0
		if G:F=cv.shelf_grid_item_info.size.x;E.x+=F;B.x-=F
		A.pos=E.copy();A.size=B
	def on_left_click(A,ctx,cv:Canvas,m:Vector)->_A:return super().on_left_click(ctx,cv,m)
	def on_leftmouse_release(A,ctx,cv:Canvas,m:Vector)->_A:super().on_leftmouse_release(ctx,cv,m);return _C
	def on_double_click(A,ctx,cv:Canvas,m:Vector)->_A:
		B=ctx
		if A.hovered_item is _A:return
		if A.type==_D:
			if A.hovered_item.id in Props.GetHotbarBrushIds():Props.SetHotbarSelected(B,A.hovered_item)
			else:Props.SelectBrush(B,A.hovered_item)
		elif A.type==_E:C:Texture=A.hovered_item;C.to_brush(B)
		cv.shelf.expand=_C
	def on_rightmouse_press(A,ctx,cv:Canvas,m:Vector)->int:
		if A.hovered_item is _A:return 0
		if Props.GetActiveCat(A.type)is _A:return 0
		cv.ctx_shelf_item.show(cv,m,A.hovered_item);A.hovered_item=_A;return 1
	def on_numkey(A,ctx,number:int,cv:Canvas,m:Vector)->_A:
		B=number
		if not A.selected_item:return
		C=9 if B==0 else B-1;Props.SetHotbarBrush(C,A.selected_item);A.selected_item=_A
	def get_data(C,cv:Canvas)->list:
		A:List[Union[Brush,Texture]]=Props.GetActiveCatItems(C.type)
		if A is _A:return[]
		B=cv.shelf_search.search
		if B:B=B.lower();D={C for C in A if C.name.lower().startswith(B)};E=[C for C in A if C not in D and B in C.name.lower()];A=list(D)+E
		A.sort(key=lambda item:item.fav,reverse=_B);return A
	def draw_poll(A,context,cv:Canvas)->bool:return cv.shelf.expand and cv.shelf.size.y>A.slot_size
	def get_draw_item_args(A,context,cv:Canvas,scale:float,prefs:SCULPTPLUS_AddonPreferences)->tuple:
		B=Props.GetActiveCat(A.type)
		if B is _A:return _A
		D=Vector(prefs.theme_shelf_slot);C=Props.GetActiveBrush()if A.type==_D else Props.GetActiveTexture();return D,B.id,C.id if C else _A,Props.GetHotbarBrushIds()
	def draw_item(E,slot_p:Vector,slot_s:Vector,item:Union[Brush,Texture],is_hovered:bool,slot_color:Vector,act_cat_id:str,act_item:str,hotbar_ids:List[str],scale:float,prefs:SCULPTPLUS_AddonPreferences):
		I=hotbar_ids;H=slot_color;G=is_hovered;F=prefs;D=scale;C=item;B=slot_s;A=slot_p;J=C.id==act_item;K=C==E.selected_item;DiRct(A,B,H)
		if G:DiRct(A,B,Vector(F.theme_hotbar_slot)+Vector((0.2,0.2,0.2,0)))
		C.draw_preview(A,B,G,view_widget=E)
		if E.type==_D:
			if C.id in I:DiText(A+Vector((1,3)),str(I.index(C.id)),12,D)
		N=C.cat_id
		if N==act_cat_id:DiTriCorner(A+Vector((0.5,B.y-0.5)),B.x/5,'TOP_LEFT',(1,0.212,0.48,0.9))
		if C.fav:L=16*D;M=L/2;DiStar(A+B-Vector((M,M)),L)
		if J:DiCage(A,B,2.4*D,F.theme_active_slot_color)
		if K:DiCage(A,B,2.4*D,F.theme_selected_slot_color)
		if not J and not K:DiCage(A,B,2.4*D,H*1.3)
	def draw_post(A,_context,cv:Canvas,mouse:Vector,scale:float,_prefs:SCULPTPLUS_AddonPreferences):
		B=scale
		if cv.active_ctx_widget:DiText(A.pos,'.',1,B);DiRct(A.pos,A.size,(0.24,0.24,0.24,0.64))
		else:super().draw_post(_context,cv,mouse,B,_prefs)
class ShelfDragHandle(WidgetBase):
	modal_trigger:Set[str]={'LEFTMOUSE'};msg_on_enter:str='Click, or Press & Drag up/down to expand or hide'
	def init(A)->_A:A.start_mouse=Vector((0,0));A.end_mouse=Vector((0,0));A.tx_pos=Vector((0,0));A.dragging=_C
	def update(B,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:A:float=cv.hotbar.size.y*0.2;C:Vector=cv.shelf.get_pos_by_relative_point(Vector((0.5,1.0)));C.y+=A*1.5;B.pos=C;B.size=Vector((A*1.5,A*1.5))
	def on_hover(A,m:Vector)->bool:return point_inside_circle(m,A.pos,A.size.x)
	def start_drag(A,cv:Canvas,m:Vector):
		A.dragging=_B;A.start_mouse=m.copy();A.end_mouse=m.copy()
		if not cv.shelf.expand:cv.shelf.size=Vector((cv.hotbar.size.x,0))
	def on_drag(B,cv:Canvas,m:Vector):
		A=cv;B.end_mouse=m.copy();D:float=A.hotbar.size.y*0.2;C=A.hotbar.get_pos_by_relative_point(Vector((0.0,1.0)));C.y+=D
		if A.shelf.expand:
			if B.end_mouse.y>B.start_mouse.y or B.end_mouse.y<C.y:return
			E=max(0,B.end_mouse.y-C.y-D)
		else:
			if B.end_mouse.y<B.start_mouse.y or B.end_mouse.y<C.y:return
			E=min(max(B.end_mouse.y-B.start_mouse.y,0),25*A.scale)
		A.shelf.pos=C.copy();A.shelf.size=Vector((A.hotbar.size.x,E));A.shelf_drag.update(A,_A);A.shelf_search.update(A,_A);A.shelf_sidebar_actions.update(A,_A);A.shelf_sidebar.update(A,_A);A.shelf_ctx_switcher.update(A,_A);A.shelf_grid_item_info.update(A,_A)
	def end_drag(B,cv:Canvas):
		A=cv;B.dragging=_C;B._is_on_hover=_C;E=A.scale;C=abs(B.end_mouse.y-B.start_mouse.y);D=20*E
		if(C>D or C==0)and not A.shelf.expand:A.shelf.expand=_B
		elif(C>D or C==0)and A.shelf.expand:A.shelf.expand=_C
	def modal_enter(A,ctx,cv:Canvas,m:Vector)->_A:A.start_drag(cv,m)
	def on_mousemove(A,ctx,cv:Canvas,m:Vector)->_A:
		A.on_drag(cv,m)
		if cv.shelf.expand:ctx.area.header_text_set('Drag it down, then release to hide')
		else:ctx.area.header_text_set('Drag it up, then release to expand')
	def modal_exit(A,ctx,cv:Canvas,m:Vector,cancel:bool=_C)->_A:A.end_drag(cv)
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		G='color';F='margin';C=prefs;B=scale;H=C.theme_text if A._is_on_hover else Vector(C.theme_text)*0.75;I=(0.1,0.1,0.1,0.7)if A._is_on_hover else(0.1,0.1,0.1,0.35);J=abs(A.end_mouse.y-A.start_mouse.y);D=20*B;E=A.dragging and J>D;K=': : :'if not A.dragging else' ○ 'if E else' v 'if cv.shelf.expand else' ^ ';DiText(A.pos,K,SLOT_SIZE/4,B,H,pivot=(0.5,0),draw_rect_props={F:8,G:I},id=0)
		if not cv.shelf.expand and E:DiText(A.pos-Vector((0,D)),'Release to show Brush-Shelf',12,B,(0.92,0.92,0.92,0.7),pivot=(0.5,1),draw_rect_props={F:8,G:(0.1,0.1,0.1,0.3)})
class ShelfSearch(WidgetBase):
	use_scissor:bool=_B;cursor:CursorIcon=CursorIcon.TEXT
	def init(A)->_A:A.search='';A.type_index=0;A.modal_cancel=_C;A._expand=_C
	@property
	def expand(self):return self._expand
	@expand.setter
	def expand(self,state:bool):
		A=self
		def B():A.cv.refresh()
		if state==_C:A._expand=_C;A.resize(x=A.size.y,animate=_B,anim_change_callback=B)
		else:
			def C():A._expand=_B
			A.resize(x=A.cv.shelf_grid.size.x,animate=_B,anim_change_callback=B,anim_finish_callback=C)
	def on_hover(A,m:Vector,p:Vector=_A,s:Vector=_A)->bool:return super().on_hover(m,p,s)and A.cv.shelf.expand
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		B=HEADER_HEIGHT*cv.scale;C=6*cv.scale;A.pos=cv.shelf.get_pos_by_relative_point(Vector((0,1)));A.pos.x+=C;A.pos.y-=B+C;A.size.y=B
		if A.in_modal:A.size.x=cv.shelf_grid.size.x
		else:A.size.x=B
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		B=scale
		if not cv.shelf.expand or cv.shelf.size.y<60:return
		C=A.pos.copy();D=A.size.copy()
		if A.in_modal or A.anim_pool:
			F=0.08,0.08,0.08,0.9;DiRct(C,D,F);DiCage(C,D,2.2*B,(0.2,0.5,0.9,0.8));E=C+Vector((10,D.y*0.32));G=time();G=round(G%1,2);H=min(3,int(G/0.25));I=G<0.5;J='Start Typing '+''.join(['.']*H)+('|'if I else'');DiText(E,A.search if A.search else J,16,B)
			if A.search:K=get_text_dim(A.search[:A.type_index],16,B);E+=Vector((K[0],-4*B));DiLine(E,E+Vector((0,20*B)),1.6*B,(0.1,0.1,0.1,0.7));DiLine(E,E+Vector((0,20*B)),1.3*B,(0.7,0.7,0.7,0.7))
		elif A._is_on_hover:F=0.2,0.2,0.2,0.8;DiRct(C,D,F);DiCage(C,D,2.2*B,Vector(F)*0.8);DiIcoCol(C,D,Icon.SEARCH,(0.9,0.9,0.9,0.9))
		else:DiIcoCol(C,D,Icon.SEARCH,(0.9,0.9,0.9,0.6))
	def on_left_click(A,ctx,cv:Canvas,m:Vector)->bool:return _B
	def modal_enter(A,ctx,cv:Canvas,m:Vector)->_A:A.expand=_B
	def modal_exit(A,ctx,cv:Canvas,m:Vector,cancel:bool=_C)->_A:
		A.expand=_C
		if A.modal_cancel or cancel:A.modal_cancel=_C;A.search=''
	def modal(A,ctx,evt,cv:Canvas,m:Vector)->bool:
		C='RET';B=evt
		if B.type in{'ESC',C,'RIGHTMOUSE'}:
			A.modal_cancel=_B
			if B.type!=C:A.search=''
			return _C
		if B.value!='PRESS':return _B
		if B.type=='LEFT_ARROW':A.type_index=clamp(A.type_index-1,0,len(A.search));return _B
		if B.type=='RIGHT_ARROW':A.type_index=clamp(A.type_index+1,0,len(A.search));return _B
		if B.type=='DEL':
			if len(A.search)==A.type_index:return _B
			else:A.search=A.search[:A.type_index]+A.search[A.type_index+1:]
			return _B
		if B.type=='BACK_SPACE':
			if A.type_index==0:return _B
			if len(A.search)==A.type_index:A.search=A.search[:-1]
			else:A.search=A.search[:A.type_index-1]+A.search[A.type_index:]
			A.type_index-=1;return _B
		if not B.unicode and not B.ascii:return _B
		if len(A.search)==A.type_index:A.search+=B.unicode
		else:A.search=A.search[:A.type_index]+B.unicode+A.search[A.type_index:]
		A.type_index+=1;return _B
class ShelfGridItemInfo(WidgetBase):
	def init(A)->_A:A._expand=_C;A.max_width=1;A._anim_running=_C
	@property
	def expand(self)->bool:return self._expand
	@expand.setter
	def expand(self,value:bool)->_A:
		A=self;B=A.cv
		def C():A.cv.refresh();B.shelf_grid.update(B,_A)
		if value:
			A._expand=_B
			def D():A._anim_running=_C;A.update(B,_A)
			A.resize(A.max_width,animate=_B,anim_change_callback=C,anim_finish_callback=D)
		else:
			def E():A._anim_running=_C;A._expand=_C;A.update(B,_A)
			A._anim_running=_B;A.resize(0,animate=_B,anim_change_callback=C,anim_finish_callback=E)
	def poll(A,_context,cv:Canvas)->bool:return A.expand and cv.shelf.expand and A.size.y>10
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		if not A.expand and not A.anim_running():A.pos=cv.shelf_grid.pos.copy();A.size=Vector((0,cv.shelf_grid.size.y));return
		C=cv.scale;B=A.cv.shelf.pos.copy();B.x+=6*C;B.y+=6*C;A.pos=B;A.size=Vector((A.size.x,cv.shelf_grid.size.y));A.max_width=A.cv.hotbar.size.x*0.215
	def draw(C,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		H=scale;DiText(C.pos,'.',1,1,(0.1,0.1,0.1,1));A=min(max(C.size.x/C.max_width,0),1);A=ease_quad_in_out(-0.25,1,A);G=6*H*2;E=5*H;K=C.pos.copy()
		if C._anim_running:D=Vector((C.max_width-G,C.size.y))
		else:D=C.size.copy()-Vector((G,0))
		DiRct(C.pos,D,(0.04,0.04,0.04,0.32*A));DiLine(K+Vector((D.x,0)),K+D,2.4,(0.5,0.5,0.5,0.64*A));DiLine(K+Vector((D.x,0)),K+D,1.2,(0.1,0.1,0.1,0.64*A));L=Props.GetActiveBrush();D-=Vector((G+E*2,E*2));M=get_text_dim('O',12,H)[1]+G;I=(D.y-M*2-G*2)/2
		if I>D.x:I=D.x
		F=Vector((I,I));B=C.get_pos_by_relative_point(Vector((0,1)))-Vector((0,F.x));B+=Vector((E,-E))
		def N(p,s,act:bool,opacity:float):DiBr(p,s,L.sculpt_tool,act,opacity)
		if L:L.draw_preview(B,F,_C,fallback=N,opacity=A);J=L.name
		else:DiRct(B,F,(0.05,0.05,0.05,0.4*A));DiCage(B,F,1.5,(0.05,0.05,0.65*A));DiIcoCol(B+Vector((E,E)),F-Vector((E,E))*2,Icon.PAINT_BRUSH,(0.8,0.8,0.8,1*A));J='No Active Brush'
		B-=Vector((0,M));DiText(B,J,12,H,(0.92,0.92,0.92,A));B-=Vector((0,I+G*2))
		def N(p,s,act:bool,opacity:float):DiIcoOpGamHl(p,s,Icon.TEXTURE,opacity)
		O=Props.GetActiveTexture()
		if O:J=O.name;O.draw_preview(B,F,act=_C,opacity=A)
		else:J='No Texture';N(B,F,_C,opacity=A)
		B-=Vector((0,M));DiText(B,J,12,H,(0.92,0.92,0.92,A))