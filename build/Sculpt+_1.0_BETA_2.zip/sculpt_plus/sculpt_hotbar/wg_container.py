_B=False
_A=None
from .wg_base import WidgetBase,Canvas,Vector,SCULPTPLUS_AddonPreferences
class WidgetContainer(WidgetBase):
	def __init__(A,canvas:Canvas,pos:Vector=Vector((0,0)),size:Vector=Vector((0,0)))->_A:A.hovered_widget=_A;A.modal_widget=_A;(A._children):list[WidgetBase]=[];super().__init__(canvas,pos,size)
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		B=prefs
		if not A.enabled:return _B
		super().update(cv,B)
		for C in A._children:C.update(cv,B)
	def add_child(A,widget:WidgetBase)->_A:B=widget;A._children.append(B);B.parent=A
	def remove_child(B,widget:WidgetBase)->_A:A=widget;B._children.remove(A);A.parent=_A
	def on_hover(A,m)->bool:
		if not A.enabled:return _B
		if A.hovered_widget:
			if not A.hovered_widget.on_hover(m):A.hovered_widget=_A
		if super().on_hover(m):
			for B in A._children:
				C=B.on_hover(m)
				if C:A.hovered_widget=B;return True
		A.hovered_widget=_A;return _B
	def on_hover_exit(A)->_A:
		if A.hovered_widget:A.hovered_widget.on_hover_exit();A.hovered_widget=_A
	def invoke(A,ctx,evt,cv:Canvas,m:Vector)->bool:
		if not A.enabled:return _B
		if A.hovered_widget is _A:return _B
		return A.hovered_widget.invoke(ctx,evt,cv,m)
	def modal_enter(A,ctx,cv:Canvas,m:Vector)->_A:A.modal_widget=A.hovered_widget;A.modal_widget.modal_enter(ctx,cv,m)
	def modal(A,ctx,evt,cv:Canvas,m:Vector)->bool:
		if A.modal_widget is _A:return _B
		return A.modal_widget.modal(ctx,evt,cv,m)
	def modal_exit(A,ctx,cv:Canvas,m:Vector,cancel:bool=_B)->_A:A.modal_widget.modal_exit(ctx,cv,m,cancel=cancel);A.modal_widget=_A
	def draw_container(A,context,cv:Canvas,scale:float,prefs:SCULPTPLUS_AddonPreferences):0
	def _draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		E=prefs;D=scale;C=mouse;B=context;super()._draw(B,cv,C,D,E)
		if A.enabled:
			for F in A._children:F._draw(B,cv,C,D,E)
class WidgetContainerChild(WidgetBase):parent:WidgetContainer