def install():
	'\n    os.system("pip3 install -r requirements.txt")\n    os.system("pip3 install -r requirements-dev.txt")\n    os.system("pip3 install -r requirements-test.txt")\n    ';E='install';D='pip';C='-m'
	try:
		import PIL
		if not hasattr(PIL,'__version__')or float(PIL.__version__[:-2])<9.4:print('Pillow version is too old! Requires to install a recent version...');raise ImportError('Pillow version is too old!')
	except ImportError:import subprocess as A;import sys;import os;B=os.path.join(sys.prefix,'bin','python.exe');F=os.path.join(sys.prefix,'lib','site-packages');A.call([B,C,'ensurepip']);A.call([B,C,D,E,'--upgrade',D]);A.call([B,C,D,E,'Pillow>=9.4.0','-t',F])