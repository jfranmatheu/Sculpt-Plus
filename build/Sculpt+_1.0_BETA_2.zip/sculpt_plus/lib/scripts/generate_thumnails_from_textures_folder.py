_B='.jpg'
_A='PIL'
from time import time
from pathlib import Path
import shutil
from math import floor
import sys
from bpy.types import Image as BlImage
import imbuf,bpy
from PIL import Image
import numpy as np
LEADERBOARD={'IMBUF':135,_A:334,'BlImage':131}
TEXTURES_FOLDER=Path('D:\\B3D Asset Library\\Brushes\\Blender_Brushes_Stylized\\Textures\\Alphas')
OUTPUT_FOLDER=TEXTURES_FOLDER/'Thumbnails'
THUMBNAIL_SIZE=100,100
THUMBNAIL_PIXEL_SIZE=THUMBNAIL_SIZE[0]*THUMBNAIL_SIZE[1]*4
IMAGE_FILE_FORMATS=_B,'.jpeg','.png','.bmp','.tiff','.tif','.tga'
IMBUF_RESIZE_METHOD='FAST'
PIL_TIF_FACTOR_MULT=1.0/256
REZIZE_METHODS=_A,
RESIZE_METHOD=_A
data_images=bpy.data.images
THUMBNAIL_BLIMAGE=data_images.new('.thumbnail',*(THUMBNAIL_SIZE))
IS_WINDOWS_PLATFORM=sys.platform=='Windows'
def _is_image_file(filename:str)->bool:return filename.endswith(IMAGE_FILE_FORMATS)
def get_images_in_directory(directory:Path)->list[Path]:
	B=[]
	for A in directory.iterdir():
		if A.is_dir():B+=get_images_in_directory(A)
		elif _is_image_file(A.name):B.append(A)
	return B
def _get_thumbnail_path(image_path:Path,ext=_B)->Path:return OUTPUT_FOLDER/(image_path.stem+'thumbnail'+ext)
def _remove_exif(image_path:Path,image:Image):
	C=image_path;A=image
	if not A.getexif():return A
	print('removing EXIF from',C.name,'...');D=list(A.getdata());B=Image.new(A.mode,A.size);B.putdata(D);B.save(C);return B
class ResizeImage:
	@staticmethod
	def imbuf(image_path:Path):B=image_path;A=imbuf.load(str(B));A.resize(THUMBNAIL_SIZE,method=IMBUF_RESIZE_METHOD);imbuf.write(A,filepath=str(_get_thumbnail_path(B)));A.free();del A
	@staticmethod
	def pil(image_path:Path):
		B=image_path;A=Image.open(str(B))
		if B.suffix in{'.tif','.tiff'}:format=A.format;C=B.suffix;D={}
		else:format='JPEG';C=_B;D={'optimize':True,'quality':80}
		A.thumbnail(THUMBNAIL_SIZE,resample=Image.Resampling.NEAREST);A.save(_get_thumbnail_path(B,ext=C),format=format,**D)
		if IS_WINDOWS_PLATFORM:
			try:A.close()
			except OSError as E:pass
		else:A.close()
		del A
	@staticmethod
	def blimage(image_path:Path):D=image_path;B:BlImage=data_images.load(str(D));B.scale(*(THUMBNAIL_SIZE));C=np.empty(THUMBNAIL_PIXEL_SIZE,dtype=np.float32);B.pixels.foreach_get(C);A:BlImage=THUMBNAIL_BLIMAGE.copy();A.filepath_raw=str(_get_thumbnail_path(D));A.pixels.foreach_set(C);A.save();del B;del A;del C
image_paths:list[Path]=get_images_in_directory(TEXTURES_FOLDER)
for METHOD in REZIZE_METHODS:
	OUTPUT_FOLDER.mkdir(exist_ok=True);resize_function:callable=getattr(ResizeImage,METHOD.lower());allow_multiprocess=METHOD in{_A}
	if allow_multiprocess:
		from threading import Thread;from multiprocessing import cpu_count;thread_count=int(cpu_count()/4);start_time=time();tot_images=len(image_paths);_images_per_thread=tot_images/thread_count;images_per_thread=[floor(_images_per_thread)]*thread_count
		if _images_per_thread%1!=0:images_per_thread[0]+=int(_images_per_thread%1*thread_count)
		def resize_images(image_paths:list[Path],resize_function:callable):
			for A in image_paths:resize_function(A)
		threads=[];image_path_index=0
		for image_count in images_per_thread:thread=Thread(target=resize_images,args=(image_paths[image_path_index:image_path_index+image_count],resize_function),daemon=True);image_path_index+=image_count;threads.append(thread)
		for thread in threads:thread.start()
		for thread in threads:thread.join()
		time_to_finish=time()-start_time;print(f"Processed {tot_images} images in {round(time_to_finish,2)} seconds.")
	else:
		images_processed_count:int=0;start_time=time()
		for image_path in image_paths:
			resize_function(image_path);images_processed_count+=1
			if time()-start_time>60:break
		print(f"Method {METHOD}, processed {images_processed_count} images in {round(time()-start_time,2)} seconds.")
	shutil.rmtree(OUTPUT_FOLDER)