_C='================================'
_B=None
_A=False
from pathlib import Path
import sys
from math import floor
from threading import Thread
from multiprocessing import cpu_count
from bpy import ops as OP
from bpy import data as D
from bpy.path import abspath
from sculpt_plus.path import DBShelfManager
from sculpt_plus.props import builtin_brushes,Brush,Texture
from sculpt_plus.core.sockets.pbar_client import PBarClient
" Get Command Arguments.\nCalled from Blender.\n\nCommand arguments:\n0. b3d exec.\n1. blendlib path.\n2. --background flag.\n3. --python flag.\n4. script path.\n5. '--' empty break flag.\n6. Socket communication PORT.\n"
argv=sys.argv
PYTHON_EXEC=argv[0]
BLENDLIB_FILEPATH=argv[1]
THIS_SCRIPT_FILEPATH=argv[4]
SOCKET_PORT=int(argv[-1])
USE_DEBUG='--debug'in argv
if USE_DEBUG:from bpy.types import Brush as BlBrush,ImageTexture as BlImageTexture;from time import time;print(argv);start_time=time();print('[Sculpt+][SUB::ExportBrushesFromBlendlib] START')
else:BlBrush=_B;BlImageTexture=_B
COMPATIBLE_IMAGE_EXTENSIONS={'PNG','JPG','JPEG','TGA','TIFF','TIF','PSD'}
def insert_custom_property(ID,name:str,value)->_B:ID[name]=value
def verify_brush_texture(bl_brush:BlBrush)->bool:
	A=bl_brush
	if A.texture is _B:print('\t- Brush has not texture ->',A.name);return _A
	if A.texture.type!='IMAGE':print('\t- Brush Texture is not image type ->',A.name,A.texture.name);return _A
	B=A.texture.image
	if B is _B:print('\t- Brush Texture has no image ->',A.name,A.texture.name);return _A
	if B.source not in{'FILE','SEQUENCE'}:print('\t- Invalid Blender image source ->',B.name);return _A
	C=B.filepath_raw
	if not C:print('\t- Invalid image filepath! ->',B.name);return _A
	C=Path(C)
	if not C.exists()or not C.is_file():print('\t- Could not find image in path! ->',B.name,str(C));return _A
	return True
' Create a client Socket to communicate the progress to the invoker process. '
client_progress=PBarClient(port=SOCKET_PORT)
client_progress.start()
' Get sculpt brushes. Ignore builtin brushes. '
brushes:list[BlBrush]=[A for A in D.brushes if A.use_paint_sculpt and A.name not in builtin_brushes]
' Count will be useful to determine the interval for progress reporting.\n    As well as to split brushes in several async loops for concurrent or parallel processing.'
brush_count:int=len(brushes)
client_progress.set_increment_rate(step_count=brush_count+1)
' Unpack all images from brush textures packed in the .blend library. '
OP.file.unpack_all()
OP.file.make_paths_absolute()
' MULTI-THREADING '
brush_items:list[Brush]=[]
def new_brush_item(bl_brush:BlBrush)->Brush:
	A=bl_brush;client_progress.increase()
	if USE_DEBUG:print('\t- Creating brush',A.name)
	return Brush(A,fake_brush=_B)
def new_texture_item(bl_texture:BlImageTexture)->Texture:return Texture(bl_texture,fake_texture=_B)
def run_thread(input_bl_brushes:list[BlBrush]):
	if USE_DEBUG:print('[Sculpt+][SUB::ExportBrushesFromBlendlib] Start Thread')
	for B in input_bl_brushes:
		A:Brush=new_brush_item(B)
		if verify_brush_texture(B):C:Texture=new_texture_item(B.texture);C.thumbnail.set_filepath(C.image.filepath_raw,lazy_generate=_A);A.attach_texture(C)
		if A.use_custom_icon:
			A.icon_filepath=abspath(A.icon_filepath);D:Path=Path(A.icon_filepath)
			if not D.exists()or not D.is_file():A.icon_filepath='';A.use_custom_icon=_A
			else:A.thumbnail.set_filepath(A.icon_filepath,lazy_generate=_A)
		brush_items.append(A)
	print('[Sculpt+][SUB::ExportBrushesFromBlendlib] Finish Thread')
min_brushes_per_thread=10
thread_count:int=int(cpu_count()/2)
if thread_count>brush_count/min_brushes_per_thread:thread_count=floor(brush_count/min_brushes_per_thread)
_brushes_per_loop:int=brush_count/thread_count
brushes_per_loop=[floor(_brushes_per_loop)]*thread_count
if _brushes_per_loop%1!=0:brushes_per_loop[0]+=int(_brushes_per_loop%1*thread_count)
if USE_DEBUG:print('[Sculpt+][SUB::ExportBrushesFromBlendlib] - Total threads ->',thread_count)
threads:list[Thread]=[]
index=0
for count in brushes_per_loop:thread=Thread(target=run_thread,args=(brushes[index:index+count],),daemon=_A);index+=count;threads.append(thread)
for thread in threads:thread.start()
for thread in threads:thread.join()
' Write to the shelve temporal database\n    all retrieved items from async loops. '
with DBShelfManager.TEMPORAL(cleanup=True)as db_temp:{db_temp.write(A)for A in brush_items}
client_progress.complete(stop=True)
if USE_DEBUG:print(_C);print('[TIME] Finished in %.2f seconds'%(time()-start_time));print(_C)