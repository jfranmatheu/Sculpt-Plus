_B='FINISHED'
_A='SCULPT'
from bpy.types import Operator
from bpy.props import FloatProperty,BoolProperty
class SCULPTPLUS_OT_remesh_voxel_increase_size(Operator):
	bl_idname='sculpt_plus.remesh_voxel_increase_size';bl_label='De/Increase Voxel Size';bl_description='Decrease/Increase Remesh Voxel Size by a given value';value:FloatProperty(default=0,name='Value')
	@classmethod
	def poll(B,context):A=context;return A.mode==_A and A.sculpt_object is not None
	def execute(A,context):context.sculpt_object.data.remesh_voxel_size+=A.value;return{_B}
class SCULPTPLUS_OT_remesh_voxel_increase_density(Operator):
	bl_idname='sculpt_plus.remesh_voxel_increase_density';bl_label='De/Increase Voxel Size by density';bl_description='Decrease/Increase Remesh Voxel Size by density porcentage change';value:FloatProperty(default=0,name='Percentage Value')
	@classmethod
	def poll(B,context):A=context;return A.mode==_A and A.sculpt_object is not None
	def execute(B,context):A=context;A.sculpt_object.data.remesh_voxel_size-=A.sculpt_object.data.remesh_voxel_size*B.value/100;return{_B}