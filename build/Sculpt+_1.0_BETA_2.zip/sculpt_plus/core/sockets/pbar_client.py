_A=None
from ._socket_client import SocketClient
class PBarClient(SocketClient):
	progress:float;progress_increment_rate:float
	def init(A)->_A:A.progress_cumulative=0;A.progress=0;A.progress_increment_rate=0
	def set_increment_rate(A,step_count:int=100)->_A:A.progress_increment_rate=1.0/step_count
	def set_progress(A,progress:float)->_A:
		B=progress;A.progress_cumulative=B
		if B-A.progress<0.01 and B<1.0:return
		A.progress=B
		if A.progress>=1.0:A.progress=1.0
		try:A.send_data()
		except ConnectionAbortedError as C:print(C);A.stop()
	def complete(A,stop:bool=False)->_A:
		A.set_progress(1.0)
		if stop:A.stop()
	def update(A,progress:float)->_A:A.set_progress(progress*A.progress_increment_rate)
	def increase(A)->_A:A.set_progress(A.progress_cumulative+A.progress_increment_rate)
	def prepare_data(A)->tuple:return int(A.progress*100),