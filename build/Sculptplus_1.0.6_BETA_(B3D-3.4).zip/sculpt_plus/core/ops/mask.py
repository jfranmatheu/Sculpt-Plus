_C='INVERT'
_B='DRAW_2D'
_A=False
from bpy import ops as OPS
from mathutils import Vector
from sculpt_plus.utils.operator import create_op_props_popup_wrapper,create_op_modal_exec_wrapper
from sculpt_plus.sculpt_hotbar.di import DiText
from sculpt_plus.prefs import get_prefs
class SCULPTPLUS_OT_mask_slice_wrapper:
	bl_idname='sculpt_plus.mask_slice_wrapper';bl_label='Mask Slice'
	def post_execute(B,context):
		A='SCULPT'
		if context.mode!=A:OPS.object.mode_set(_A,mode=A)
class SCULPTPLUS_OT_mask_expand_normal_wrapper:
	bl_idname='sculpt_plus.mask_expand_normal_wrapper';bl_label='Mask Expand by Normals';options={_B}
	def post_modal(A,context,event):0
	def pre_execute(A,context):
		if A.invert:OPS.paint.mask_flood_fill(_A,mode=_C)
	def draw_2d(E,context):A=context;B=get_prefs(A).get_scale(A);C=A.region.width/2;D=A.region.height-64*B;DiText(Vector((C,D)),'Left-Click over mesh surface to start expanding a Mask by normals',24,B,pivot=(0.5,1),draw_rect_props={})
class SCULPTPLUS_OT_mask_expand_wrapper:
	bl_idname='sculpt_plus.mask_expand_wrapper';bl_label='Mask Expand by Topology';options={_B}
	def post_modal(A,context,event):0
	def pre_execute(A,context):
		if A.invert:OPS.paint.mask_flood_fill(_A,mode=_C)
	def draw_2d(E,context):A=context;B=get_prefs(A).get_scale(A);C=A.region.width/2;D=A.region.height-64*B;DiText(Vector((C,D)),'Left-Click over mesh surface to start expanding a Mask by topology',24,B,pivot=(0.5,0),draw_rect_props={})
def register():F='edge_sensitivity';E='create_face_set';D='invert';C='keep_previous_mask';B='use_normals';A=True;create_op_props_popup_wrapper(OPS.mesh.paint_mask_slice,SCULPTPLUS_OT_mask_slice_wrapper);create_op_modal_exec_wrapper(OPS.sculpt.mask_expand,SCULPTPLUS_OT_mask_expand_wrapper,props_overwrite={B:_A,C:A,D:_A,E:_A,F:2000},copy_props=A);create_op_modal_exec_wrapper(OPS.sculpt.mask_expand,SCULPTPLUS_OT_mask_expand_normal_wrapper,props_overwrite={B:A,C:A,D:_A,E:_A,F:2000,'smooth_iterations':0},copy_props=A)