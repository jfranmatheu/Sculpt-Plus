import bpy
from bpy.types import WorkSpaceTool,Operator
class SCULPTPLUS_OT_all_brush_tool(Operator):
	bl_idname:str='sculpt_plus.all_brush_tool';bl_label:str='All Brush Tool';bl_description:str=''
	def execute(L,context):
		D='CANCELLED';C=context;from .override_tools import accept_brush_tools as G,ToolSelectPanelHelper as E;from sculpt_plus.props import Props as B
		if C.space_data is None:return{D}
		F=B.BrushManager().active_sculpt_tool
		try:A=E._tool_active_from_context(C,'VIEW_3D',mode='SCULPT',create=False)
		except AttributeError as H:print('[SCULPT+] WARN!',H);return{D}
		if A is None:print('[SCULPT+] WARN! Current active tool is NULL');return{D}
		type,A=A.idname.split('.');A=A.replace(' ','_').upper()
		if F!=A:
			print(f"Info! Changed tool from {F} to {A}.");I:bool=A not in G and type=='builtin_brush'
			if I:B.BrushManager().active_sculpt_tool=A;return{D}
			print('Sculpt Brush! All for One, One for All!');bpy.ops.wm.tool_set_by_id(name='builtin_brush.Draw')
			if(J:=B.GetActiveBrush()):B.SelectBrush(C,J)
			elif(K:=list(B.BrushManager().brushes.values())):B.SelectBrush(C,K[0])
			A=E.tool_active_from_context(C);A=A.idname.split('.')[1].replace(' ','_').upper();B.BrushManager().active_sculpt_tool=A
		return{'FINISHED'}
'\nclass MyTool(WorkSpaceTool):\n    bl_space_type = \'VIEW_3D\'\n    bl_context_mode = \'SCULPT\'\n\n    # The prefix of the idname should be your add-on name.\n    bl_idname = "builtin_brush.all_brush"\n    bl_label = "All Brush"\n    bl_description = (\n        "Unified Brush Tool\n"\n        "Bye Bye to a lot of messy brushes here!"\n    )\n    bl_icon = "brush.gpencil_draw.draw"\n    bl_widget = None\n    bl_keymap = (\n        ("sculpt_plus.all_brush_tool", {"type": \'MOVEMOUSE\', "value": \'ANY\'},\n         {})\n    )\n\n    def draw_settings(context, layout, tool):\n        pass\n'
'\nclass MyOtherTool(WorkSpaceTool):\n    bl_space_type = \'VIEW_3D\'\n    bl_context_mode = \'OBJECT\'\n\n    bl_idname = "my_template.my_other_select"\n    bl_label = "My Lasso Tool Select"\n    bl_description = (\n        "This is a tooltip\n"\n        "with multiple lines"\n    )\n    bl_icon = "ops.generic.select_lasso"\n    bl_widget = None\n    bl_keymap = (\n        ("view3d.select_lasso", {"type": \'LEFTMOUSE\', "value": \'PRESS\'}, None),\n        ("view3d.select_lasso", {"type": \'LEFTMOUSE\', "value": \'PRESS\', "ctrl": True},\n         {"properties": [("mode", \'SUB\')]}),\n    )\n\n    def draw_settings(context, layout, tool):\n        props = tool.operator_properties("view3d.select_lasso")\n        layout.prop(props, "mode")\n\n\nclass MyWidgetTool(WorkSpaceTool):\n    bl_space_type = \'VIEW_3D\'\n    bl_context_mode = \'OBJECT\'\n\n    bl_idname = "my_template.my_gizmo_translate"\n    bl_label = "My Gizmo Tool"\n    bl_description = "Short description"\n    bl_icon = "ops.transform.translate"\n    bl_widget = "VIEW3D_GGT_tool_generic_handle_free"\n    bl_widget_properties = [\n        ("radius", 75.0),\n        ("backdrop_fill_alpha", 0.0),\n    ]\n    bl_keymap = (\n        ("transform.translate", {"type": \'LEFTMOUSE\', "value": \'PRESS\'}, None),\n    )\n\n    def draw_settings(context, layout, tool):\n        props = tool.operator_properties("transform.translate")\n        layout.prop(props, "mode")\n'