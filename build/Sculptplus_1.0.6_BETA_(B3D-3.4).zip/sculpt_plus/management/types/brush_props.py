_K='smear_deform_type'
_J='deform_target'
_I='invert_to_scrape_fill'
_H='area_radius_factor'
_G='use_persistent'
_F='tip_roundness'
_E='normal_weight'
_D='crease_pinch_factor'
_C='use_plane_trim'
_B='plane_trim'
_A='plane_offset'
import bpy
from bpy.types import Property,BrushCapabilitiesSculpt,BrushCapabilities,BrushCurvesSculptSettings,BrushTextureSlot,Brush as BlBrush,Image as BlImage,Texture as BlTexture
from typing import Dict,Tuple,List,Set,Union
from .generated import BaseBrush
brush_properties:Dict[str,Property]=lambda:bpy.types.Brush.bl_rna.properties
exclude_properties:Set[str]=set()
sculpt_tool_items:Tuple[str]=tuple((A.identifier for A in BlBrush.bl_rna.properties['sculpt_tool'].enum_items))
specific_brush_properties={'DRAW':{},'DRAW_SHARP':{},'CLAY':{_A,_B,_C},'CLAY_STRIPS':{_A,_B,_C,_F},'CLAY_THUMB':{_A,_B,_C},'LAYER':{'height',_G},'INFLATE':{},'BLOB':{_D},'CREASE':{_D},'SMOOTH':{'smooth_deform_type','surface_smooth_shape_preservation','surface_smooth_current_vertex','surface_smooth_iterations'},'FLATTEN':{_A,_B,_C},'FILL':{_A,_B,_C,_H,_I},'SCRAPE':{_A,_B,_C,_H,_I},'MULTIPLANE_SCRAPE':{'multiplane_scrape_angle','use_multiplane_scrape_dynamic','show_multiplane_scrape_planes_preview'},'PINCH':{},'GRAB':{_E,'use_grab_active_vertex','use_grab_silhouette'},'ELASTIC_DEFORM':{_E,'elastic_deform_type','elastic_deform_volume_preservation'},'SNAKE_HOOK':{_E,_D,'rake_factor','snake_hook_deform_type'},'THUMB':{},'POSE':{_J,'pose_deform_type','pose_origin_type','pose_smooth_iterations','pose_ik_segments','pose_offset','use_pose_ik_anchored','use_connected_only','disconnected_distance_max'},'NUDGE':{},'ROTATE':{},'TOPOLOGY':{'slide_deform_type'},'BOUNDARY':{_J,'boundary_deform_type','boundary_falloff_type','boundary_offset'},'CLOTH':{_G,'cloth_simulation_area_type','cloth_sim_limit','cloth_sim_falloff','use_cloth_pin_simulation_boundary','cloth_deform_type','cloth_force_falloff_type','cloth_mass','cloth_damping','cloth_constraint_softbody_strength','use_cloth_collision'},'SIMPLIFY':{},'MASK':{'mask_tool'},'DRAW_FACE_SETS':{},'DISPLACEMENT':{},'DISPLACEMENT_ERASER':{},'DISPLACEMENT_SMEAR':{_K},'PAINT':{'color','secondary_color','blend','flow','wet_mix','wet_persistence','wet_paint_radius_factor','density',_F,'tip_scale_x','use_flow_pressure','invert_flow_pressure','use_wet_mix_pressure','invert_wet_mix_pressure','use_wet_persistence_pressure','invert_wet_persistence_pressure','use_density_pressure','invert_density_pressure','color_type','gradient_stroke_mode'},'SMEAR':{_K}}
all_specific_brush_properties:Set[str]=set()
for group_attr in specific_brush_properties.values():
	if group_attr:all_specific_brush_properties.update(group_attr)
brush_properties_minus_specific:Set[str]=set(BaseBrush._attributes).difference(all_specific_brush_properties).difference(exclude_properties)
brush_properties_minus_specific.remove('direction')
brush_properties_per_sculpt_type:Dict[str,Tuple[str]]={A:brush_properties_minus_specific.union(specific_brush_properties[A])for A in sculpt_tool_items}