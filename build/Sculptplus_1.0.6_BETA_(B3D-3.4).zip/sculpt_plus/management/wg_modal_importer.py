_G=True
_F='OUTPUT'
_E='INPUT'
_D=False
_C='TEXTURE'
_B='BRUSH'
_A=None
from sculpt_plus.sculpt_hotbar.wg_container import Canvas,Vector,SCULPTPLUS_AddonPreferences,WidgetContainer,WidgetBase
from sculpt_plus.sculpt_hotbar.wg_view import ViewWidget
from sculpt_plus.management.types.fake_item import FakeViewItem_Brush,FakeViewItem_Texture,FakeViewItem
from sculpt_plus.sculpt_hotbar.wg_but import Button,ButtonGroup
from sculpt_plus.sculpt_hotbar.wg_selector import WidgetSelector
from sculpt_plus.management.types.image import Thumbnail
from sculpt_plus.sculpt_hotbar.di import DiRct,DiCage,DiIma,DiIcoCol,DiIco,DiText,DiIcoOpGamHl,DiImaOpGamHl,DiBr
from sculpt_plus.utils.gpu import gputex_from_image_file
from sculpt_plus.lib.icons import Icon
from sculpt_plus.props import Props,Brush,Texture
from sculpt_plus.path import DBShelfManager,DBShelfPaths,ScriptPaths,SculptPlusPaths
import bpy
from typing import Union
import subprocess
from time import time
from os.path import basename
class AssetImporterModal(WidgetBase):
	interactable:bool=_D
	def init(A)->_A:A.enabled=_D;(A.lib_path):str=_A;A.input_brushes=[];A.input_textures=[];A.output_brushes=[];A.output_textures=[];A.ctx_type=_B;A.use_fake_items=_D
	def on_hover(A,m:Vector,p:Vector=_A,s:Vector=_A)->bool:return _G
	def pass_item(A,item:Union[FakeViewItem_Brush,FakeViewItem_Texture],move_to:str)->_A:
		C=move_to;B=item
		if A.ctx_type==_B:
			if C==_E:A.input_brushes.append(A.output_brushes.pop(A.output_brushes.index(B)))
			elif C==_F:A.output_brushes.append(A.input_brushes.pop(A.input_brushes.index(B)))
		elif A.ctx_type==_C:
			if C==_E:A.input_textures.append(A.output_textures.pop(A.output_textures.index(B)))
			elif C==_F:A.output_textures.append(A.input_textures.pop(A.input_textures.index(B)))
	def pass_all_items(A,move_to:str)->_A:
		B=move_to
		if A.ctx_type==_B:
			if B==_E:A.input_brushes,A.output_brushes=A.output_brushes,A.input_brushes
			elif B==_F:A.output_brushes,A.input_brushes=A.input_brushes,A.output_brushes
		elif A.ctx_type==_C:
			if B==_E:A.input_textures,A.output_textures=A.output_textures,A.input_textures
			elif B==_F:A.output_textures,A.input_brushes=A.input_brushes,A.output_textures
	def show(A,lib_path:str,type:str,data:Union[list[Brush],list[Texture],list[FakeViewItem_Brush],list[FakeViewItem_Texture]],use_fake_items:bool=_D)->_A:
		F=use_fake_items;B=data
		if not B:return
		if not F:
			C=[]
			for D in B:
				E=D.thumbnail
				if type==_B:
					if D.use_custom_icon and D.icon_filepath:C.append(E)
				elif type==_C:E.set_filepath(D.image.filepath,lazy_generate=_D);C.append(E)
			if len(C)>0:from .thumbnailer import Thumbnailer as G;G.push(*(C))
		A.use_fake_items=F;A.lib_path=lib_path;A.ctx_type=type
		if type==_B:A.input_brushes=B;A.output_brushes=[]
		elif type==_C:A.input_textures=B;A.output_textures=[]
		A.enabled=_G;A.cv.shelf.expand=_D;A.update(A.cv,_A);A.cv.refresh()
	def confirm(A):
		D=Props.BrushManager();"\n        datablocks = {\n            'brushes': [brush.name for brush in self.output_brushes],\n            'images': [texture.name for texture in self.output_textures],\n        }\n        ";B=A.output_brushes if A.ctx_type==_B else A.output_textures if A.ctx_type==_C else _A
		if not B:return
		E:str=basename(A.lib_path).removesuffix('.blend')
		if A.ctx_type==_B:
			C:list[Texture]=[];B.sort(key=lambda i:i.name)
			for F in B:
				if hasattr(F,'texture'):C.append(F.detach_texture())
				D.add_brush(F)
			C.sort(key=lambda i:i.name)
			for K in C:D.add_texture(K)
			D.new_brush_cat(E,brush_items=B);D.new_texture_cat(E,texture_items=C);from .thumbnailer import Thumbnailer as H
			if len(C)<=40:H.push(*([A.thumbnail for A in C]))
			else:H.push(*([A.thumbnail for A in C[:40]]))
			del C
		elif A.ctx_type==_C:
			for L in B:D.add_brush(L)
			D.new_texture_cat(E,texture_items=B)
		del B;A.close();return;G=time();I:str=SculptPlusPaths.APP__TEMP('fake_items_texture_ids.txt')
		with open(I,'w',encoding='ascii')as J:
			if A.ctx_type==_B:J.write('\n'.join([A.texture.id+A.texture.name for A in B if A.texture is not _A]))
			elif A.ctx_type==_C:J.write('\n'.join([A.id+A.name for A in B]))
		print('*[TIME] Save fake items to temporal database: %.2f seconds'%(time()-G));G=time();M=subprocess.Popen([bpy.app.binary_path,A.lib_path,'--background','--python',ScriptPaths.GENERATE_NPZ_FROM_BLENDLIB,'--',I]);M.wait();print('*[TIME] Save selected textures to .npy: %.2f seconds'%(time()-G));del B;A.close()
	def cancel(A):A.close()
	def close(A)->_A:
		A.cv.refresh();A.cv.shelf.expand=_G;A.enabled=_D;A.lib_path=_A
		if A.ctx_type==_B:del A.input_brushes;del A.output_brushes
		elif A.ctx_type==_C:del A.input_textures;del A.output_textures
	def update(B,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:A=cv;B.pos=Vector((A.reg.width*0.25,A.reg.height*0.25));B.size=Vector((A.reg.width*0.75-B.pos.x,A.reg.height*0.75-B.pos.y));super().update(A,prefs)
	def draw_pre(A,ctx,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):DiRct(Vector((0,0)),Vector((ctx.region.width,ctx.region.height)),(0.05,0.05,0.05,0.95))
	def draw(A,ctx,cv:Canvas,m,scale:float,prefs:SCULPTPLUS_AddonPreferences):B=prefs;DiRct(A.pos,A.size,B.theme_shelf);DiCage(A.pos,A.size,6,Vector(B.theme_shelf)*1.25);DiText(A.pos,"Press 'A' to swap all items.",12,scale,pivot=(0,1))
class AssetImporterWidget:
	parent:AssetImporterModal;enabled:bool
	@property
	def enabled(self):return self.cv.mod_asset_importer.enabled
	@enabled.setter
	def enabled(self,value):
		A=value;self._enabled=A
		if A:self.on_enable()
	def on_enable(A):0
	def __init__(A)->_A:A._enabled=_D
class AssetImporterCatSelector(WidgetSelector,AssetImporterWidget):
	label='Select a Category'
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:B=cv.mod_asset_importer;A.size=Vector((150,30))*cv.scale;A.pos=B.get_pos_by_relative_point(Vector((0.5,0.85)));A.pos.x-=A.size.x*0.5;A.pos.y+=A.size.y;super().update(cv,prefs)
	def on_enable(A):A.items=A.load_items()
	def load_items(C):
		A=C.cv.mod_asset_importer
		if A.ctx_type==_B:B=Props.GetAllBrushCats()
		elif A.ctx_type==_C:B=Props.GetAllTextureCats()
		else:return()
		return[(A.id,A.name)for A in B]
class AssetImporterActions(ButtonGroup,AssetImporterWidget):
	def init(A)->_A:super().init();A.button_style['color']=0.16,0.16,0.16,0.9;A.new_button('Confirm',on_click_callback=lambda ctx,cv:cv.mod_asset_importer.confirm());A.new_button('Cancel',on_click_callback=lambda ctx,cv:cv.mod_asset_importer.cancel())
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:B=cv.mod_asset_importer;A.size=Vector((180*cv.scale,32*cv.scale));A.pos=B.get_pos_by_relative_point(Vector((0.5,0)));A.pos.x-=A.size.x/2;A.pos.y-=A.size.y*2;super().update(cv,prefs)
	def draw_pre(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):0
class AssetImporterGrid(ViewWidget,AssetImporterWidget):
	use_scissor:bool=_G;header_label:str='Hello World';item_hover_icon:Icon
	def __init__(A,canvas:Canvas,anchor:tuple[float,float,float,float]=(0,1,0,1))->_A:A.anchor=anchor;super().__init__(canvas)
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:C=cv.mod_asset_importer;D,E=C.get_pos_size_by_anchor(Vector(A.anchor));B=Vector((10,10))*cv.scale;A.pos=D+B;A.size=E-B*2
	def event(A,ctx,evt,cv:Canvas,m:Vector)->bool:
		if evt.type=='A'and evt.value=='CLICK':A.pass_all_items(cv)
		return _D
	def on_left_click(A,ctx,cv:Canvas,m:Vector)->_A:
		if A.hovered_item:A.pass_item(cv);cv.refresh(ctx)
	def pass_item(A,cv:Canvas)->_A:0
	def pass_all_items(A,cv:Canvas)->_A:0
	def get_draw_item_args(A,context,cv:Canvas,scale:float,prefs:SCULPTPLUS_AddonPreferences)->tuple:return prefs.theme_shelf_slot,cv.mouse
	def draw_pre(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):B=scale;DiText(A.get_pos_by_relative_point(Vector((0,1)))+Vector((0,8*B)),A.header_label,16,B);DiRct(A.pos,A.size,Vector(prefs.theme_sidebar)*0.7)
	def draw_item(F,slot_p,slot_s,item:Union[Brush,Texture,FakeViewItem_Brush,FakeViewItem_Texture],is_hovered:bool,slot_color,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		G=is_hovered;C=item;B=slot_p;A=slot_s;E=4*scale;H=Vector((E,E));DiRct(B,A,slot_color)
		if isinstance(C,(FakeViewItem_Brush,FakeViewItem_Texture)):
			DiImaOpGamHl(B+H,A-H*2,C.icon)
			if isinstance(C,FakeViewItem_Brush)and C.texture:D=A.x*0.4;D=Vector((D,D));I=B+Vector((A.x-D.x,0));DiImaOpGamHl(I,D,C.texture.icon);DiCage(I,D,1,(0.1,0.1,0.1,0.92))
		elif isinstance(C,(Brush,Texture)):C.draw_preview(B,A,G,view_widget=F)
		if G:DiRct(B,A,(0.05,0.05,0.05,0.82));DiCage(B,A,E*0.5,prefs.theme_active_slot_color);L=B+A*0.5;J=A.x*0.2;K=Vector((J,J));DiIcoOpGamHl(L-K,K*2,F.item_hover_icon,1.5)
class AssetImporterGrid_Inputs(AssetImporterGrid):
	header_label:str='Blend Library Assets';item_hover_icon=Icon.ADD_PLUS_2
	def get_data(B,cv:Canvas)->list:
		A=cv.mod_asset_importer
		if A.ctx_type==_B:return A.input_brushes
		elif A.ctx_type==_C:return A.input_textures
		return[]
	def pass_item(A,cv:Canvas):B=cv.mod_asset_importer;B.pass_item(A.hovered_item,move_to=_F)
	def pass_all_items(B,cv:Canvas)->_A:A=cv.mod_asset_importer;A.pass_all_items(move_to=_F)
class AssetImporterGrid_Outputs(AssetImporterGrid):
	header_label:str='To Import Assets';item_hover_icon=Icon.CLOSE
	def get_data(B,cv:Canvas)->list:
		A=cv.mod_asset_importer
		if A.ctx_type==_B:return A.output_brushes
		elif A.ctx_type==_C:return A.output_textures
		return[]
	def pass_item(A,cv:Canvas):B=cv.mod_asset_importer;B.pass_item(A.hovered_item,move_to=_E)
	def pass_all_items(B,cv:Canvas)->_A:A=cv.mod_asset_importer;A.pass_all_items(move_to=_E)