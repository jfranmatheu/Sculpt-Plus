_A=None
from .wg_base import WidgetBase,Canvas,Vector,SCULPTPLUS_AddonPreferences
from .wg_but import ButtonGroup
from sculpt_plus.lib.icons import Icon
class SidebarContextSwitcher(ButtonGroup):
	but_ctx_brush:object;but_ctx_texture:object
	def init(A)->_A:
		E='ENABLED';D='TEXTURE';super().init();A.but_ctx_brush=_A;A.but_ctx_texture=_A;A.button_style['outline_color']=0.24,0.24,0.24,0.9;A.button_style['color']=0.16,0.16,0.16,0.65;A.style['separator_color']=_A
		def B(cv:Canvas,ctx_type:str,target_button):
			C=ctx_type;B=cv;F=B.shelf_grid.type
			if F==C:return
			if F==D:B.shelf_grid_item_info.expand=False
			elif C==D:B.shelf_grid_item_info.expand=True
			B.shelf_sidebar.type=C;B.shelf_grid.type=C
			for G in A.buttons:G.set_state(E,remove=True)
			target_button.set_state(E)
		A.but_ctx_brush=A.new_button('',icon=Icon.PAINT_BRUSH,on_click_callback=lambda ctx,cv:B(cv,'BRUSH',A.but_ctx_brush));A.but_ctx_texture=A.new_button('',icon=Icon.TEXTURE_OPACITY,on_click_callback=lambda ctx,cv:B(cv,D,A.but_ctx_texture));A.but_ctx_brush.set_state(E)
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		B=cv.shelf_sidebar;C=8*cv.scale;A.size=Vector((32,64+C))*cv.scale;A.pos=B.get_pos_by_relative_point(Vector((0,1)));A.pos.x-=B.margin+A.size.x;A.pos.y-=A.size.y-B.header_height
		if A.but_ctx_brush is _A or A.but_ctx_texture is _A:return
		D=Vector((32,32))*cv.scale;A.but_ctx_texture.pos=A.pos.copy();A.but_ctx_brush.pos=A.pos+Vector((0,D.y+C));A.but_ctx_brush.size=A.but_ctx_texture.size=D
	def poll(A,_context,cv:Canvas)->bool:return cv.shelf.expand and cv.shelf.size.y>A.size.y
	def draw_pre(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):0