_e='builtin_brush.Draw Face Sets'
_d='builtin_brush.Mask'
_c='icon_scale'
_b='post_func_ctx'
_a='iterations'
_Z='auto_iteration_count'
_Y='SHARPEN'
_X='Mask Sharpen'
_W='SMOOTH'
_V='Mask Smooth'
_U='Mask Shrink'
_T='Mask Grow'
_S='INVERT'
_R='Mask Invert'
_Q='Mask Clear'
_P='sculpt.face_set_edit'
_O='SCULPT'
_N='builtin.face_set_edit'
_M='name'
_L='toggle'
_K='SHRINK'
_J='GROW'
_I='mode'
_H=None
_G=False
_F='filter_type'
_E='icon'
_D='kwargs'
_C='args'
_B='func'
_A='label'
from typing import Any,Dict,Tuple
from bpy import ops as OPS
from sculpt_plus.lib.icons import BrushIcon,Icon
from .wg_group_but import ButtonGroup,MultiButtonGroup
"\n{ # MASK FILL.\n            'func': OPS.paint.mask_flood_fill,\n            'args': (),\n            'kwargs': {\n                'mode':   'VALUE',\n                'value':  1\n            },\n            'icon': 'F'\n        },\n"
def set_face_set_edit_mode(ctx,mode:str)->_H:
	A=ctx.workspace.tools.from_space_view3d_mode(_O,create=_G)
	if A:A.operator_properties(_P).mode=mode
def get_face_set_edit_mode(ctx)->_H:
	A=ctx
	if A.workspace.tools.from_space_view3d_mode(A.mode,create=_G).idname!=_N:return _H
	B=A.workspace.tools.from_space_view3d_mode(_O,create=_G)
	if B:return B.operator_properties(_P).mode
	return _H
class MaskGroup(ButtonGroup):fill_by:str='COLS';relative_to_bar_pos=0,1;items:Tuple[Dict[str,Any]]=({_A:_Q,_B:OPS.paint.mask_flood_fill,_C:(),_D:{_I:'VALUE','value':0},_E:Icon.MASK_CLEAR},{_A:_R,_B:OPS.paint.mask_flood_fill,_C:(),_D:{_I:_S},_E:Icon.MASK_INVERT},{_A:_T,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_J},_E:'G'},{_A:_U,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_K},_E:'K'},{_A:_V,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_W},_E:'S'},{_A:_X,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_Y},_E:'N'},{_A:'Mask Contrast Increase',_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:'CONTRAST_INCREASE',_Z:_G,_a:2},_E:'CI'},{_A:'Mask Contrast Decrease',_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:'CONTRAST_DECREASE',_Z:_G,_a:2},_E:'CD'})
class MaskMultiGroup(MultiButtonGroup):fill_by:str='COLS';rows:int=2;align:str='LEFT';align_dir:str='RIGHT';relative_to_bar_pos=0,0;group_items:Tuple[Tuple[Dict[str,Any]]]=(({_A:_Q,_B:OPS.paint.mask_flood_fill,_C:(),_D:{_I:'VALUE','value':0},_E:Icon.MASK_CLEAR},{_A:_R,_B:OPS.paint.mask_flood_fill,_C:(),_D:{_I:_S},_E:Icon.MASK_INVERT},{_A:_T,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_J},_E:Icon.MASK_GROW},{_A:_U,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_K},_E:Icon.MASK_SHRINK},{_A:_V,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_W},_E:Icon.MASK_SMOOTH},{_A:_X,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_Y},_E:Icon.MASK_SHARP}),({_A:'Face Set Grow (Tool)',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_M:_N},_b:lambda ctx:set_face_set_edit_mode(ctx,_J),_E:Icon.FACESET_GROW,_L:lambda ctx:get_face_set_edit_mode(ctx)==_J},{_A:'Face Set Shrink (Tool)',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_M:_N},_b:lambda ctx:set_face_set_edit_mode(ctx,_K),_E:Icon.FACESET_SHRINK,_L:lambda ctx:get_face_set_edit_mode(ctx)==_K}),({_A:'Mask Brush Tool',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_M:_d},_E:BrushIcon.MASK,_c:1.05,_L:lambda ctx:ctx.workspace.tools.from_space_view3d_mode(ctx.mode,create=_G).idname==_d},{_A:'Draw Face Sets Tool',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_M:_e},_E:BrushIcon.DRAW_FACE_SETS,_c:1.05,_L:lambda ctx:ctx.workspace.tools.from_space_view3d_mode(ctx.mode,create=_G).idname==_e}))