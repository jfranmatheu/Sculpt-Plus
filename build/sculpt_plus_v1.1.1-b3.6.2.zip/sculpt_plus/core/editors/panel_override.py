from bpy.types import VIEW3D_PT_tools_brush_select,VIEW3D_PT_tools_brush_settings
from.backup_cache import set_cls_attribute
classes_to_override__poll=VIEW3D_PT_tools_brush_select,VIEW3D_PT_tools_brush_settings
@classmethod
def poll(cls,context):
	B='SCULPT';A=context
	if A.mode==B and'sculpt_plus'in A.workspace:return False
	return A.object and A.mode==B
@classmethod
def poll_default(cls,context):return True
def register():
	for A in classes_to_override__poll:set_cls_attribute(A,'poll',poll)