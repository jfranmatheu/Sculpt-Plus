_E='draw_mode_settings'
_D='draw_tool_settings'
_C='sculpt_plus'
_B='SCULPT'
_A=True
from bl_ui.space_view3d import VIEW3D_HT_tool_header
from bpy.types import Brush as BlBrush,UILayout
from bl_ui.properties_paint_common import UnifiedPaintPanel
from...backup_cache import get_attr_from_cache,VIEW3D_PT_tools_active,set_cls_attribute
def draw_error(self,context):self.layout.label(text='ERROR!')
def draw_toolheader_tool_settings(self:VIEW3D_HT_tool_header,context):
	F=None;D=self;A=context
	if A.mode!=_B or _C not in A.workspace:
		if hasattr(VIEW3D_HT_tool_header,'old_draw_tool_settings'):
			if VIEW3D_HT_tool_header.old_draw_tool_settings==draw_toolheader_tool_settings:draw_error(D,A)
			else:VIEW3D_HT_tool_header.old_draw_tool_settings(D,A)
		else:get_attr_from_cache(VIEW3D_HT_tool_header,_D,draw_error)(D,A)
		return
	H=A.space_data.type;I=VIEW3D_PT_tools_active._tool_active_from_context(A,H)
	if not I:return
	J:str=getattr(I,'idname',F);N,J=J.split('.');O:bool=N=='builtin_brush';K,T,P=VIEW3D_PT_tools_active._tool_get_active(A,H,_B,with_icon=_A)
	if K is F:return
	C:UILayout=D.layout;C.label(text='    '+K.label,icon_value=P)
	if O:
		B:BlBrush=A.tool_settings.sculpt.brush
		if B is F:C.label(text='No active brush !');return
		'\n        UnifiedPaintPanel.prop_unified(layout, context, brush, \'size\', \'size\', \'use_pressure_size\', text="Radius", slider=True, header=True)\n        UnifiedPaintPanel.prop_unified(layout, context, brush, \'strength\', \'strength\', \'use_pressure_strength\', text="Strength", slider=True, header=True)\n        if not brush.sculpt_capabilities.has_direction:\n            layout.prop(brush, \'direction\', expand=True, text="")\n        ';Q=A.tool_settings;G=B.sculpt_capabilities;L=Q.unified_paint_settings
		if G.has_color:E=C.row(align=_A);E.ui_units_x=4;UnifiedPaintPanel.prop_unified_color(E,A,B,'color',text='');UnifiedPaintPanel.prop_unified_color(E,A,B,'secondary_color',text='');E.separator();C.prop(B,'blend',text='',expand=False)
		M='size';R=L if L.use_unified_size else B
		if R.use_locked_size=='SCENE':M='unprojected_radius'
		UnifiedPaintPanel.prop_unified(C,A,B,M,pressure_name='use_pressure_size',unified_name='use_unified_size',text='Radius',slider=_A,header=_A);S='use_pressure_strength'if G.has_strength_pressure else F;UnifiedPaintPanel.prop_unified(C,A,B,'strength',pressure_name=S,unified_name='use_unified_strength',text='Strength',header=_A)
		if not G.has_direction:C.row().prop(B,'direction',expand=_A,text='')
	else:get_attr_from_cache(VIEW3D_HT_tool_header,_D,draw_error)(D,A)
def draw_toolheader_mode_settings(self,context):
	C=self;A=context
	if A.mode!=_B or _C not in A.workspace:
		if hasattr(VIEW3D_HT_tool_header,'old_draw_mode_settings'):VIEW3D_HT_tool_header.old_draw_mode_settings(C,A)
		else:get_attr_from_cache(VIEW3D_HT_tool_header,_E,draw_error)(C,A)
		return
	F=_C not in A.workspace;E:UILayout=C.layout;D=E.row(align=_A);D.box().label(icon='MOD_MIRROR');B=D.row(align=_A);B.scale_x=.7;B.prop(A.object,'use_mesh_mirror_x',text='X',toggle=_A);B.prop(A.object,'use_mesh_mirror_y',text='Y',toggle=_A);B.prop(A.object,'use_mesh_mirror_z',text='Z',toggle=_A);B=D.row(align=_A);B.popover('VIEW3D_PT_sculpt_symmetry_for_topbar',text='');E.popover('VIEW3D_PT_sculpt_options',text='Options')
def register():set_cls_attribute(VIEW3D_HT_tool_header,_D,draw_toolheader_tool_settings);set_cls_attribute(VIEW3D_HT_tool_header,_E,draw_toolheader_mode_settings)