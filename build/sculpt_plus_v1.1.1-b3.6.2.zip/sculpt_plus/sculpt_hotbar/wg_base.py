_G='RIGHTMOUSE'
_F='LEFTMOUSE'
_E='WidgetBase'
_D='RELEASE'
_C=True
_B=False
_A=None
from collections import defaultdict
import functools
from subprocess import call
from time import time
from typing import Dict,List,Set,Tuple
from mathutils import Vector
from bpy.app import timers
from bpy.app import version
if version<=(3,4,1):USE_BGL=_C;from bgl import glScissor,glEnable,GL_SCISSOR_TEST,glDisable,GL_BLEND,GL_DEPTH_TEST
else:USE_BGL=_B;from gpu import state
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.sculpt_hotbar.di import DiRct,DiText
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
from sculpt_plus.utils.math import ease_quad_in_out,lerp
from sculpt_plus.utils.cursor import Cursor,CursorIcon
num_str={'ONE':1,'TWO':2,'THREE':3,'FOUR':4,'FIVE':5,'SIX':6,'SEVEN':7,'EIGHT':8,'NINE':9,'ZERO':0}
class WidgetBase:
	use_scissor:bool=_B;scissor_padding:Vector=Vector((0,0));interactable:bool=_C;modal_trigger:Set[str]=set();cursor:CursorIcon=CursorIcon.DEFAULT;msg_on_enter:str=_A;parent:_E or Canvas;closes_itself:bool
	def __init__(A,canvas:Canvas,pos:Vector=Vector((0,0)),size:Vector=Vector((0,0)))->_A:A.cv=canvas;A._is_on_hover=_B;A.in_modal=_B;A.enabled=_C;A.pos=pos;A.size=size;(A.anim_pool):Dict[str,dict]={};A.scroll_prev_time=time();A.parent=_A;A.closes_itself=_B;A.init()
	def anim_running(A)->bool:return A.anim_pool=={}
	def init(A)->_A:0
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:0
	def poll(A,_context,cv:Canvas)->bool:return _C
	def invoke(B,ctx,evt,cv:Canvas,m:Vector,prefs:SCULPTPLUS_AddonPreferences)->bool:
		J='WHEELDOWNMOUSE';I='WHEELUPMOUSE';H=prefs;G='CLICK';F='PRESS';D=cv;C=ctx;A=evt
		if not B.enabled:return _B
		E=_A
		if A.type==_F:
			if A.value==F:E=B.on_leftmouse_press(C,D,m)
			elif A.value==_D:E=B.on_leftmouse_release(C,D,m)
			elif A.value==G:E=B.on_left_click(C,D,m)
			elif A.value=='CLICK_DRAG':E=B.on_left_click_drag(C,D,m)
			elif A.value=='DOUBLE_CLICK':E=B.on_double_click(C,D,m)
		elif A.type==_G:
			if A.value==F:E=B.on_rightmouse_press(C,D,m)
			elif A.value==_D:E=B.on_rightmouse_release(C,D,m)
			elif A.value==G:E=B.on_right_click(C,D,m)
		elif A.value==F and A.type in{I,J}:
			if time()-B.scroll_prev_time<.01:return _B
			if A.type==I:B.on_scroll_up(C,D,H)
			elif A.type==J:B.on_scroll_down(C,D,H)
			B.scroll_prev_time=time()
		elif A.type in num_str and A.value==G:E=B.on_numkey(C,num_str[A.type],D,m)
		if E is not _A:return bool(E)
		return B.event(C,A,D,m)
	def event(A,ctx,evt,cv:Canvas,m:Vector)->bool:return evt.type in A.modal_trigger
	def modal_enter(A,ctx,cv:Canvas,m:Vector)->_A:0
	def modal_exit(A,ctx,cv:Canvas,m:Vector,cancel:bool=_B)->_A:0
	def modal(B,ctx,evt,cv:Canvas,m:Vector)->bool:
		C=ctx;A=evt
		if A.type in{'ESC','RIGHTCLICK'}:return _B
		if A.value==_D:
			if A.type==_G:B.on_rightmouse_release(C,cv,m)
			elif A.type==_F:B.on_leftmouse_release(C,cv,m)
			return _B
		if A.type=='MOUSEMOVE':B.on_mousemove(C,cv,m);return _C
		return _C
	def _on_hover(A,ctx,m)->bool:
		B=ctx
		if not A.enabled:return _B
		if not A.poll(B,A.cv):return _B
		if A.on_hover(m):
			A.cv.refresh(B)
			if not A._is_on_hover:
				A.cv.refresh(B)
				if A.msg_on_enter:B.area.header_text_set(A.msg_on_enter)
				A._is_on_hover=_C;A.on_hover_enter()
			if A.cursor:Cursor.set_icon(B,A.cursor)
			C=A.on_hover_stay(m)
			if C:A.cv.refresh(B)
			return _C
		else:
			if A._is_on_hover:
				if A.cursor and A.cursor!=CursorIcon.DEFAULT:Cursor.set_icon(B,CursorIcon.DEFAULT)
				if A.msg_on_enter:B.area.header_text_set(_A)
				A._is_on_hover=_B;A.on_hover_exit();A.cv.refresh(B)
			return _B
	' OnHover Methods. '
	@staticmethod
	def check_hover(widget:'WidgetBase',m:Vector,p:Vector=_A,s:Vector=_A)->bool:A=widget;p=p if p else A.pos;s=s if s else A.size;return m.x>p.x and m.x<p.x+s.x and m.y>p.y and m.y<p.y+s.y and s.x>2 and s.y>2
	def on_hover(A,m:Vector,p:Vector=_A,s:Vector=_A)->bool:p=p if p else A.pos;s=s if s else A.size;return m.x>p.x and m.x<p.x+s.x and m.y>p.y and m.y<p.y+s.y and s.x>2 and s.y>2
	def on_hover_enter(A)->_A:0
	def on_hover_exit(A)->_A:0
	def on_hover_stay(A,m:Vector)->bool:return _B
	' Event Methods.'
	def on_leftmouse_press(A,ctx,cv:Canvas,m:Vector)->_A:0
	def on_leftmouse_release(A,ctx,cv:Canvas,m:Vector)->_A:0
	def on_left_click(A,ctx,cv:Canvas,m:Vector)->_A:0
	def on_left_click_drag(A,ctx,cv:Canvas,m:Vector)->_A:0
	def on_double_click(A,ctx,cv:Canvas,m:Vector)->_A:0
	def on_rightmouse_press(A,ctx,cv:Canvas,m:Vector)->_A:0
	def on_rightmouse_release(A,ctx,cv:Canvas,m:Vector)->_A:0
	def on_right_click(A,ctx,cv:Canvas,m:Vector)->_A:0
	def on_numkey(A,ctx,number:int,cv:Canvas,m:Vector)->_A:0
	def on_mousemove(A,ctx,cv:Canvas,m:Vector)->_A:0
	def on_scroll_up(A,ctx,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences):0
	def on_scroll_down(A,ctx,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences):0
	' Transform Methods. '
	def move(A,x:int=0,y:int=0,animate:bool=_B,anim_change_callback:callable=_A,anim_finish_callback:callable=_A)->_A:
		if x==0 and y==0:return
		A.move_to(A.pos.x+x,A.pos.y+y,animate=animate,anim_change_callback=anim_change_callback,anim_finish_callback=anim_finish_callback)
	def move_to(A,x:int=0,y:int=0,animate:bool=_B,anim_change_callback:callable=_A,anim_finish_callback:callable=_A)->_A:
		C=anim_finish_callback;B=anim_change_callback
		if not animate:
			if x!=0:A.pos.x=int(x)
			if y!=0:A.pos.y=int(y)
			return
		if x!=0:A.anim('pos_x',A.pos,'x',int(x),duration=.4,delay=.01,smooth=_C,change_callback=B,finish_callback=C)
		if y!=0:A.anim('pos_y',A.pos,'y',int(y),duration=.4,delay=.01,smooth=_C,change_callback=B,finish_callback=C)
	def scale(A,x:float=1,y:float=1,animate:bool=_B,anim_change_callback:callable=_A,anim_finish_callback:callable=_A)->_A:
		if x==1 and y==1:return
		A.move_to(A.size.x*x,A.size.y*y,animate=animate,anim_change_callback=anim_change_callback,anim_finish_callback=anim_finish_callback)
	def resize(A,x:float=1,y:float=1,animate:bool=_B,anim_change_callback:callable=_A,anim_finish_callback:callable=_A)->_A:
		C=anim_finish_callback;B=anim_change_callback
		if not animate:
			if x!=1:A.size.x=int(x)
			if y!=1:A.size.y=int(y)
			return
		if x!=1:A.anim('size_x',A.size,'x',int(x),duration=.3,delay=.01,smooth=_C,change_callback=B,finish_callback=C)
		if y!=1:A.anim('size_y',A.size,'y',int(y),duration=.3,delay=.01,smooth=_C,change_callback=B,finish_callback=C)
	' Util Methods. '
	def get_pos_by_relative_point(A,rel_point:Vector)->Vector:return A.pos+A.size*rel_point;'\n        Vector((\n            self.pos.x + self.size.x * rel_point.x,\n            self.pos.y + self.size.y * rel_point.y\n        ))\n        '
	def get_pos_size_by_anchor(A,anchor:Vector)->Tuple[Vector,Vector]:B=anchor;C=A.pos+A.size*B.xz;D=A.pos+A.size*B.yw;return C,D-C;'\n        Vector((\n            self.pos.x + self.size.x * anchor.x,\n            self.pos.y + self.size.y * anchor.z\n        )), Vector((\n            self.pos.x + self.size.x * anchor.y,\n            self.pos.y + self.size.y * anchor.w\n        ))\n        '
	def anim(B,idname:str,data,attr:str,target_value:float or int,duration:float,smooth:bool=_B,delay:float=.01,change_callback:callable=_A,finish_callback:callable=_A,attr_index:int=_A,block_existing_anim:bool=_B)->_A:
		V='idname';S=target_value;R='start_value';Q='value_dimension';P='finish_callback';O='attr_index';N='start_time';M=attr_index;L=duration;J=attr;I=data;H='change_callback';G='end_value';F='time';E=idname;D='attr';C='data'
		if not hasattr(I,J):return
		def W(_idname:str)->_A:del B.anim_pool[_idname]
		def X(ease_fun:callable,anim:dict):
			A=anim;I:float=min(time()-A[N],A[F])/A[F]
			if I>=.98:
				if A[O]:getattr(A[C],A[D])[M]=A[G]
				else:setattr(A[C],A[D],A[G])
				if A[H]:A[H]()
				if A[P]:A[P]()
				W(A[V]);return
			if A[Q]==1:
				E=ease_fun(A[R],A[G],I)
				if A[O]:getattr(A[C],A[D])[M]=E
				else:setattr(A[C],A[D],E)
			else:
				for J in range(A[Q]):E=lerp(A[R][J],A[G][J],I);getattr(A[C],A[D])[J]=E
			if A[H]:A[H]();B.cv.refresh()
			return .001
		def Z(start_time:float,anim:dict):0
		if E not in B.anim_pool:
			K=getattr(I,J)
			if not isinstance(K,(Vector,list,int,float)):print('Animating an incompatible type!');return
			A={V:E,C:I,D:J,O:M,R:K,G:S,Q:len(K)if isinstance(K,(Vector,list))else 1,N:time(),F:L,H:change_callback,P:finish_callback};Y:callable=ease_quad_in_out if smooth else lerp;B.anim_pool[E]=A;B.time_fun(X,delay,Y,B.anim_pool[E])
		else:
			A=B.anim_pool[E];T:float=time()-A[N]
			if L<.5:U=min(T,A[F])/A[F]<.2
			else:U=T<.2
			if not block_existing_anim or U:return
			A.update(start_value=getattr(I,J),end_value=S,time=L,start_time=time())
	def time_fun(C,fun,time=.1,*A,**B):
		if timers.is_registered(fun):return
		timers.register(functools.partial(fun,*A,**B),first_interval=time)
	def _draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		F=mouse;E=prefs;D=scale;C=cv;B=context
		if not A.enabled:return _B
		if A.size.x==0 or A.size.y==0:return _B
		if not A.poll(B,C):return _B
		if not A.draw_poll(B,C):return _B
		A.draw_pre(B,C,F,D,E)
		if A.use_scissor:
			if USE_BGL:glEnable(GL_SCISSOR_TEST)
			else:state.scissor_test_set(_C)
			A.draw_scissor_apply(A.pos,A.size);DiText(Vector((0,0)),' ',1,D,E.theme_text)
		A.draw(B,C,F,D,E)
		if A.use_scissor:
			if USE_BGL:glDisable(GL_SCISSOR_TEST)
			else:state.scissor_test_set(_B)
			A.draw_scissor_apply(Vector((0,0)),Vector((B.region.width,B.region.height)));A.draw_post(B,C,F,D,E)
	def draw_scissor_apply(A,_p:Vector,_s:Vector):
		if USE_BGL:glScissor(int(_p.x)-1+int(A.scissor_padding.x),int(_p.y)-1+int(A.scissor_padding.x),int(_s.x)+2-int(A.scissor_padding.x*2),int(_s.y)+2-int(A.scissor_padding.x*2))
		else:state.scissor_set(int(_p.x)-1+int(A.scissor_padding.x),int(_p.y)-1+int(A.scissor_padding.x),int(_s.x)+2-int(A.scissor_padding.x*2),int(_s.y)+2-int(A.scissor_padding.x*2))
	def draw_poll(A,context,cv:Canvas)->bool:return _C
	def draw_pre(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):0
	def draw_post(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):0
	def draw_over(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):0
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):DiRct(A.pos,A.size,(.1,.1,.1,.8))