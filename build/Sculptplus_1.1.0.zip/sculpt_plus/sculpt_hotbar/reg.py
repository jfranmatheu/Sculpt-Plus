_C='SCULPT'
_B=True
_A=None
import bpy
from bpy.app.timers import register as register_timer,is_registered as is_timer_registered
from bpy.types import GizmoGroup as GZG,Gizmo as GZ,Region,Context
from mathutils import Vector
from sculpt_plus.prefs import get_prefs
from sculpt_plus.sculpt_hotbar.km import WidgetKM as KM
from sculpt_plus.sculpt_hotbar.canvas import Canvas as CV
from sculpt_plus.utils.gpu import LiveView
from sculpt_plus.props import Props,CM_UIContext
from sculpt_plus.globals import G
from bl_ui.space_toolsystem_toolbar import VIEW3D_PT_tools_active
from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
from brush_manager.globals import GLOBALS
exclude_brush_tools:set[str]={'MASK','DRAW_FACE_SETS','DISPLACEMENT_ERASER','DISPLACEMENT_SMEAR','SIMPLIFY'}
initialized=False
def initialize_brush():
	if GLOBALS.is_importing_a_library:return 0.5
	A=bpy.context
	if A!=_C:return 1.0
	with CM_UIContext(A,mode=_C,item_type='BRUSH'):
		if(C:=G.bm_data.active_brush):C.set_active(A)
		elif(B:=G.bm_data.active_category):
			if B.items.count>0:
				try:B.items[0].set_active(A)
				except Exception:return 1.0
		else:
			if A.space_data is _A:Props.SculptTool.clear_stored();return _A
			bpy.ops.wm.tool_set_by_id(name='builtin_brush.Draw');Props.SculptTool.update_stored(A)
def dummy_poll_view(ctx):
	global initialized
	if not initialized or Props.SculptTool.get_stored()=='NONE':
		if is_timer_registered(initialize_brush):return _B
		initialized=_B;register_timer(initialize_brush,first_interval=0.1)
	return _B
class Master(GZ):
	bl_idname:str='VIEW3D_GZ_sculpt_hotbar';_cv_instance=_A;cv:CV;reg:Region
	@classmethod
	def get_cv(A,ctx:Context|_A=_A)->CV:
		if A._cv_instance is _A:A._cv_instance=CV(ctx.region if ctx is not _A else bpy.context.region)
		return A._cv_instance
	def setup(A):0
	def test_select(A,c,l):return Master.get_cv(c).test(c,l)
	def invoke(A,c,e):return Master.get_cv(c).invoke(c,e)
	def modal(A,c,e,t):return Master.get_cv(c).modal(c,e,t)
	def exit(A,c,ca):return Master.get_cv(c).exit(c,ca)
	def draw(A,c):Master.get_cv(c).draw(c)
class Controller(GZG,KM):
	bl_idname:str='VIEW3D_GZG_sculpt_hotbar';bl_label:str='Sculpt Hotbar Controller';bl_space_type:str='VIEW_3D';bl_region_type:str='WINDOW';bl_options:set[str]={'PERSISTENT','SHOW_MODAL_ALL'}
	@classmethod
	def poll(B,y)->bool:A=y.object is not _A and y.mode==_C and y.scene.sculpt_hotbar.show_gizmo_sculpt_hotbar and y.space_data.show_gizmo and Props.Workspace(y)==y.workspace;return A
	def setup(A,ctx):B=ctx;A.rdim=B.region.width,B.region.height;A.roff=0,0;A.init_master(B,A.gizmos.new(Master.bl_idname))
	def draw_prepare(A,ctx:Context):A.update_master(ctx)
	def refresh(C,ctx:Context):
		A=ctx;B=Master.get_cv(A)
		if B.reg!=A.region:setattr(B,'reg',A.region);C.update_master(A)
	def init_master(B,ctx:Context,gz_master:Master):A=gz_master;A.reg=ctx.region;A.use_event_handle_all=_B;A.use_draw_modal=_B;A.scale_basis=1.0;B.master=A
	def update_master(B,ctx:Context):
		A=ctx;C=0;D=0;K=0;I=0
		for E in A.area.regions:
			if E.type=='TOOLS':C+=E.width
			elif E.type=='UI':I+=E.width
		G=A.region.width-I-C;H=A.region.height-K-D;F=Master.get_cv(A)
		if F.reg!=A.region or B.rdim[0]!=G or B.rdim[1]!=H or C!=B.roff[0]or D!=B.roff[1]:F.reg=A.region;F.refresh();B.roff=C,D;B.rdim=G,H;J=get_prefs(A);F.update((C,D),(G,H),J.get_scale(A),J)
bpy.sculpt_hotbar=Master