_C='RUNNING_MODAL'
_B='WINDOW'
_A='HORIZONTAL'
from gpu_extras.presets import draw_circle_2d
from bpy.types import Operator
from mathutils import Vector
from math import dist
from sculpt_plus.sculpt_hotbar.di import DiText
from sculpt_plus.utils.math import clamp,map_value
from gpu import state
class SCULPTPLUS_OT_gesture_size_strength(Operator):
	bl_label:str='Gesture Size Strength';bl_idname:str='sculpt_plus.gesture_size_strength'
	@classmethod
	def poll(B,context):A=context;return A.object and A.mode=='SCULPT'and A.tool_settings.sculpt.brush is not None
	def invoke(A,context,event):E=False;C=event;B=context;A.scale=D=B.preferences.system.ui_scale;A.start_mouse=Vector((C.mouse_region_x,C.mouse_region_y));A.current_mouse=A.start_mouse.copy();A.prev_mouse=A.start_mouse.copy();B.window_manager.modal_handler_add(A);A._draw_handler=B.space_data.draw_handler_add(A.draw_px,(B,A.start_mouse,A.current_mouse,D),_B,'POST_PIXEL');A.started=E;A.start_event=C.type;A.safe_radius=10*D;A.direction='NONE';A.old_value=0;A.mouse_delta_resto_for_next_iter=0;A.max_radius=250*D;A.data=None;A.data_prop='';A.data_range=0,1;B.tool_settings.sculpt.show_brush=E;B.region.tag_redraw();return{_C}
	def modal_exit(B,context):A=context;A.region.tag_redraw();A.space_data.draw_handler_remove(B._draw_handler,_B);A.tool_settings.sculpt.show_brush=True
	def modal(A,context,event):
		D=event;B=context
		if D.type in{'ESC'}:
			if A.started:setattr(A.data,A.data_prop,A.old_value)
			A.modal_exit(B);return{'CANCELLED'}
		if D.type==A.start_event and D.value=='RELEASE':
			if A.started:0
			A.modal_exit(B);return{'FINISHED'}
		A.current_mouse.x=D.mouse_region_x;A.current_mouse.y=D.mouse_region_y
		if A.started:
			B.region.tag_redraw();G=A.current_mouse-A.prev_mouse
			if A.direction==_A:E=G.x*0.002;H=clamp(getattr(A.data,A.data_prop)+E,*A.data_range)
			else:I=G.y+A.mouse_delta_resto_for_next_iter;E=int(I);A.mouse_delta_resto_for_next_iter=I-E;H=clamp(getattr(A.data,A.data_prop)+E,*A.data_range)
			setattr(A.data,A.data_prop,H)
		elif dist(A.start_mouse,A.current_mouse)>A.safe_radius:
			B.region.tag_redraw();F=B.tool_settings.sculpt.brush;C=B.tool_settings.unified_paint_settings;A.started=True;J=A.current_mouse-A.start_mouse;K,L=abs(J.x),abs(J.y)
			if K>L:
				A.direction=_A
				if C.use_unified_strength:A.old_value=C.strength;A.data=C
				else:A.old_value=F.strength;A.data=F
				A.data_prop='strength';A.data_range=0.0,2.0;A.max_radius=300
			else:
				A.direction='VERTICAL'
				if C.use_unified_size:A.old_value=C.size;A.data=C
				else:A.old_value=F.size;A.data=F
				(A.data_range):tuple[int,int]=(1,500);A.data_prop='size';A.max_radius=500
			A.start_mouse=A.current_mouse.copy()
		A.prev_mouse=A.current_mouse.copy();return{_C}
	def draw_px(A,context,origin:Vector,current_mouse:Vector,scale:float):
		D=1.0;C=scale;B=origin;B=A.start_mouse;state.blend_set('ALPHA');state.line_width_set(2.0*C)
		if A.started:
			E=getattr(A.data,A.data_prop);H=map_value(E,A.data_range,(0,A.max_radius))
			if A.direction==_A:F='Strength';G=D,D,0.0,D;E=round(E,2)
			else:F='Size';G=0.0,D,D,D
			draw_circle_2d(B,(0.8,0.8,0.8,D),A.max_radius,segments=int(64*C));draw_circle_2d(B,(0.6,0.6,0.6,D),A.max_radius*0.5,segments=int(32*C));draw_circle_2d(B,G,H,segments=int(64*C));DiText(B+Vector((0,A.max_radius*0.5+A.safe_radius)),F,16,C,pivot=(0.5,0),draw_rect_props={},shadow_props={});DiText(B,str(E),14,C,pivot=(0.5,0.5),draw_rect_props={},shadow_props={})
		else:DiText(B+Vector((0,A.safe_radius*2)),'Size +',14,C,pivot=(0.5,0),draw_rect_props={},shadow_props={});DiText(B+Vector((A.safe_radius*2,0)),'Strength +',14,C,pivot=(0,0.5),draw_rect_props={},shadow_props={});DiText(B+Vector((0,-A.safe_radius*2)),'Size -',14,C,pivot=(0.5,1),draw_rect_props={},shadow_props={});DiText(B+Vector((-A.safe_radius*2,0)),'Strength -',14,C,pivot=(1,0.5),draw_rect_props={},shadow_props={});draw_circle_2d(B,(D,0.0,0.0,D),A.safe_radius,segments=int(24*C))
		state.blend_set('NONE')