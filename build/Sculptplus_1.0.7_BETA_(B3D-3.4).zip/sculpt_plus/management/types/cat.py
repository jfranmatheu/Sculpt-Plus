_A=None
from uuid import uuid4
from typing import List,Dict,Union
from pathlib import Path
from copy import deepcopy
from .brush import Brush
from .image import Image,Thumbnail
from .texture import Texture
from sculpt_plus.path import ThumbnailPaths,DBShelf,DBShelfManager
class Category:
	id:str;name:str;index:int;item_ids:List[str];items:Union[Brush,Texture];icon:Thumbnail;items_count:int;type:str;bl_type:str='CAT_'
	def __init__(A,name:str='Untitled Category',_id:str=_A):(A.id):str=_id if _id else uuid4().hex;(A.name):str=name;(A.index):int=0;(A.icon):Thumbnail=Thumbnail.empty(A);(A.item_ids):List[str]=[];print(f"New Category {A.id} with name {A.name}")
	@property
	def items_count(self)->int:return len(self.item_ids)
	def get_items(A,all_items:Dict[str,Union[Brush,Texture]])->List[Union[Brush,Texture]]:return[all_items[id]for id in A.item_ids]
	def link_item(B,item:Union[Brush,Texture])->_A:
		A=item
		if A.cat_id:A.cat.unlink_item(A)
		B.item_ids.append(A.id);A.cat_id=B.id
	def unlink_item(A,item:Union[Brush,Texture])->_A:A.item_ids.remove(item.id);item.cat_id=_A
	def move_up(A)->_A:A.index=max(0,A.index-1)
	def move_down(A)->_A:A.index+=1
	def clear(A)->_A:A.item_ids.clear()
	def reset(A)->_A:0
	def save(A)->_A:' Save the brush category to the database. '
	def load_icon(A,filepath:Union[str,Path])->str:
		if A.icon is not _A:del A.icon
		A.icon=Thumbnail(filepath,A.id,'CAT_'+A.type);return A.icon.filepath
	def draw_preview(A,p,s,act:bool=False,fallback=_A)->_A:
		B=fallback
		if A.icon and A.icon.is_valid:A.icon.draw(p,s,act)
		elif B:B(p,s,act)
class BrushCategory(Category):
	type:str='BRUSH';bl_type:str='CAT_BRUSH_'
	@property
	def items(self)->List[Brush]:from ..manager import Manager as A;return list(A.get().brushes.values())
	def reset(A)->_A:from ..manager import Manager as B;B.get().reset_brush_cat(A)
	def save(A)->_A:DBShelf.BRUSH_CAT.write(A)
	def save_default(A)->_A:
		with DBShelfManager.BRUSH_DEFAULTS()as B:
			for C in A.items:B.write(C)
	def reset_default(C)->_A:
		from sculpt_plus.props import Props
		with DBShelfManager.BRUSH_DEFAULTS()as D,DBShelfManager.BRUSH_SETTINGS()as E:
			for A in C.items:B=D.get(A.id);E.write(B);Props.BrushManager().brushes[A.id]=B
	def __del__(A)->_A:
		return
		if(B:=ThumbnailPaths.BRUSH_CAT(A,check_exists=True)):B.unlink()
		DBShelf.BRUSH_CAT.remove(A)
class TextureCategory(Category):
	type:str='TEXTURE';bl_type:str='CAT_TEXTURE_'
	@property
	def items(self)->List[Texture]:from ..manager import Manager as A;return list(A.get().textures.values())
	def reset(A)->_A:from ..manager import Manager as B;B.get().reset_texture_cat(A)
	def save(A)->_A:DBShelf.TEXTURE_CAT.write(A)
	def save_default(A)->_A:0
	def reset_default(A)->_A:0
	def __del__(A)->_A:
		return
		if(B:=ThumbnailPaths.TEXTURE_CAT(A,check_exists=True)):B.unlink()
TexCat=TextureCategory
BruCat=BrushCategory