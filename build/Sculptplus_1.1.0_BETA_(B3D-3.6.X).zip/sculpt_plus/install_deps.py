import subprocess,sys,os,requests,tempfile,bpy
PILL_IMPORT_ERROR=False
PILL_UPDATE_ERROR=False
def is_pil_ok()->bool:global PILL_IMPORT_ERROR;return PILL_IMPORT_ERROR
class VersionError(Exception):0
def install():
	N='Blender-Brush-Manager';M='jfranmatheu';G='install';D='pip';C='-m';B=True;from .  import PILLOW_VERSION as H,BM_VERSION as I
	try:import brush_manager as O;Q=O.bl_info['version']
	except ImportError:
		if I!='latest':J='https://api.github.com/repos/{}/{}/releases/tags/{}'.format(M,N,I)
		else:J='https://api.github.com/repos/{}/{}/releases/latest'.format(M,N)
		E=requests.get(J,stream=B);print('[Sculpt+] Install BM - Request Status Code:',E.status_code)
		if E.status_code==200:
			with tempfile.TemporaryFile(mode='w+b',suffix='.zip')as K:
				for P in E.iter_content(chunk_size=128):K.write(P)
				bpy.ops.preferences.addon_install(filepath=K.name,overwrite=B);bpy.ops.preferences.addon_enable(module='brush_manager');bpy.ops.wm.save_userpref()
	'\n    os.system("pip3 install -r requirements.txt")\n    os.system("pip3 install -r requirements-dev.txt")\n    os.system("pip3 install -r requirements-test.txt")\n    ';A=os.path.join(sys.prefix,'bin','python.exe');L=os.path.join(sys.prefix,'lib','site-packages')
	try:
		import PIL
		if not hasattr(PIL,'__version__')or float(PIL.__version__[:-2])<9.3:print('Pillow version is too old! Requires to install a recent version...');raise VersionError('Pillow version is too old!')
	except ImportError:
		subprocess.call([A,C,'ensurepip']);subprocess.call([A,C,D,G,'--upgrade',D])
		try:subprocess.call([A,C,D,G,H,'-t',L])
		except PermissionError as F:print(F);global PILL_IMPORT_ERROR;PILL_IMPORT_ERROR=B
	except VersionError:
		try:subprocess.call([A,C,D,G,'--ignore-installed',H,'-t',L])
		except PermissionError as F:print(F);global PILL_UPDATE_ERROR;PILL_UPDATE_ERROR=B