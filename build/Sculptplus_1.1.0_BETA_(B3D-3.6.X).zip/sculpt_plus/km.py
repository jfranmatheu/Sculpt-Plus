import bpy
from sculpt_plus.core.ops.gestures import SCULPTPLUS_OT_gesture_size_strength
def register():
	C=bpy.context.window_manager.keyconfigs.active;A=C.keymaps['Sculpt']
	for B in reversed(A.keymap_items):
		if B.name=='Sculpt Context Menu':A.keymap_items.remove(B)
	A.keymap_items.new(SCULPTPLUS_OT_gesture_size_strength.bl_idname,'RIGHTMOUSE','CLICK_DRAG')