_I='SCULPT_PLUS'
_H='SCULPT_LEGACY'
_G='DEFAULT'
_F='SIMPLIFY'
_E='DISPLACEMENT_SMEAR'
_D='DISPLACEMENT_ERASER'
_C='DRAW_FACE_SETS'
_B='SCULPT'
_A=None
import bpy
from bl_ui.space_toolsystem_toolbar import VIEW3D_PT_tools_active,_defs_transform,_defs_annotate,_defs_sculpt
from bl_ui.space_toolsystem_common import ToolDef,ToolSelectPanelHelper
from bpy.app import handlers
from typing import List,Dict
unregistered_tools:List[ToolDef]=[]
hidden_brush_tools:Dict[str,ToolDef]={}
accept_brush_tools:set[str]={'MASK',_C,_D,_E,_F}
def generate_from_brushes(dummy=_A):
	B={};E='builtin_brush.';F='brush.sculpt.';type=bpy.types.Brush;G='sculpt_tool'
	for C in type.bl_rna.properties[G].enum_items_static:
		D=C.name;A=C.identifier
		if A not in accept_brush_tools:continue
		B[A]=ToolDef.from_dict(dict(idname=E+D,label=D,icon=F+A.lower(),cursor=_G,data_block=A))
	'\n    name = "Sculpt Brush"\n    idname = "SCULPT_BRUSH"\n    tool_defs[idname] = ToolDef.from_dict(\n        dict(\n            idname=\'sculpt_plus.\' + name,\n            label=name,\n            icon=icon_prefix + \'draw\',\n            cursor=\'DEFAULT\',\n            keymap="3D View Tool: Sculpt",\n            #data_block=\'SCULPT DRAW\',\n            draw_settings=draw_settings__sculpt_brush_tool,\n            operator=\'sculpt.brush_stroke\',\n            #options={\'KEYMAP_FALLBACK\'},\n        )\n    )\n    ';return B
'\n@ToolDef.from_fn\ndef all_brush_tool():\n    def draw_settings(_context, layout, tool):\n        props = tool.operator_properties(SCULPTPLUS_OT_all_brush_tool.bl_idname)\n    return dict(\n        idname="builtin.all_brush",\n        label=\'Sculpt Brush\',\n        operator=SCULPTPLUS_OT_all_brush_tool.bl_idname,\n        icon="brush.gpencil_draw.draw",\n        # cursor=\'DEFAULT\',\n        keymap="3D View Tool: Sculpt Brush",\n        draw_settings=draw_settings,\n    )\n'
@handlers.persistent
def set_sculpt_tools(dummy=_A):print('[SCULPT+] Setting-Up toolbar tools...');"\n    from bpy import context as C\n\n    tool_name = '3D View Tool: Sculpt, Sculpt Brush'\n    cfg = C.window_manager.keyconfigs.default\n    if tool_name not in cfg.keymaps:\n        cfg.keymaps.new(tool_name, space_type='VIEW_3D', region_type='WINDOW')\n        kmi = cfg.keymaps[tool_name].keymap_items\n        if SCULPTPLUS_OT_all_brush_tool.bl_idname not in kmi:\n            kmi.new(SCULPTPLUS_OT_all_brush_tool.bl_idname, 'MIDDLEMOUSE', 'PRESS', any=True)\n    ";A=generate_from_brushes();B=ToolDef.from_dict(dict(idname='builtin_brush.all_brush',label='Sculpt Brush',icon='brush.sculpt.draw',cursor=_G,data_block='DRAW'));"\n    cfg = C.window_manager.keyconfigs.addon\n    if tool_name not in cfg.keymaps:\n        cfg.keymaps.new(tool_name, space_type='VIEW_3D', region_type='WINDOW')\n        kmi = cfg.keymaps[tool_name].keymap_items\n        if SCULPTPLUS_OT_all_brush_tool.bl_idname not in kmi:\n            kmi.new(SCULPTPLUS_OT_all_brush_tool.bl_idname, 'MIDDLEMOUSE', 'ANY', any=True)\n    ";VIEW3D_PT_tools_active._tools[_H]=list(VIEW3D_PT_tools_active._tools[_B]);VIEW3D_PT_tools_active._tools[_I]=[B,_A,_defs_sculpt.generate_from_brushes,_A,A['MASK'],(_defs_sculpt.mask_border,_defs_sculpt.mask_lasso,_defs_sculpt.mask_line),_defs_sculpt.mask_by_color,_A,A[_C],(_defs_sculpt.face_set_box,_defs_sculpt.face_set_lasso),_defs_sculpt.face_set_edit,_A,_defs_sculpt.hide_border,(_defs_sculpt.trim_box,_defs_sculpt.trim_lasso),_defs_sculpt.project_line,_A,_defs_sculpt.mesh_filter,_defs_sculpt.cloth_filter,_defs_sculpt.color_filter,_A,A[_F],A[_E],A[_D],_A,_defs_transform.translate,_defs_transform.rotate,_defs_transform.scale,_defs_transform.transform,_A,*VIEW3D_PT_tools_active._tools_annotate];global hidden_brush_tools;hidden_brush_tools=A
def get_hidden_brush_tools()->Dict[str,ToolDef]:global hidden_brush_tools;return hidden_brush_tools
def toggle_toolbar_tools(use_legacy:bool)->_A:
	if use_legacy:VIEW3D_PT_tools_active._tools[_B]=VIEW3D_PT_tools_active._tools[_H]
	else:VIEW3D_PT_tools_active._tools[_B]=VIEW3D_PT_tools_active._tools[_I]
def register():
	if _B in VIEW3D_PT_tools_active._tools:set_sculpt_tools()
	else:handlers.load_post.append(set_sculpt_tools)
def unregister():
	if set_sculpt_tools in handlers.load_post:handlers.load_post.remove(set_sculpt_tools)