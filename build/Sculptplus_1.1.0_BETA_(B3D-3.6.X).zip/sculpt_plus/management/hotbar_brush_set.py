_A=None
from typing import List
from brush_manager.api import bm_types
class HotbarBrushSet:
	owner:object;brushes:List[bm_types.BrushItem]
	@property
	def layer(self):from .hotbar_layer import HotbarLayer as A;B:A=self.owner;return B
	@property
	def brushes_ids(self)->List[str]:return[A.uuid if A is not _A else''for A in self.brushes]
	def __init__(A,layer,set_size:int=10,type:str='MAIN')->_A:A.owner=layer;(A.brushes):List[bm_types.BrushItem]=[_A]*set_size;A.type=type
	def __del__(A)->_A:A.brushes.clear()
	def switch(A,index_A:int,index_B:int)->_A:' Switch brushes at specified indices. ';C=index_B;B=index_A;A.brushes[B],A.brushes[C]=A.brushes[C],A.brushes[B]
	def asign_brush(A,brush:bm_types.BrushItem|str,at_index:int)->_A:
		C=brush;B=at_index
		if B<0 or B>9:print('ERROR! Index out of range! Expected a value between 0 and 9');return
		if A.layer.uuid in C.hotbar_layers:
			if A.brushes[B]==C:return
			A.unasign_brush(C)
		elif A.brushes[B]is not _A:A.unasign_brush(A.brushes[B])
		A.brushes[B]=C;C.hotbar_layers[A.layer.uuid]=A.type
	def unasign_brush(A,brush:bm_types.BrushItem|str)->_A:
		' Call this function when detect that the brush is moved to another BrushCat or the BrushItem was removed. ';B=brush
		if B not in A.brushes:return
		A.brushes[A.brushes.index(B)]=_A
		if A.layer.uuid not in B.hotbar_layers:print('WARN! BrushItem.hotbar_layers does not contain the layer with UUID:',A.layer.uuid,B.hotbar_layers)
		else:del B.hotbar_layers[A.layer.uuid]
	def clear_owners(A)->_A:A.owner=_A;A.brushes=[(B.cat_id,B.uuid)if B is not _A else('','')for B in A.brushes]
	def ensure_owners(A,layer)->_A:from sculpt_plus.globals import G;A.owner=layer;C=G.bm_data.brush_cats.get;A.brushes=[C(B).items.get(D)if B!=''else _A for(B,D)in A.brushes]