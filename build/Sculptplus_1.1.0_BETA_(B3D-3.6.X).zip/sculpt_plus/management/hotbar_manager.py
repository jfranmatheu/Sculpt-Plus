_A=None
from typing import List
from pathlib import Path
import pickle
from sculpt_plus.path import SculptPlusPaths
from .hotbar_layer import HotbarLayer_Collection
from sculpt_plus.utils.decorators import singleton
from brush_manager.api import bm_types
@singleton
class HotbarManager:
	@classmethod
	def get(C):
		A=C.get_instance()
		if A is not _A:return A
		print(f"[Sculpt+] Instance? HM_DATA@[{id(A)if A is not _A else _A}]");B:Path=SculptPlusPaths.HOTBAR_DATA(as_path=True);from ..management.hotbar_manager import HotbarManager as D
		if not B.exists()or B.stat().st_size==0:print(f"[Sculpt+] HotbarManager not found in path: '{str(B)}'");A=D()
		else:
			with B.open('rb')as E:A:D=pickle.load(E);A.ensure_owners()
			print(f"[Sculpt+] Loaded HM_DATA@[{id(A)}] from file: '{str(B)}'")
		C.set_instance(A);print(f"[Sculpt+] Created/Loaded? HM_DATA@[{id(A)if A is not _A else _A}]");A=C.get_instance();print(f"[Sculpt+] StoredInstance? HM_DATA@[{id(A)if A is not _A else _A}]");return A
	def save(A)->_A:
		B:Path=SculptPlusPaths.HOTBAR_DATA(as_path=True);print(f"[Sculpt+] Saving HM_DATA@[{id(A)}] to file: '{str(B)}'");A.clear_owners()
		with B.open('wb')as C:pickle.dump(A,C)
		A.ensure_owners()
	def clear_owners(A)->_A:A.layers.clear_owners()
	def ensure_owners(A)->_A:A.layers.ensure_owners(A)
	layers:HotbarLayer_Collection;use_alt:bool
	@property
	def brushes(self)->List[bm_types.BrushItem]:
		if(A:=self.layers.active):return A.brushes
		return[]
	@property
	def brushes_ids(self)->List[str]:
		if(A:=self.layers.active):return A.brushes_ids
		return[]
	def select_brush(A,context,brush_index:int)->_A:
		if(B:=A.layers.active):
			if(C:=B.active_set.brushes[brush_index]):C.set_active(context)
	def __init__(A):print(f"[Sculpt+] New HM_DATA@[{id(A)}]");A.active_cat_id='';A.layers=HotbarLayer_Collection(A);(A.use_alt):bool=False;A.layers.add('Default',custom_uuid='DEFAULT')
	def __del__(A):print(f"[Sculpt+] Remove HM_DATA@[{id(A)}]");del A.layers;global _hm_data;_hm_data=_A
	def toggle_alt(A)->_A:A.use_alt=not A.use_alt