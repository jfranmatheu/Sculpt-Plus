import bpy
from bpy.app.handlers import load_post,persistent
from bl_ui.space_toolsystem_toolbar import VIEW3D_PT_tools_active
from bl_ui.space_toolsystem_common import ToolDef
from typing import List,Dict
sculpt_tool_VS_brush_name:Dict[str,str]={}
@persistent
def on_post_load(dummy):
	from sculpt_plus.prefs import get_prefs as B
	if not B(bpy.context).first_time:return
	print('[Sculpt+] Installation complete!');B(bpy.context).first_time=False;return;print('[Sculpt+] Unregistering Sculpt brush tools...');from bpy.utils import unregister_tool as C;D:List[ToolDef]=list(VIEW3D_PT_tools_active.tools_from_context(bpy.context,mode='SCULPT'))
	for A in D:
		if'builtin_brush'in A.idname:C(A);unregistered_tools.append(A)
def register():load_post.append(on_post_load)
def unregister():
	if on_post_load in load_post:load_post.remove(on_post_load)