_B='TEXTURE'
_A=None
from typing import List,Union,Tuple
from uuid import uuid4
from pathlib import Path
import bpy
from bpy.types import ImageTexture as BlTexture,Image as BlImage,Brush as BlBrush,Context,ImageUser
from .image import Image,Thumbnail
from .cat_item import CategoryItem,TextureCatItem
from sculpt_plus.path import DBShelf,ThumbnailPaths
cache_tex_image_ids:dict[str,str]={}
class ImageUserData:
	_bl_attributes:Tuple[str]=('frame_current','frame_duration','frame_offset','frame_start');frame_current:int;frame_duration:int;frame_offset:int;frame_start:int
	def __init__(A,image_user:ImageUser):A.from_image_user(image_user)
	def from_image_user(B,image_user:ImageUser):
		for A in ImageUserData._bl_attributes:setattr(B,A,getattr(image_user,A))
	def to_image_data(B,dst_image_user:ImageUser):
		for A in ImageUserData._bl_attributes:setattr(dst_image_user,A,getattr(B,A))
bl_texture_attributes='use_alpha','use_calculate_alpha','invert_alpha','use_flip_axis','extension','crop_min_x','crop_max_x','crop_min_y','crop_max_y','repeat_x','repeat_y','use_mirror_x','use_mirror_y','checker_distance','use_checker_even','use_checker_odd','use_interpolation','use_mipmap','use_mipmap_gauss','filter_type','filter_eccentricity','filter_lightprobes','filter_size','use_filter_size_min','use_clamp','factor_red','factor_blue','factor_green','intensity','contrast','saturation'
class Texture(TextureCatItem):
	bl_type=_B;id:str;name:str;image:Image;cat_id:str;thumbnail:Thumbnail
	def __init__(A,texture:BlTexture,cat:str='',fake_texture=_A,custom_id:str=_A):
		C=fake_texture;B=texture;super().__init__(cat=cat,custom_id=custom_id);A.name=B.image.name;A.image=Image(B.image,A.id);(A.cat_id):str=cat
		if B.image.source=='SEQUENCE':A.image_user=ImageUserData(B.image_user);A.image.filepath=B.image.filepath_from_user(image_user=B.image_user)
		else:A.image_user=_A
		if C is not _A:A.from_fake_texture(C)
		A.copy_bl_attributes(B)
	def init(A):0
	def copy_bl_attributes(B,bl_texture:BlTexture):
		for A in bl_texture_attributes:setattr(B,A,getattr(bl_texture,A))
	def paste_bl_attributes(B,bl_texture:BlTexture):
		for A in bl_texture_attributes:setattr(bl_texture,A,getattr(B,A))
	def from_fake_texture(B,fake_texture):
		A=fake_texture;B.id=A.id;B.name=A.name
		if A.icon:B.thumbnail=Thumbnail.from_fake_item(A,_B)
	def to_brush(A,context:Context)->_A:
		D=context;G:BlBrush=D.tool_settings.sculpt.brush
		if A.image_user:
			B=bpy.data.textures.get('.'+A.id,_A)
			if not B:B=bpy.data.textures.new('.'+A.id,'IMAGE')
			C=A.image.get_bl_image(paste_attributes=False,ensure_float_buffer=True);B.image=C;A.image_user.to_image_data(B.image_user)
		else:from sculpt_plus.props import Props as E;B:BlTexture=E.TextureSingleton(D);C:BlImage=E.TextureImageSingleton(D);A.image.to_image(C);B.image=C
		A.paste_bl_attributes(B);B['id']=A.id;C['id']=A.image.id;G.texture=B;return;'\n        image: BlImage = Props.TextureImageSingleton(context).copy()\n        texture.image = image\n        for key in Image._bl_attributes:\n            setattr(image, key, getattr(self.image, key))\n        image.filepath = self.image.filepath_raw\n        if not image.has_data or not image.is_float:\n            image.update()\n        if self.image_user is not None:\n            self.image_user.to_image_data(texture.image_user)\n\n        if not image.has_data or not image.is_float:\n            image.update()\n\n        return\n        ';F:BlImage=E.TextureImageSingleton(D)
		if A.image_user is not _A:texture.image=_A;A.image_user.to_image_data(texture.image_user)
		if(F:=A.image.to_image(F)):texture.image=F
	def __del__(A)->_A:
		if(B:=ThumbnailPaths.TEXTURE(A,check_exists=True)):B.unlink()