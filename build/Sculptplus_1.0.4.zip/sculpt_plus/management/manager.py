_O='active_texture'
_N='active_brush'
_M='active_texture_cat'
_L='active_brush_cat'
_K='hotbar'
_J='SEQUENCE'
_I='Untitled'
_H='Simplify'
_G='Multires Displacement Smear'
_F='Multires Displacement Eraser'
_E='Draw Face Sets'
_D='\t> '
_C=False
_B=True
_A=None
from typing import Dict,Union,List,Set,Tuple
import shelve
from os import path
import json
from collections import OrderedDict
from pathlib import Path
from time import time
import bpy
from bpy.types import Brush as BlBrush,Texture as BlTexture,Image as BlImage
from sculpt_plus.path import DBShelf,SculptPlusPaths,DBShelfPaths,DBShelfManager,data_brush_dir,data_texture_dir
from .types.cat import BrushCategory,TextureCategory,Brush,Texture
from sculpt_plus.lib import Icon
from sculpt_plus.management.types.fake_item import FakeViewItem_Brush,FakeViewItem_Texture
builtin_brush_names='Blob','Boundary','Clay','Clay Strips','Clay Thumb','Cloth','Crease',_E,'Draw Sharp','Elastic Deform','Fill/Deepen','Flatten/Contrast','Grab','Inflate/Deflate','Layer','Mask','Multi-plane Scrape',_F,_G,'Nudge','Paint','Pinch/Magnify','Pose','Rotate','Scrape/Peaks','SculptDraw',_H,'Slide Relax','Smooth','Snake Hook','Thumb'
exclude_brush_names={'Mask',_E,_H,_F,_G}
filtered_builtin_brush_names=tuple((A for A in builtin_brush_names if A not in exclude_brush_names))
class HotbarManager:
	brushes:List[str];selected:str;alt_brushes:List[str];alt_selected:str;use_alt:bool
	def __init__(A):(A._brushes):List[str]=[_A]*10;(A._selected):str=_A;(A.alt_selected):str=_A;(A.alt_brushes):List[str]=[_A]*10;(A.use_alt):bool=_C
	def __del__(A):A._selected=_A;A.alt_selected=_A;A._brushes.clear();A.alt_brushes.clear()
	@property
	def brushes(self)->List[str]:
		A=self
		if A.use_alt:return A.alt_brushes
		return A._brushes
	@brushes.setter
	def brushes(self,brushes:List[str]):self._brushes=brushes
	@property
	def selected(self)->str:
		A=self
		if A.use_alt:return A.alt_selected
		return A._selected
	def toggle_alt(A)->_A:A.use_alt=not A.use_alt
	@selected.setter
	def selected(self,item):
		B=self;A=item
		if isinstance(A,str):0
		elif isinstance(A,int):A=B.brushes[A]
		elif isinstance(A,Brush):A=A.id
		else:A=_A;print(f"WARN! Invalid selected hotbar item: {A}")
		if B.use_alt:B.alt_selected=A
		else:B._selected=A
	def serialize(A)->dict:' Serialize hotbar data to a dictionary. ';return{'_brushes':A._brushes,'_selected':A._selected,'alt_brushes':A.alt_brushes,'alt_selected':A.alt_selected}
	def deserialize(A,data:dict)->_A:
		' Load data from dictionary. '
		for (B,C) in data.items():setattr(A,B,C)
class Manager:
	_instance=_A;brush_cats:Dict[str,BrushCategory];brushes:Dict[str,Brush];texture_cats:Dict[str,TextureCategory];textures:Dict[str,Texture];active_brush_cat:BrushCategory;active_texture_cat:TextureCategory;active_sculpt_tool:str;selected_item:str;hotbar:HotbarManager
	@classmethod
	def get(A)->'Manager':
		if A._instance is _A:A._instance=Manager()
		return A._instance
	def __new__(A):
		if A._instance is _A:A._instance=super(Manager,A).__new__(A)
		return A._instance
	def __del__(A):A._active_brush=_A;A.active_texture=_A;A._active_brush_cat=_A;A._active_texture_cat=_A;A.active_sculpt_tool=_A;A.brushes.clear();A.textures.clear();A.brush_cats.clear();A.texture_cats.clear();del A.hotbar
	def __init__(A):B='';(A.initilized):bool=_C;(A.is_data_loaded):bool=_C;(A._active_brush_cat):str=B;(A._active_texture_cat):str=B;(A._active_brush):str=B;(A._active_texture):str=B;(A._active_sculpt_tool):str=B;A.brush_cats=OrderedDict();A.brushes=dict();A.texture_cats=OrderedDict();A.textures=dict();(A.hotbar):HotbarManager=HotbarManager();A._remove_atexit__brushes=[];A._remove_atexit__textures=[];A._remove_atexit__brush_cats=[];A._remove_atexit__texture_cats=[]
	def ensure_data(A)->_A:
		if A.is_data_loaded:
			if A.brush_cats_count==0 or A.brushes_count==0:A.load_default_brushes()
		else:A.load_data()
	' Getters. '
	@property
	def brush_list(self)->List[Brush]:return self.brushes.values()
	@property
	def texture_list(self)->List[Texture]:return self.textures.values()
	@property
	def active_brush_cat(self)->Union[BrushCategory,_A]:return self.brush_cats.get(self._active_brush_cat,_A)
	@active_brush_cat.setter
	def active_brush_cat(self,value:Union[BrushCategory,str]):
		A=value
		if isinstance(A,str):self._active_brush_cat=A
		elif isinstance(A,BrushCategory):self._active_brush_cat=A.id
	@property
	def active_brush(self)->str:return self._active_brush
	@active_brush.setter
	def active_brush(self,brush:Union[Brush,str]):
		B=self;A=brush;C=A.id if isinstance(A,Brush)else A;B._active_brush=C
		if C and(A:=B.get_brush(C)):B.active_texture=A.texture_id;B.active_sculpt_tool=A.sculpt_tool
	@property
	def active_texture(self)->str:return self._active_texture
	@active_texture.setter
	def active_texture(self,texture:Union[Texture,str]):A=texture;B=A.id if isinstance(A,Texture)else A;self._active_texture=B
	@property
	def active_sculpt_tool(self)->str:return self._active_sculpt_tool
	@active_sculpt_tool.setter
	def active_sculpt_tool(self,tool:Union[Brush,str]):A=tool;self._active_sculpt_tool=A.sculpt_tool if isinstance(A,Brush)else A
	@property
	def active_texture_cat(self)->Union[TextureCategory,_A]:return self.texture_cats.get(self._active_texture_cat,_A)
	@active_texture_cat.setter
	def active_texture_cat(self,value:Union[TextureCategory,str]):
		A=value
		if isinstance(A,str):self._active_texture_cat=A
		elif isinstance(A,TextureCategory):self._active_texture_cat=A.id
	@property
	def brushes_count(self)->int:return len(self.brushes)
	@property
	def textures_count(self)->int:return len(self.textures)
	@property
	def brush_cats_count(self)->int:return len(self.brush_cats)
	@property
	def texture_cats_count(self)->int:return len(self.texture_cats)
	def get_brush(A,brush_id:str)->Brush:return A.brushes.get(brush_id,_A)
	def get_texture(A,texture_id:str)->Texture:return A.textures.get(texture_id,_A)
	def get_brush_cat(C,cat:Union[str,Brush,int])->BrushCategory:
		A=cat
		if isinstance(A,int):
			for B in C.brush_cats.values():
				if B.index==A:return B
			return _A
		if isinstance(A,str):
			if(B:=C.brush_cats.get(A,_A)):return B
			for B in C.brush_cats.values():
				if B.name==A:return B
			return _A
		if isinstance(A,Brush):return C.brush_cats.get(A.cat_id,_A)
		return _A
	def get_texture_cat(C,cat:Union[str,Texture,int])->TextureCategory:
		A=cat
		if isinstance(A,int):
			for B in C.texture_cats.values():
				if B.index==A:return B
			return _A
		if isinstance(A,str):
			if(B:=C.texture_cats.get(A,_A)):return B
			for B in C.texture_cats.values():
				if B.name==A:return B
			return _A
		if isinstance(A,Texture):return C.texture_cats.get(A.cat_id,_A)
		return _A
	' Remove Methods. '
	def remove_brush_item(B,brush_id:str)->_A:A=brush_id;C:Brush=B.brushes.pop(A if isinstance(A,str)else A.id);B.get_brush_cat(C).unlink_item(A);B._remove_atexit__brushes.append(C.id);del C
	def remove_texture_item(B,texture_id:str)->_A:A=texture_id;C:Texture=B.textures.pop(A if isinstance(A,str)else A.id);B.get_texture_cat(C).unlink_item(A);B._remove_atexit__textures.append(C.id);del C
	def remove_brush_cat(A,cat:Union[str,BrushCategory])->_A:
		B=cat
		if B is _A:return
		G:BrushCategory=A.active_brush_cat;C:BrushCategory=A.brush_cats.pop(B)if isinstance(B,str)else A.brush_cats.pop(B.id)
		if not C:return
		F:List[str]=C.item_ids;D=A.hotbar;H=set(D.brushes)
		for E in F:
			del A.brushes[E]
			if E in H:D.brushes[D.brushes.index(E)]=_A
		A._remove_atexit__brushes.extend(F);A._remove_atexit__brush_cats.append(B.id)
		if C==G:
			if A.brush_cats_count!=0:A.active_brush_cat=list(A.brush_cats.keys())[0]
		C.clear();del C
	def remove_texture_cat(A,cat:Union[str,TextureCategory])->_A:
		B=cat
		if not B:return
		C:TextureCategory=A.texture_cats.pop(B)if isinstance(B,str)else A.texture_cats.pop(B.id)
		if not C:return
		D:List[str]=C.item_ids
		for E in D:del A.textures[E]
		A._remove_atexit__textures.extend(D);A._remove_atexit__texture_cats.append(B.id)
		if C.id==A.active_texture_cat:
			if A.texture_cats_count!=0:A.active_texture_cat=list(A.texture_cats.keys())[0]
		C.clear();del C
	' Defaults. Reset. '
	def reset_brushes(B,*C:str)->_A:
		with DBShelfManager.BRUSH_DEFAULTS()as D:
			with DBShelfManager.BRUSH_SETTINGS()as E:
				for F in C:A:Brush=D.get(F);E.write(A);B.add_brush(A)
	def reset_brush_cat(B,cat_id:Union[str,BrushCategory])->_A:
		A:BrushCategory=A if isinstance(A,BrushCategory)else B.get_brush_cat(cat_id)
		if A:B.reset_brushes(*A.item_ids)
	' Move from cat to cat. '
	def move_brush(D,brush:Union[Brush,str],from_cat:Union[BrushCategory,str,_A],to_cat:Union[BrushCategory,str])->_A:
		C=to_cat;B=from_cat;A=brush;A=D.get_brush(A,_A)if isinstance(A,str)else A
		if not A:return
		if B is _A:B=D.get_brush_cat(A)
		else:B=D.get_brush_cat(B)if isinstance(B,str)else B
		C=D.get_brush_cat(C)if isinstance(C,str)else C;B.unlink_item(A);C.link_item(A)
	def move_texture(D,texture:Union[Texture,str],from_cat:Union[TextureCategory,str,_A],to_cat:Union[TextureCategory,str])->_A:
		C=to_cat;B=from_cat;A=texture;A=D.get_texture(A,_A)if isinstance(A,str)else A
		if not A:return _A
		if B is _A:B=D.get_texture_cat(A)
		else:B=D.get_texture_cat(B)if isinstance(B,str)else B
		C=D.get_texture_cat(C)if isinstance(C,str)else C;B.unlink_item(A);C.link_item(A)
	' Creation Methods. '
	def add_brush(B,brush:Brush)->_A:A=brush;B.brushes[A.id]=A
	def add_texture(B,texture:Texture)->_A:A=texture;B.textures[A.id]=A
	def new_brush_cat(B,cat_name:str=_I,cat_id:str=_A,check_exists:bool=_C,brush_items:List[Brush]=[])->BrushCategory:
		C=cat_name
		if check_exists and(D:=B.get_brush_cat(C)):return D
		A:BrushCategory=BrushCategory(C,cat_id)
		for E in brush_items:A.link_item(E)
		A.index=B.brush_cats_count;B.brush_cats[A.id]=A;B.active_brush_cat=A.id;DBShelf.BRUSH_CAT.write(A);return A
	def new_texture_cat(B,cat_name:str=_I,cat_id:str=_A,check_exists:bool=_C,texture_items:List[Texture]=[])->TextureCategory:
		C=cat_name
		if check_exists and(D:=B.get_texture_cat(C)):return D
		A:TextureCategory=TextureCategory(C,cat_id)
		for E in texture_items:A.link_item(E)
		A.index=B.texture_cats_count;B.texture_cats[A.id]=A;B.active_texture_cat=A.id;DBShelf.TEXTURE_CAT.write(A);return A
	def load_brushes_from_datablock(B,cat_name:str,cat_id:str,brush_names:List[Union[str,BlBrush]],fake_items:dict={},remove_brush_datablocks:bool=_B)->_A:
		L=fake_items;K=cat_id;J=cat_name;C=remove_brush_datablocks
		if C:Q=bpy.data.brushes.remove;R=bpy.data.images.remove;S=bpy.data.textures.remove
		T:Dict[str,BlBrush]=bpy.data.brushes;M:BrushCategory=B.new_brush_cat(J,K,check_exists=_B);U:TextureCategory=B.new_texture_cat(J,K,check_exists=_B);N=L is not _A;D=_A;O=_A;V=not N
		for G in brush_names:
			A:BlBrush=G if isinstance(G,BlBrush)else T.get(G,_A)
			if A is _A:continue
			if N:D=L.get(A.name,_A)
			H:Brush=Brush(A,fake_brush=D);B.add_brush(H);M.link_item(H)
			if(E:=A.texture):
				if E.type=='IMAGE'and(F:=E.image):
					if F.source in{'FILE',_J}and F.pixels:
						P:Path=Path(F.filepath_from_user())
						if P.exists()and P.is_file():
							if D:O=D.texture
							I:Texture=Texture(E,fake_texture=O);B.add_texture(I);U.link_item(I);H.texture_id=I.id
					if C:R(F)
				if C:S(E)
			if C:Q(A)
		return M
	def load_textures_from_datablock(D,cat_name:str,cat_id:str,image_names:List[Union[str,BlBrush]],fake_items:List[FakeViewItem_Texture]=_A,remove_image_datablocks:bool=_B)->_A:
		F=fake_items;E=image_names;G:Dict[str,BlBrush]=bpy.data.images;C:TextureCategory=D.new_texture_cat(cat_name,cat_id)
		class K:
			def __init__(A,image):B=image;A.name=B.name;A.image=B
		H=F is not _A;L=not H
		with DBShelfManager.BRUSH_SETTINGS()as M:
			for A in E:
				B:BlImage=A if isinstance(A,BlImage)else G.get(A,_A)
				if B is _A:continue
				if B.source not in{'FILE',_J}:continue
				I:Path=Path(B.filepath_from_user())
				if not I.exists()or not I.is_file():continue
				N=F.get(B.name,_A)if H else _A;J:Texture=Texture(K(B),fake_texture=N,generate_thumbnail=L);D.add_texture(J);C.link_item(J);M.write(C)
		if remove_image_datablocks:
			O=G.remove
			for A in E:O(A)
		return C
	def load_default_brushes(A)->_A:print('[SCULPT+] Loading default brushes...');B:BrushCategory=A.load_brushes_from_datablock('Default',_A,filtered_builtin_brush_names,remove_brush_datablocks=_C);A.hotbar.brushes=[A for A in B.item_ids[:10]];B.load_icon(Icon.BRUSH_PENCIL_X.get_path());A.active_brush_cat=B
	def duplicate_brush(B,base_brush_item:Union[Brush,str])->Brush:
		A=base_brush_item
		if isinstance(A,str):return B.duplicate_brush(B.brushes[A])
		if not isinstance(A,Brush):return _A
		B.add_brush(A.copy())
	def load_brushes_from_lib(B,cat_name:str,lib_path:str):
		with bpy.data.libraries.load(lib_path)as(C,A):A.brushes=C.brushes
		B.load_brushes_from_datablock(cat_name,_A,A.brushes)
	def load_datablocks_from_lib(C,lib_path:str,datablocks:dict[str,list[str]])->_A:
		G='images';F='Blend-lib Cat';E='brushes';D=lib_path;A=datablocks
		with bpy.data.libraries.load(D,link=_B)as(K,B):
			for (H,I) in A.items():setattr(B,H,I)
		if E in A and A[E]:C.load_brushes_from_datablock(F,_A,B.brushes,remove_brush_datablocks=_B)
		if G in A and A[G]:C.load_textures_from_datablock(F,_A,B.images,remove_image_datablocks=_B)
		if(J:=bpy.data.libraries.get(Path(D).name,_A)):bpy.data.libraries.remove(J,do_unlink=_B)
	def load_viewitems_from_lib(F,lib_path:str,type:str,items:List[Union[FakeViewItem_Brush,FakeViewItem_Texture]])->_A:
		J='TEXTURE';I='BRUSH';D=lib_path;A=items
		if not A:return
		G:str=Path(D).stem;B:dict[str,str]={}
		def H(item,datablocks)->bool:
			C=datablocks;A=item
			if A is _A:return _C
			if A.name in C:C.remove(C[A.name])
			B[A.name]=A;return _B
		E=time()
		with bpy.data.libraries.load(D,link=_B)as(L,C):
			if type==I:C.brushes=[B.name for B in A if H(B,bpy.data.brushes)]
			elif type==J:C.images=[B.name for B in A if H(B,bpy.data.images)]
		print('[TIME] Linking datablocks from library -> %.2fs'%(time()-E));E=time()
		if type==I:F.load_brushes_from_datablock(G,_A,C.brushes,fake_items=B,remove_brush_datablocks=_B)
		elif type==J:F.load_textures_from_datablock(G,_A,C.images,fake_items=B,remove_image_datablocks=_B)
		print('[TIME] Create items from datablocks -> %.2fs'%(time()-E))
		if(K:=bpy.data.libraries.get(Path(D).name,_A)):bpy.data.libraries.remove(K,do_unlink=_B)
		del B;del A
	def new_texture_cat_from_directory(A,texture_dirpath:str)->_A:0
	def load_brushes_from_temporal_data(A)->_A:' Load Brushes data from temporal (fake items) data. '
	' Generic methods, load and save. '
	def load_data(A)->_A:
		D='.dat';A.is_data_loaded=_B;E:str=DBShelfPaths.BRUSH_SETTINGS;F:str=DBShelfPaths.BRUSH_CAT;C:str=SculptPlusPaths.CONFIG_FILE()
		if not path.exists(F+D)or not path.isfile(F+D):print('WARN! BrushCategory Database not found: '+F);A.load_default_brushes();return
		if not path.exists(E+D)or not path.isfile(E+D):print('WARN! Brush Database not found: '+E);A.load_default_brushes();return
		if not path.exists(C)or not path.isfile(C):print('WARN! Config file not found: '+C);A.load_default_brushes();return
		print('[SCULPT+] Loading brushes from database...')
		with DBShelfManager.BRUSH_SETTINGS()as O:
			for (P,G) in O.get_items():print(_D,G.name);A.brushes[P]=G
		print('[SCULPT+] Loading brush categories from database...')
		with DBShelfManager.BRUSH_CAT()as Q:
			for (R,H) in Q.get_items():print(_D,H.name);A.brush_cats[R]=H
		print('[SCULPT+] Loading textures from database...')
		with DBShelfManager.TEXTURE()as S:
			for (T,I) in S.get_items():print(_D,I.name);A.textures[T]=I
		print('[SCULPT+] Loading texture categories from database...')
		with DBShelfManager.TEXTURE_CAT()as U:
			for (V,J) in U.get_items():print(_D,J.name);A.texture_cats[V]=J
		print('[SCULPT+] Loading config file...');B:dict={}
		with open(C,'r')as W:B=json.load(W);print('[SCULPT+] Loading hotbar config...');X=B.pop(_K);A.hotbar.deserialize(X)
		K:str=B[_L]
		if K in A.brush_cats:A.active_brush_cat=K
		L:str=B[_M]
		if L in A.texture_cats:A.active_texture_cat=L
		M:str=B[_N]
		if M in A.brushes:A.active_brush=M
		N:str=B[_O]
		if N in A.textures:A.active_texture=N
		if A.brushes_count==0 or A.brush_cats_count==0:A.load_default_brushes()
	def save_all(A)->_A:
		if not A.brushes and not A.textures and not A.brush_cats and not A.texture_cats:return
		print('[Sculpt+] Saving UI config...');H={_N:A._active_brush if A._active_brush else _A,_O:A._active_texture if A._active_texture else _A,_L:A._active_brush_cat if A._active_brush_cat else _A,_M:A._active_texture_cat if A._active_texture_cat else _A,_K:A.hotbar.serialize()}
		with open(SculptPlusPaths.CONFIG_FILE(),'w')as I:json.dump(H,I,indent=4,ensure_ascii=_B)
		if A.brushes!={}:
			print('[Sculpt+] Saving brushes..')
			with DBShelfManager.BRUSH_SETTINGS()as B:
				for J in A.brushes.values():B.write(J)
				for K in A._remove_atexit__brushes:B.remove(K)
				A._remove_atexit__brushes.clear()
		if A.textures!={}:
			print('[Sculpt+] Saving textures..')
			with DBShelfManager.TEXTURE()as C:
				for L in A.textures.values():C.write(L)
				for M in A._remove_atexit__textures:C.remove(M)
				A._remove_atexit__textures.clear()
		if A.brush_cats!={}:
			print('[Sculpt+] Saving brush_cats..')
			with DBShelfManager.BRUSH_CAT()as D:
				for E in A.brush_cats.values():D.write(E);print(_D,E.name)
				for N in A._remove_atexit__brush_cats:D.remove(N)
				A._remove_atexit__brush_cats.clear()
		if A.texture_cats!={}:
			print('[Sculpt+] Saving texture_cats..')
			with DBShelfManager.TEXTURE_CAT()as F:
				for G in A.texture_cats.values():F.write(G);print(_D,G.name)
				for O in A._remove_atexit__texture_cats:F.remove(O)
				A._remove_atexit__texture_cats.clear()