_d='builtin_brush.Draw Face Sets'
_c='builtin_brush.Mask'
_b='icon_scale'
_a='post_func_ctx'
_Z='iterations'
_Y='auto_iteration_count'
_X='SHARPEN'
_W='Mask Sharpen'
_V='SMOOTH'
_U='Mask Smooth'
_T='Mask Shrink'
_S='Mask Grow'
_R='INVERT'
_Q='Mask Invert'
_P='Mask Clear'
_O='sculpt.face_set_edit'
_N='SCULPT'
_M='builtin.face_set_edit'
_L='name'
_K='toggle'
_J='SHRINK'
_I='GROW'
_H='mode'
_G=False
_F='filter_type'
_E='icon'
_D='kwargs'
_C='args'
_B='func'
_A='label'
from typing import Any,Dict,Tuple
from bpy import ops as OPS
from sculpt_plus.lib.icons import BrushIcon,Icon
from.wg_group_but import ButtonGroup,MultiButtonGroup
"\n{ # MASK FILL.\n            'func': OPS.paint.mask_flood_fill,\n            'args': (),\n            'kwargs': {\n                'mode':   'VALUE',\n                'value':  1\n            },\n            'icon': 'F'\n        },\n"
def set_face_set_edit_mode(ctx,mode:str)->None:
	A=ctx.workspace.tools.from_space_view3d_mode(_N,create=_G)
	if A:A.operator_properties(_O).mode=mode
def get_face_set_edit_mode(ctx)->None:
	A=ctx
	if A.workspace.tools.from_space_view3d_mode(A.mode,create=_G).idname!=_M:return
	B=A.workspace.tools.from_space_view3d_mode(_N,create=_G)
	if B:return B.operator_properties(_O).mode
class MaskGroup(ButtonGroup):fill_by:str='COLS';relative_to_bar_pos=0,1;items:Tuple[Dict[str,Any]]=({_A:_P,_B:OPS.paint.mask_flood_fill,_C:(),_D:{_H:'VALUE','value':0},_E:Icon.MASK_CLEAR},{_A:_Q,_B:OPS.paint.mask_flood_fill,_C:(),_D:{_H:_R},_E:Icon.MASK_INVERT},{_A:_S,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_I},_E:'G'},{_A:_T,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_J},_E:'K'},{_A:_U,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_V},_E:'S'},{_A:_W,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_X},_E:'N'},{_A:'Mask Contrast Increase',_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:'CONTRAST_INCREASE',_Y:_G,_Z:2},_E:'CI'},{_A:'Mask Contrast Decrease',_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:'CONTRAST_DECREASE',_Y:_G,_Z:2},_E:'CD'})
class MaskMultiGroup(MultiButtonGroup):fill_by:str='COLS';rows:int=2;align:str='LEFT';align_dir:str='RIGHT';relative_to_bar_pos=0,0;group_items:Tuple[Tuple[Dict[str,Any]]]=(({_A:_P,_B:OPS.paint.mask_flood_fill,_C:(),_D:{_H:'VALUE','value':0},_E:Icon.MASK_CLEAR},{_A:_Q,_B:OPS.paint.mask_flood_fill,_C:(),_D:{_H:_R},_E:Icon.MASK_INVERT},{_A:_S,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_I},_E:Icon.MASK_GROW},{_A:_T,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_J},_E:Icon.MASK_SHRINK},{_A:_U,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_V},_E:Icon.MASK_SMOOTH},{_A:_W,_B:OPS.sculpt.mask_filter,_C:(),_D:{_F:_X},_E:Icon.MASK_SHARP}),({_A:'Face Set Grow (Tool)',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_L:_M},_a:lambda ctx:set_face_set_edit_mode(ctx,_I),_E:Icon.FACESET_GROW,_K:lambda ctx:get_face_set_edit_mode(ctx)==_I},{_A:'Face Set Shrink (Tool)',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_L:_M},_a:lambda ctx:set_face_set_edit_mode(ctx,_J),_E:Icon.FACESET_SHRINK,_K:lambda ctx:get_face_set_edit_mode(ctx)==_J}),({_A:'Mask Brush Tool',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_L:_c},_E:BrushIcon.MASK,_b:1.05,_K:lambda ctx:ctx.workspace.tools.from_space_view3d_mode(ctx.mode,create=_G).idname==_c},{_A:'Draw Face Sets Tool',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_L:_d},_E:BrushIcon.DRAW_FACE_SETS,_b:1.05,_K:lambda ctx:ctx.workspace.tools.from_space_view3d_mode(ctx.mode,create=_G).idname==_d}))