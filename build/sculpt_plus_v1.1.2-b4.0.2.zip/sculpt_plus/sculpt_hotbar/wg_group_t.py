_M='builtin.transform'
_L='builtin.rotate'
_K='builtin.scale'
_J='builtin.move'
_I=False
_H='name'
_G='toggle'
_F='icon_scale'
_E='icon'
_D='kwargs'
_C='args'
_B='func'
_A='label'
from typing import Any,Dict,Tuple
from bpy import ops as OPS
from sculpt_plus.lib.icons import Icon
from.wg_group_but import ButtonGroup,MultiButtonGroup
class TransformGroup(ButtonGroup):fill_by:str='COLS';rows:int=2;align:str='LEFT';align_dir:str='RIGHT';relative_to_bar_pos=1,0;items:Tuple[Dict[str,Any]]=({_A:'Transform Move',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_H:_J},_E:Icon.TRANSFORM_TRANSLATE,_F:1.1,_G:lambda ctx:ctx.workspace.tools.from_space_view3d_mode(ctx.mode,create=_I).idname==_J},{_A:'Transform Scale',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_H:_K},_E:Icon.TRANSFORM_SCALE,_F:1.1,_G:lambda ctx:ctx.workspace.tools.from_space_view3d_mode(ctx.mode,create=_I).idname==_K},{_A:'Transform Rotate',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_H:_L},_E:Icon.TRANSFORM_ROTATE,_F:1.1,_G:lambda ctx:ctx.workspace.tools.from_space_view3d_mode(ctx.mode,create=_I).idname==_L},{_A:'Transform Move/Rotate/Scale',_B:OPS.wm.tool_set_by_id,_C:(),_D:{_H:_M},_E:Icon.TRANSFORM_MULTI,_F:1.1,_G:lambda ctx:ctx.workspace.tools.from_space_view3d_mode(ctx.mode,create=_I).idname==_M})