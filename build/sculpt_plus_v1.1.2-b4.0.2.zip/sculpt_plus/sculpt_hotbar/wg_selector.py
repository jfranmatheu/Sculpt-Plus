_B=False
_A=None
from.wg_base import WidgetBase,Vector,SCULPTPLUS_AddonPreferences,Canvas
from.di import DiLine,DiRct,DiText,get_rect_center,DiCage
class WidgetSelector(WidgetBase):
	static_items=();default_item=_A;label='Select an item';active_item:str;active_index:int
	def load_items(A):return()
	def init(A)->_A:
		A.expanded=_B;A.hovered_index=_A;A.active_item=A.default_item;A.active_index=-1 if A.default_item is _A else A.items.index(A.default_item)
		if A.static_items:A.items=A.static_items
		else:A.items=A.load_items()
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		A.item_height=30*cv.scale
		if not A.expanded:return
		C=max(0,A.active_index);D=len(A.items);B=D*A.item_height;E=C*A.item_height;A.pos=A.pos+Vector((0,E-B));A.size=Vector((A.size.x,B))
	'\n    def on_hover(self, m: Vector, p: Vector = None, s: Vector = None) -> bool:\n        if self.expanded:\n            ret = super().on_hover(m)\n            if not ret:\n                return False\n            #print("Iter items hover item...")\n            #self.hovered_index = self.iter_items(self.on_hover_item, m) # self.hovered_index = \n            return True\n\n        return super().on_hover(m, p, s)\n    '
	def on_leftmouse_press(A,ctx,cv:Canvas,m:Vector)->_A:return not A.expanded
	def modal_enter(A,ctx,cv:Canvas,m:Vector)->_A:
		print('Start')
		if not A.items:A.items=A.load_items()
		A.expanded=True;A.update(cv,_A)
	def confirm(A,ctx,cv:Canvas,m:Vector)->_A:
		if not A.expanded:return _B
		print(A.hovered_index)
		if A.hovered_index:A.active_index=A.hovered_index;A.active_item=A.items[A.hovered_index]
	def modal_exit(A,ctx,cv:Canvas,m:Vector,cancel:bool=_B)->_A:
		print('End')
		if not cancel:A.confirm(ctx,cv,m)
		A.hovered_index=_A;A.expanded=_B;A.update(cv,_A)
	def iter_items(A,callback:callable,*F,**G):
		'\n        act_idx = self.active_index\n        tot_rows = len(self.items)\n        s_y = tot_rows * self.item_height\n        y_off = act_idx * self.item_height\n        p = self.pos.copy()\n        p.y += (y_off - s_y)\n        ';B=A.pos.copy();D=Vector((A.size.x,A.item_height));E=_A
		for(C,H)in enumerate(A.items):
			if E is _A and A.on_hover_item(B,D,_A,_A,A.cv.mouse):E=C
			callback(B,D,H,C,*F,**G);B.y+=A.item_height
		A.hovered_index=C
	def on_hover_item(A,ipos,isize,item,index,m:Vector)->int:return super(WidgetSelector,A).on_hover(m,ipos,isize)
	def draw_item(C,ipos,isize,item,index:int,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		D=prefs;B=isize;A=ipos;E=item[1]if C.expanded else item[1]+'  ▼';DiText(get_rect_center(A,B),E,14,scale,pivot=(.5,.5))
		if index==C.active_index:DiCage(A,B,1.5,D.theme_active_slot_color)
		else:DiLine(A,A+Vector((B.x,0)),1.5,Vector(D.theme_sidebar)*1.25)
	def draw(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):
		C=prefs;B=scale;D=Vector((A.size.x,A.item_height));DiRct(A.pos,A.size,(.24,.24,.24,.9));DiCage(A.pos,A.size,2.4,(.16,.16,.16,.9))
		if A.expanded:
			A.iter_items(A.draw_item,B,C)
			if A.active_item is _A:A.draw_item(A.pos,D,(_A,A.label),_A,B,C)
		else:A.draw_item(A.pos,D,A.active_item if A.active_item else(_A,A.label),A.active_index if A.active_item else _A,B,C)