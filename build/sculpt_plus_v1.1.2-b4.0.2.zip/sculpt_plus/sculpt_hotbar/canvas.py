_D=1.
_C=True
_B=False
_A=None
import functools
from time import time
from datetime import datetime
from.di import DiCage,DiRct,DiBr,DiText
from mathutils import Vector
from bpy.app import timers
import bpy
from bpy.app import timers
import functools
from.types import Return
from sculpt_plus.prefs import get_prefs
from.di import set_font
from sculpt_plus.lib.fonts import Fonts
from sculpt_plus.globals import G
from sculpt_plus.prefs import SCULPTPLUS_AddonPreferences
start_time=0
counter=0
fps_count=0
class Canvas:
	def __init__(A,reg,prefs:SCULPTPLUS_AddonPreferences)->_A:B=reg;A.size=Vector((B.width,B.height));A.pos=Vector((0,0));A.scale=_D;A.reg=B;A.mouse=Vector((0,0));A.hover_ctx=_A;A.tag_redraw=_B;A.modal_override_all=_B;A.init_ui(prefs);set_font(Fonts.NUNITO);A.draw_progress=_B;A.progress=0;A.progress_label=''
	def progress_start(A,label:str=''):A.progress=0;A.draw_progress=_C;A.progress_label=label;A.progress_time=time()
	def progress_stop(A):A.draw_progress=_B;A.progress_label='';print('[TIME] Progress Spent -> %.2f seconds'%(time()-A.progress_time))
	def progress_update(A,progress:float,label:str=''):
		B=label;A.progress=progress
		if B:A.progress_label=B
	def init_ui(A,prefs:SCULPTPLUS_AddonPreferences):C=prefs;from.wg_base import WidgetBase as B;from.wg_hotbar import Hotbar as D;from.wg_shelf import Shelf as E,ShelfDragHandle as F,ShelfSearch as G,ShelfGrid as H,ShelfGridItemInfo;from.wg_group_mask import MaskGroup,MaskMultiGroup as I;from.wg_group_t import TransformGroup as J;from.wg_shelf_sidebar import ShelfSidebar as K,ShelfSidebarActions as L;from.wg_ctx_switcher import SidebarContextSwitcher as M;from.wg_ctx_pie import ShelfGridItemCtxPie as N,ShelfSidebarCatCtxPie as O;(A.wg_on_hover):B=_A;(A.active_wg):B=_A;(A.active_ctx_widget):B=_A;(A.hotbar):D=D(A);(A.shelf):E=E(A);(A.shelf_drag):F=F(A);(A.shelf_search):G=G(A);(A.shelf_grid):H=H(A);(A.group_mask):I=I(A);(A.group_t):J=J(A);(A.shelf_sidebar):K=K(A);(A.shelf_sidebar_actions):L=L(A);(A.shelf_ctx_switcher):M=M(A);(A.ctx_shelf_item):N=N(A);(A.ctx_shelf_sidebar_item):O=O(A);A.children=A.hotbar,A.shelf,A.shelf_drag,A.shelf_search,A.shelf_sidebar,A.shelf_grid,A.shelf_sidebar_actions,A.shelf_ctx_switcher,A.group_mask,A.group_t,A.ctx_shelf_item,A.ctx_shelf_sidebar_item;A.group_mask.enabled=C.show_hotbar_mask_group;A.group_t.enabled=C.show_hotbar_transform_group;A.prev_event_time=time();A.prev_event=_A,_A;global start_time;start_time=time()
	def update(A,off:tuple,dimensions:tuple,scale:float,prefs)->'Canvas':
		B=dimensions
		if B:A.size=Vector(B)
		if off:A.pos=Vector(off)
		A.scale=scale
		for C in A.children:C.update(A,prefs)
		return A
	def refresh(A,ctx=_A):
		if ctx:ctx.region.tag_redraw()
		else:A.reg.tag_redraw()
	def test(A,ctx,m):return 1 if A._on_hover(ctx,m)else-1
	@staticmethod
	def set_cursor(_state=_C):import bpy;bpy.context.tool_settings.sculpt.show_brush=_state
	def _on_hover(A,ctx,m):
		B=ctx;A.mouse=Vector(m);A.hover_ctx=B
		if A.active_ctx_widget:A.active_ctx_widget._on_hover(B,A.mouse);return _C
		C=_B
		if A.wg_on_hover and A.wg_on_hover._is_on_hover:
			if A.wg_on_hover._on_hover(B,A.mouse):
				if A.wg_on_hover.interactable:return _C
				C=_C
		for D in reversed(A.children):
			if C and D==A.wg_on_hover:continue
			if D._on_hover(B,A.mouse):
				if C:A.wg_on_hover._is_on_hover=_B;A.wg_on_hover.on_hover_exit()
				if not A.wg_on_hover:timers.register(functools.partial(Canvas.set_cursor,_B),first_interval=.05)
				else:A.refresh(B)
				A.wg_on_hover=D;return _C
		if C:return _C
		if A.wg_on_hover:A.refresh(B);timers.register(functools.partial(Canvas.set_cursor,_C),first_interval=.05);A.wg_on_hover=_A
		if A.shelf.expand:return _C
		return _B
	def invoke(A,ctx,evt):
		C=ctx;B=evt;D,E=A.prev_event
		if D==B.type and E==B.value:
			if time()-A.prev_event_time<.2:
				if B.type in{'WHEELUPMOUSE','WHEELDOWNMOUSE'}:0
				else:return Return.FINISH()
		A.prev_event_time=time();A.prev_event=B.type,B.value
		if B.type=='LEFT_ALT':
			if B.value=='PRESS':G.hm_data.toggle_alt()
			A.refresh(C);return Return.FINISH()
		if not A.wg_on_hover:
			if A.shelf.expand and not A.shelf.anim_pool and B.type in{'LEFTMOUSE','RIGHTMOUSE','ESC'}:A.shelf.expand=_B
			return Return.FINISH()
		if not A.wg_on_hover.interactable:return Return.FINISH()
		A.refresh(C);F=Vector((B.mouse_region_x,B.mouse_region_y))
		if A.wg_on_hover.invoke(C,B,A,F,get_prefs(C)):A.inject_submodal(C,A.wg_on_hover);return Return.RUN()
		return Return.FINISH()
	def modal(A,ctx,evt,tweak):
		C=evt;B=ctx;A.refresh(B);D=Vector((C.mouse_region_x,C.mouse_region_y))
		if A.active_wg:
			if not A.active_wg.modal(B,C,A,D):
				A.active_wg.in_modal=_B;A.active_wg.modal_exit(B,A,A.mouse);A.active_wg=_A
				if A.active_ctx_widget is _A:return Return.FINISH()
		if A.active_ctx_widget:
			if not A.active_ctx_widget.modal(B,C,A,D):
				A.active_ctx_widget.in_modal=_B;A.active_ctx_widget.modal_exit(B,A,A.mouse);A.active_ctx_widget=_A
				if A.active_wg:A.active_wg.in_modal=_B;A.active_wg.modal_exit(B,A,A.mouse,cancel=_C);A.active_wg=_A
				return Return.FINISH()
		return Return.RUN()
	def exit(A,ctx,cancel:bool=_B):
		B=ctx;B.area.header_text_set(_A)
		if A.active_wg:A.refresh(B);A.active_wg.in_modal=_B;A.active_wg.modal_exit(B,A,A.mouse,cancel=cancel);A.active_wg=_A
		if A.active_ctx_widget:A.active_ctx_widget=_A
	def inject_submodal(A,ctx,widget):B=widget;A.active_wg=B;A.wg_on_hover=B;B.in_modal=_C;B.modal_enter(ctx,A,A.mouse);A.refresh(ctx)
	def inject_ctx_widget(A,widget,override_all:bool=_B)->_A:B=widget;A.wg_on_hover=B;B.in_modal=_C;A.active_ctx_widget=B;A.modal_override_all=override_all;A.refresh()
	def draw(A,ctx):
		B=ctx
		if get_prefs(B).first_time:DiText(Vector((10,10)),'Please, restart Blender to complete Sculpt+ installation!',32,_D,(_D,.2,.1,_D));return
		from gpu import state as H;H.blend_set('ALPHA');D=get_prefs(B)
		if A.active_ctx_widget and A.modal_override_all:A.active_ctx_widget._draw(B,A,A.mouse,A.scale,D);A.active_ctx_widget.draw_over(B,A,A.mouse,A.scale,D);return
		global counter;global fps_count;global start_time
		for E in A.children:E._draw(B,A,A.mouse,A.scale,D)
		for E in A.children:E.draw_over(B,A,A.mouse,A.scale,D)
		if A.draw_progress:
			F=Vector((B.region.width,B.region.height))*.5;C=Vector((B.region.width*.6,32*A.scale));G=F-C*.5;DiRct(G,C,(.05,.05,.05,_D));DiRct(G+Vector((3,3))*A.scale,Vector((C.x*A.progress,C.y))-Vector((6,6))*A.scale,(.3,.5,.95,_D));DiCage(G,C,3.,(.1,.1,.1,_D));I=time()-A.progress_time;"\n            m = timer / 60\n            m = int(m) if m >= 1 else 0\n            if m >= 1:\n                timer -= m\n            s = int(timer)\n            ms = int((timer - s) * 100)\n            print('%i:%i:%i' % (m, s, ms))\n            ";J=datetime.fromtimestamp(I).strftime('%M:%S.%f')[:-4];DiText(F,str(int(A.progress*100))+'%  /  '+J,16,A.scale,pivot=(.5,.5),shadow_props={})
			if A.progress_label:DiText(F+Vector((0,(16+8)*A.scale)),A.progress_label,20,A.scale,pivot=(.5,0),draw_rect_props={},shadow_props={})
		DiText(Vector((10,10)),'FPS: '+str(fps_count),9,_D,(_D,.2,.1,_D));counter+=1
		if time()-start_time>_D:fps_count=int(counter/(time()-start_time));counter=0;start_time=time()
		H.blend_set('NONE')