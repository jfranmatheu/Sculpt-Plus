_F='WINDOW'
_E='RELEASE'
_D=None
_C='LEFT_ALT'
_B='Sculpt'
_A=True
numkeys='ONE','TWO','THREE','FOUR','FIVE','SIX','SEVEN','EIGHT','NINE','ZERO'
hotkeys='A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','ZERO','ONE','TWO','THREE','FOUR','FIVE','SIX','SEVEN','EIGHT','NINE','LEFT_ARROW','DOWN_ARROW','RIGHT_ARROW','UP_ARROW','LEFTMOUSE','MIDDLEMOUSE','RIGHTMOUSE','PEN','ERASER','WHEELUPMOUSE','WHEELDOWNMOUSE','WHEELINMOUSE','WHEELOUTMOUSE','RET','SPACE','BACK_SPACE','DEL','TIMER'
addon_keymaps=[]
import bpy
from bpy.types import KeyConfig,KeyConfigPreferences,KeyConfigurations,KeyMap,KeyMapItem,KeyMapItems
op='gizmogroup.gizmo_tweak'
def register():
	E='PRESS';C=False;from.reg import Controller;from.ops import SCULPTHOTBAR_OT_set_brush as I;from sculpt_plus.management.operators import SCULPTPLUS_OT_set_hotbar_alt as D;from bpy import context as J;B=J.window_manager.keyconfigs.addon
	if not B:return
	if not B.keymaps.__contains__(_B):B.keymaps.new(_B,space_type='EMPTY',region_type=_F)
	A=B.keymaps[_B].keymap_items;F=I.bl_idname
	for(G,H)in enumerate(numkeys):A.new(F,H,E).properties.index=G;A.new(F,H,E,alt=_A).properties.index=G
	A.new(D.bl_idname,_C,E,alt=_A).properties.enabled=_A;A.new(D.bl_idname,_C,_E,alt=C).properties.enabled=C;A.new(D.bl_idname,_C,_E,alt=C).properties.enabled=C
def unregister():
	from.ops import SCULPTHOTBAR_OT_set_brush as C;from sculpt_plus.management.operators import SCULPTPLUS_OT_set_hotbar_alt as D;from bpy import context as E;A=E.window_manager.keyconfigs.addon;F={C.bl_idname,D.bl_idname}
	if A.keymaps.__contains__(_B):
		for B in A.keymaps[_B].keymap_items:
			if B.idname==F:A.keymaps[_B].keymap_items.remove(B)
class WidgetKM:
	@classmethod
	def setup_keymap(A,keyconfig:KeyConfig):return create_hotbar_km(A,keyconfig)
def create_hotbar_km(cls=_D,keyconfig=_D):
	F='VIEW_3D';E='ANY';C=keyconfig;B=cls
	if B:0
	else:from.reg import Controller as G;B=G
	if C is _D:C=bpy.context.window_manager.keyconfigs.addon
	if C.preferences is _D:
		A=bpy.context.window_manager.keyconfigs.addon.keymaps.new(B.bl_idname,space_type=F,region_type=_F)
		for D in hotkeys:A.keymap_items.new(op,D,E,any=_A);A.keymap_items.new(op,D,_E,any=_A)
		A.keymap_items.new(op,_C,E,alt=_A);return A
	if(A:=C.keymaps.get(B.bl_idname,_D)):
		if A.keymap_items and len(A.keymap_items)>1:return A
	A=C.keymaps.new(name=B.bl_idname,space_type=F,region_type=_F)
	for D in hotkeys:A.keymap_items.new(op,D,E,any=_A);A.keymap_items.new(op,D,_E,any=_A)
	A.keymap_items.new(op,_C,E,alt=_A);return A