_A=None
from.wg_base import WidgetBase,Canvas,Vector,SCULPTPLUS_AddonPreferences
from.wg_but import ButtonGroup
from sculpt_plus.lib.icons import Icon
from brush_manager.globals import GLOBALS
from brush_manager.api import BM_UI
class SidebarContextSwitcher(ButtonGroup):
	but_ctx_brush:object;but_ctx_texture:object
	def init(A)->_A:
		B='ENABLED';super().init();A.but_ctx_brush=_A;A.but_ctx_texture=_A;A.button_style['outline_color']=.24,.24,.24,.9;A.button_style['color']=.16,.16,.16,.65;A.style['separator_color']=_A
		def C(cv:Canvas,ctx,ctx_type:str,target_button):
			C=BM_UI.get_data(ctx);C.ui_context_item=ctx_type
			if hasattr(cv,'shelf_grid_item_info'):
				if GLOBALS.is_context_texture_item:cv.shelf_grid_item_info.expand=True
				else:cv.shelf_grid_item_info.expand=False
			for D in A.buttons:D.set_state(B,remove=True)
			target_button.set_state(B);cv.refresh(ctx)
		A.but_ctx_brush=A.new_button('',icon=Icon.PAINT_BRUSH,on_click_callback=lambda ctx,cv:C(cv,ctx,'BRUSH',A.but_ctx_brush));A.but_ctx_texture=A.new_button('',icon=Icon.TEXTURE_OPACITY,on_click_callback=lambda ctx,cv:C(cv,ctx,'TEXTURE',A.but_ctx_texture));A.but_ctx_brush.set_state(B)
	def update(A,cv:Canvas,prefs:SCULPTPLUS_AddonPreferences)->_A:
		B=cv.shelf_sidebar;C=8*cv.scale;A.size=Vector((32,64+C))*cv.scale;A.pos=B.get_pos_by_relative_point(Vector((0,1)));A.pos.x-=B.margin+A.size.x;A.pos.y-=A.size.y-B.header_height
		if A.but_ctx_brush is _A or A.but_ctx_texture is _A:return
		D=Vector((32,32))*cv.scale;A.but_ctx_texture.pos=A.pos.copy();A.but_ctx_brush.pos=A.pos+Vector((0,D.y+C));A.but_ctx_brush.size=A.but_ctx_texture.size=D
	def poll(A,_context,cv:Canvas)->bool:return cv.shelf.expand and cv.shelf.size.y>A.size.y
	def draw_pre(A,context,cv:Canvas,mouse:Vector,scale:float,prefs:SCULPTPLUS_AddonPreferences):0