_A='WINDOW'
import bpy
from bpy.types import SpaceView3D
draw_handler=None
def draw_callback():
	from.reg import Controller as B;A=bpy.context
	if not B.poll(A):return
	bpy.sculpt_hotbar.get_cv(A).draw(A)
def register():global draw_handler;draw_handler=SpaceView3D.draw_handler_add(draw_callback,(),_A,'POST_PIXEL')
def unregister():
	global draw_handler
	if draw_handler is not None:SpaceView3D.draw_handler_remove(draw_handler,_A);draw_handler=None