bl_info={'name':'Sculpt +','author':'J. Fran Matheu (@jfranmatheu)','description':'','blender':(4,0,2),'version':(1,1,2),'location':"Topbar [S+] button > 'Sculpt+' WorkSpace",'warning':'BETA VERSION! May be unstable!','category':'General'}
PILLOW_VERSION='Pillow>=9.3.0'
BM_VERSION='v1.0-b3.6.x'
USE_DEV_ENVIRONMENT=False
if __package__!='sculpt_plus':import sys;print("[Sculpt+] Please, rename the addon folder as 'sculpt_plus'");sys.exit(0)
import bpy
if bpy.app.background:
	print("[Sculpt+] WARN! Addon doesn't work in background!")
	def register():0
	def unregister():0
else:
	from.import install_deps;install_deps.install();from.import auto_load;auto_load.init(USE_DEV_ENVIRONMENT)
	def register():auto_load.register()
	def unregister():auto_load.unregister()