from enum import Enum
class CallEnum(Enum):
	@staticmethod
	def action(key:str,value):0
	def __call__(A):return CallEnum.action(A.name,A.value)
class CallEnumValue(Enum):
	@staticmethod
	def action(value):0
	def __call__(A):return CallEnumValue.action(A.value)
class CallEnumName(Enum):
	@staticmethod
	def action(key:str):0
	def __call__(A):return CallEnumName.action(A.name)