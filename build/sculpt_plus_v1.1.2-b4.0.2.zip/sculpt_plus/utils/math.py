_A=False
from math import pi,sin,asin,cos,radians,atan2,hypot,acos,sqrt
from mathutils import Vector
class Rect:
	def __init__(A,corner,opposite_corner,_type:str='BOTTOM_LEFT'):
		C=opposite_corner;B=corner
		if _type=='TOP_LEFT':A.xi=B[0];A.xf=C[0];A.yf=B[1];A.yi=C[1]
		else:A.xi,A.yi=B;A.xf,A.yf=C
def vector(*A)->Vector:return Vector(A)
def vector2(x,y)->Vector:return Vector((x,y))
def vector3(x,y,z)->Vector:return Vector((x,y,z))
def map_value(val,src,dst):'\n    Scale the given value from the scale of src to the scale of dst.\n    ';B=dst;A=src;return(val-A[0])/(A[1]-A[0])*(B[1]-B[0])+B[0]
def mix(x,y,a):return x*(1-a)+y*a
def dotproduct(v1,v2):return sum(A*B for(A,B)in zip(v1,v2))
def length(v):return sqrt(dotproduct(v,v))
def angle_between(v1,v2):return acos(dotproduct(v1,v2)/(length(v1)*length(v2)))
def distance_between(_p1,_p2):return hypot(_p1[0]-_p2[0],_p1[1]-_p2[1])
def direction_from_to(_p1,_p2,_norm=True):
	if _norm:return(_p1-_p2).normalized()
	else:return _p1-_p2
def rotate_point_around_point(o,p,angle):A=angle;B=o.x+cos(A)*(p.x-o.x)-sin(A)*(p.y-o.y);C=o.y+sin(A)*(p.x-o.x)+cos(A)*(p.y-o.y);return Vector((B,C))
def point_inside_circle(_p,_c,_r):return distance_between(_p,_c)<_r
def point_inside_rect(_p,_pos,_size):B=_size;A=_pos;return A[0]+B[0]>_p[0]>A[0]and A[1]+B[1]>_p[1]>A[1]
def point_inside_bounds(_p,_a,_b):return _b.x>_p.x>_a.x and _b.y>_p.y>_a.y
def point_inside_ring(_p,_c,_r1,_r2):A=distance_between(_p,_c);return A>_r1 and A<_r2
def clamp(value,_min,_max):return min(max(value,_min),_max)
def eval_bezcurve(p0,p1,p2,t=.5):return(1-t)**2*p0+2*t*(1-t)*p1+t**2*p2
def smoothstep(edge0,edge1,x):A=edge0;x=clamp((x-A)/(edge1-A),.0,1.);return x*x*(3-2*x)
def linear_interpol(x1:float,x2:float,y1:float,y2:float,x:float)->float:'Perform linear interpolation for x between (x1,y1) and (x2,y2) ';return((y2-y1)*x+x2*y1-x1*y2)/(x2-x1)
def lerp_point(t,times,points):B=times;A=points;D=A[1][0]-A[0][0];E=A[1][1]-A[0][1];C=(t-B[0])/(B[1]-B[0]);return C*D+A[0][0],C*E+A[0][1]
def lerp(v0:float,v1:float,t:float)->float:return(1-t)*v0+t*v1
def lerp_smooth(v0:float,v1:float,t:float)->float:return t*t*t*(t*(6.*t-15.)+1e1)
def ease_quad_in_out(v0:float,v1:float,t:float):A=-(t*(t-2));return v1*A+v0*(1-A)
def ParametricBlend(t):A=t*t;return A/(2.*(A-t)+1.)
def lerp_in(v0:float,v1:float,t:float)->float:return sin(t*pi*.5)
def lerp_out(v0:float,v1:float,t:float)->float:return t*t
def ease_quadratic_out(t,start,change,duration):t/=duration;return-change*t*(t-2)+start
def ease_sine_in(t,b,c,d=1.):return-c*cos(t/d*(pi/2))+c+b
def rect_contains_rect(r2,r1):return r1.x1<r2.x1<r2.x2<r1.x2 and r1.y1<r2.y1<r2.y2<r1.y2
def node_inside_bounds(node,Xi,Xf,Yi,Yf):A,B=node.get_opposite_corners();return A.x>Xi and B.x<Xf and A.y>Yi and B.y<Yf
'\n    Note that a rectangle can be represented by two coordinates, top left and bottom right. So mainly we are given following four coordinates.\n    l1: Top Left coordinate of first rectangle.\n    r1: Bottom Right coordinate of first rectangle.\n    l2: Top Left coordinate of second rectangle.\n    r2: Bottom Right coordinate of second rectangle.\n'
def node_overlaps_rect(node,l2,r2):
	A,B=node.get_opposite_corners()
	if A.x>=r2.x or l2.x>=B.x:return _A
	if A.y<=r2.y or l2.y<=B.y:return _A
	return True
def rect_overlaps_rect(R1,R2):
	if R1[0]>=R2[2]or R1[2]<=R2[0]or R1[3]<=R2[1]or R1[1]>=R2[3]:return _A
	return True
def point_inside_node(_p,_pos,_size):B=_size;A=_pos;return A[0]<_p[0]<A[0]+B[0]and A[1]-B[1]<_p[1]<A[1]