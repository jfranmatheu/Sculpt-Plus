_H='CANCELLED'
_G='RUNNING_MODAL'
_F='EVAL_ACTIVE_OBJECT'
_E='DRAW_3D'
_D='DRAW_2D'
_C='WINDOW'
_B='RAYCAST'
_A=None
from bpy.types import Operator,Context,Event,Object,PointerProperty,Property,FloatProperty,IntProperty,BoolProperty,StringProperty
from bpy.utils import register_class,unregister_class
from bpy import props as BPY_PROPS
from mathutils import Vector,Matrix
from bpy_extras import view3d_utils
dynamic_operators=[]
def get_bpy_prop_kwargs(prop,override_value=_A)->dict:
	D=override_value;C='default';A=prop;B={'name':A.name,'description':A.description,'subtype':A.subtype}
	if isinstance(A,(FloatProperty,IntProperty)):B['min']=A.hard_min;B['max']=A.hard_max;B['soft_min']=A.soft_min;B['soft_max']=A.soft_max;B[C]=A.default
	elif isinstance(A,BoolProperty):B[C]=A.default
	elif isinstance(A,StringProperty):B[C]=A.default
	if D is not _A:B[C]=D
	return B
class OpWrapper:
	def invoke(A,context:Context,event:Event):return A.execute(context)
	def pre_execute(A,context):0
	def post_execute(A,context):0
	def execute(A,context):B=context;A.pre_execute(B);A.original_bl_operator('INVOKE_DEFAULT',False,**A.get_props_dict());A.post_execute(B);return{'FINISHED'}
class OpExecutePropsWrapper(OpWrapper):
	def invoke(A,context:Context,event:Event):return context.window_manager.invoke_props_dialog(A,width=300)
class RaycastInfo:
	result:bool;location:Vector;normal:Vector;index:int;object:Object;matrix:Matrix;active_object:Object
	def update(A,context,coord):C=coord;B=context;F=B.scene;D=B.region;E=B.region_data;G=B.view_layer;H=view3d_utils.region_2d_to_vector_3d(D,E,C);I=view3d_utils.region_2d_to_origin_3d(D,E,C);J,K,L,M,object,N=F.ray_cast(G,I,H);A.result=J;A.location=K;A.normal=L;A.index=M;A.object=object;A.matrix=N
	@property
	def hit(self)->bool:return self.result
	def get_poly(A,context:Context,target_object:Object=_A):
		B=target_object
		if not A.result:return
		if B is not _A and B.name!=A.object.name:return
		if B is _A:
			if len(A.object.modifiers)>0:C=context.evaluated_depsgraph_get();D:Object=A.object.evaluated_get(C);return D.data.polygons[A.index]
		object=B if B else A.object;return object.data.polygons[A.index]
	def get_material(B,context:Context):
		A=B.get_poly(context)
		if A is _A:return
		return A.material_index
class OpModalOnReleaseExecuteWrapper(OpWrapper):
	options={_D,_E,_B,_F};mouse_pos:Vector
	def update_mouse(B,event:Event):A=event;B.mouse_pos=Vector((A.mouse_region_x,A.mouse_region_y))
	def invoke(A,context:Context,event:Event):
		B=context;B.window_manager.modal_handler_add(A);A.update_mouse(event);C=A.__class__.options
		if _D in C:A._draw_handler_2d=B.space_data.draw_handler_add(A._draw,(B,A.draw_2d),_C,'POST_PIXEL')
		if _E in C:A._draw_handler_3d=B.space_data.draw_handler_add(A._draw,(B,A.draw_3d),_C,'POST_VIEW')
		if _B in C:
			A.raycast=RaycastInfo(B.active_object);A.raycast.result=False;(A.active_object):Object=B.active_object
			if _F in C:D=B.evaluated_depsgraph_get();(A.eval_active_object):Object=A.active_object.evaluated_get(D)
			else:A.eval_active_object=_A
		A.ctx_area=B.area;A.modal_start(B);A.ctx_area.tag_redraw();A._modal_checker=_A;return{_G}
	def execute(A,context):
		if not hasattr(A,'_modal_checker'):return{_H}
		return super().execute(context)
	def modal_start(A,context:Context):0
	def modal_finish(A,context:Context):0
	def pre_modal(A,context:Context,event:Event):0
	def post_modal(A,context:Context,event:Event):0
	def draw_2d(A,context:Context):0
	def draw_3d(A,context:Context):0
	def finish(A,context:Context):
		B=context;C=A.__class__.options
		if _D in C:A._draw_handler_2d=B.space_data.draw_handler_remove(A._draw_handler_2d,_C);del A._draw_handler_2d
		if _E in C:A._draw_handler_3d=B.space_data.draw_handler_remove(A._draw_handler_3d,_C);del A._draw_handler_3d
		if _B in C:del A.raycast
		A.ctx_area.tag_redraw();A.modal_finish(B)
	def modal(A,context:Context,event:Event):
		C=event;B=context;A.pre_modal(B,C)
		if C.type=='LEFTMOUSE'and C.value=='PRESS':A.finish(B);return A.execute(B)
		if C.type in{'RIGHTMOUSE','ESC'}:A.finish(B);return{_H}
		if C.type=='MOUSEMOVE':
			A.update_mouse(C)
			if _B in A.__class__.options:A.raycast.update(B,A.mouse_pos)
		B.region.tag_redraw();A.post_modal(B,C);return{_G}
	def _draw(B,context:Context,callback)->_A:
		A=context
		if A.area!=B.ctx_area:return
		callback(A)
def get_operator_properties(op:Operator):A=op.get_rna_type();B=A.properties;C:dict[str,Property]={A:B for(A,B)in B.items()if A not in{'rna_type'}and type(B)not in{PointerProperty}};return C
def create_op_wrapper(builtin_op,your_class,base_class,props_overwrite:dict={},copy_props:bool=True):
	D=your_class;C=builtin_op;A={}
	if copy_props:A=get_operator_properties(C)
	B=type(D.__name__,(D,base_class,Operator),{'original_bl_operator':C,'prop_names':tuple(A for A in A.keys()),'__annotations__':{A:getattr(BPY_PROPS,type(B).__name__)(**get_bpy_prop_kwargs(B,props_overwrite.get(A,_A)))for(A,B)in A.items()},'get_props_dict':lambda s:{A:getattr(s,A)for A in s.prop_names}});dynamic_operators.append(B);register_class(B);return B
def create_op_props_popup_wrapper(builtin_op,your_class)->Operator:create_op_wrapper(builtin_op,your_class,OpExecutePropsWrapper,copy_props=True)
def create_op_modal_exec_wrapper(builtin_op,your_class,props_overwrite={},copy_props=True):create_op_wrapper(builtin_op,your_class,OpModalOnReleaseExecuteWrapper,props_overwrite=props_overwrite,copy_props=copy_props)
'\ndef register():\n    pass\n\ndef unregister():\n    for op in dynamic_operators:\n        unregister_class(op)\n'