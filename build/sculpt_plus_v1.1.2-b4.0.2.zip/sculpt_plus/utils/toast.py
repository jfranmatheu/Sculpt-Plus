from enum import Enum
import bpy
class Notify(Enum):
	INFO='INFO';ERROR='CANCEL';WARNING='ERROR'
	def __call__(A,title:str,message:str):
		def B(self,context):
			A=self.layout.column(align=True)
			for B in message.split('\n'):A.label(text=B)
		bpy.context.window_manager.popup_menu(B,title=title,icon=A.value)