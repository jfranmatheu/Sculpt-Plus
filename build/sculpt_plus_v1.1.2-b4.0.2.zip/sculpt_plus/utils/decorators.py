from functools import wraps
def singleton(orig_cls):
	C=None;B=orig_cls;D=B.__new__;A=C
	@classmethod
	def E(cls):nonlocal A;return A
	@classmethod
	def F(cls):
		nonlocal A
		if A is not C:del A;A=C
	@classmethod
	def G(cls,data):nonlocal A;A=data
	@wraps(B.__new__)
	def __new__(cls,*B,**E):
		nonlocal A
		if A is C:A=D(cls,*B,**E)
		return A
	B.__new__=__new__;B.get_instance=E;B.set_instance=G;B.clear_instance=F;return B