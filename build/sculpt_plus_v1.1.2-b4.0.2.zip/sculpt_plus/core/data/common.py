_B='%Y/%m/%d %H:%M:%S'
_A=None
from datetime import datetime
from typing import List,Tuple,Union
from uuid import uuid4
from bpy.types import Context
from bpy.props import PointerProperty,IntProperty,StringProperty,BoolProperty,CollectionProperty,EnumProperty
class PG_id:
	name:StringProperty(default='');uid:StringProperty(default='')
	def setup_id(A)->_A:A.uid=uuid4().hex
class PG_date:
	created_at:StringProperty();updated_at:StringProperty()
	def setup_date(A)->_A:A.created_at=datetime.utcnow().strftime(_B);A.updated_at=A.created_at
	def update_date(A)->_A:A.updated_at=datetime.utcnow().strftime(_B)
class PG_id_date(PG_id,PG_date):0
class PG_collection:
	class DummyClass:0
	collection_type=DummyClass;collection_name='';enum_items=[('NONE','None','')]
	def get_enum_items(A,context)->Tuple:A.enum_items.clear();A.enum_items=[(A.uid,A.name,'')for A in getattr(A,A.collection_name)];return A.enum_items
	def update_enum(A,context):
		B:str=A.enum
		for(C,D)in enumerate(getattr(A,A.collection_name)):
			if D.uid==B:A.active_index=C;context.area.tag_redraw();return
	enum:EnumProperty(name='List',items=get_enum_items,update=update_enum)
	def update_active(A,_context:Context):
		B=getattr(A,A.collection_name)
		if A.active_index<0 or A.active_index>=len(B):return
	active_index:IntProperty(default=-1,update=update_active)
	@property
	def active(self)->collection_type:A=self;return getattr(A,A.collection_name)[A.active_index]if A.active_index!=-1 else _A
	def new_item(A)->collection_type:
		B=getattr(A,A.collection_name);C=B.add()
		if isinstance(A,A.collection_type):C.setup_id()
		A.active_index=len(B)-1;return C
	def remove_item(B,item:Union[int,collection_type])->_A:
		A=item;C=getattr(B,B.collection_name)
		if isinstance(A,int):
			if A<0 or A>=len(C):return
			C.remove(A);return
		for(D,E)in enumerate(C):
			if E!=A:continue
			return B.remove_item(D)