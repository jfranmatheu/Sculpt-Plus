_K='emboss'
_J='alignment'
_I='active'
_H='context'
_G='CY_uiLayout'
_F=False
_E='flag'
_D='prev'
_C='next'
_B='type'
_A=None
from ctypes import POINTER,Structure,c_bool,c_char,c_char_p,c_double,c_float,c_int,c_longlong,c_wchar_p,c_short,c_byte,c_uint,sizeof,cast,byref,c_void_p,c_ubyte
from enum import IntEnum,Enum
c_float_p=POINTER(c_float)
c_int_p=POINTER(c_int)
c_byte_p=POINTER(c_byte)
c_bool_p=POINTER(c_bool)
def to_cy_string(_string:str)->c_wchar_p:return c_wchar_p(_string)
def to_cy_array_float(_list:list,ret_size:bool=_F,size:int=0):
	if _list==_A:
		if ret_size:return _A,c_int(0)
		else:return
	if not size:size=len(_list)
	clist=(c_float*size)(*_list)
	if ret_size:return c_float_p(clist),c_int(size)
	return c_float_p(clist)
def to_cy_array_int(_list:list,ret_size:bool=_F,size:int=0):
	if not size:size=len(_list)
	clist=(c_int*size)(*_list)
	if ret_size:return c_int_p(clist),c_int(size)
	return c_int_p(clist)
def to_cy_array_byte(_list:list,ret_size:bool=_F,size:int=0):
	if not size:size=len(_list)
	clist=(c_byte*size)(*_list)
	if ret_size:return c_byte_p(clist),c_int(size)
	return c_byte_p(clist)
class ConvertTo(Enum):
	STRING=to_cy_string;ARRAY_FLOAT=to_cy_array_float;ARRAY_INT=to_cy_array_int;ARRAY_BYTE=to_cy_array_byte;INT=c_int;FLOAT=c_float;BYTE=c_byte;BOOL=c_bool
	def __call__(self,input:str or list or tuple or bool,*args)->c_wchar_p or c_float_p or c_int_p or c_byte_p or c_bool or c_int or c_float or c_byte:return self.value(input,*args)
UI_MAX_NAME_STR=128
class EnumerationType(type(c_uint)):
	def __new__(metacls,name,bases,dict):
		A='_members_'
		if not A in dict:
			_members_={}
			for(key,value)in dict.items():
				if not key.startswith('_'):_members_[key]=value
			dict[A]=_members_
		cls=type(c_uint).__new__(metacls,name,bases,dict)
		for(key,value)in cls._members_.items():globals()[key]=value
		return cls
	def __contains__(self,value):return value in self._members_.values()
	def __repr__(self):return'<Enumeration %s>'%self.__name__
class Enumeration(c_uint):
	__metaclass__=EnumerationType;_members_={}
	def __init__(self,value):
		for(k,v)in self._members_.items():
			if v==value:self.name=k;break
		else:raise ValueError('No enumeration member with value %r'%value)
		c_uint.__init__(self,value)
	@classmethod
	def from_param(cls,param):
		if isinstance(param,Enumeration):
			if param.__class__!=cls:raise ValueError('Cannot mix enumeration members')
			else:return param
		else:return cls(param)
	def __repr__(self):return'<member %s=%d of %r>'%(self.name,self.value,self.__class__)
class CY_rect:
	@property
	def position(self):return self.xmin,self.ymin
	@property
	def size_x(self):return self.xmax-self.xmin
	@property
	def size_y(self):return self.ymax-self.ymin
	@property
	def size(self)->tuple:return self.size_x,self.size_y
class CY_recti(CY_rect,Structure):_fields_=[('xmin',c_int),('xmax',c_int),('ymin',c_int),('ymax',c_int)]
class CY_rectf(CY_rect,Structure):_fields_=[('xmin',c_float),('xmax',c_float),('ymin',c_float),('ymax',c_float)]
class CY_ListBase(Structure):_fields_=[('first',c_void_p),('last',c_void_p)]
class uiItemType:ITEM_BUTTON=0;ITEM_LAYOUT_ROW=1;ITEM_LAYOUT_COLUMN=2;ITEM_LAYOUT_COLUMN_FLOW=3;ITEM_LAYOUT_ROW_FLOW=4;ITEM_LAYOUT_GRID_FLOW=5;ITEM_LAYOUT_BOX=6;ITEM_LAYOUT_ABSOLUTE=7;ITEM_LAYOUT_SPLIT=8;ITEM_LAYOUT_OVERLAP=9;ITEM_LAYOUT_RADIAL=10;ITEM_LAYOUT_ROOT=11
class uiEmbossType:UI_EMBOSS=0,;UI_EMBOSS_NONE=1,;UI_EMBOSS_PULLDOWN=2,;UI_EMBOSS_RADIAL=3,;'\n    * The same as #UI_EMBOSS_NONE, unless the button has\n    * a coloring status like an animation state or red alert.\n    ';UI_EMBOSS_NONE_OR_STATUS=4,;UI_EMBOSS_UNDEFINED=255,
class CY_uiItem(Structure):
	'\n    @property\n    def size(self):\n        if self.type == uiItemType.ITEM_BUTTON:\n            # uiButtonItem *bitem = (uiButtonItem *)item;\n            CY_uiButtonItem_p = POINTER(CY_uiButtonItem)\n            bitem = cast(byref(self), CY_uiButtonItem_p).contents\n\n            bitem.but.rect\n            w = \n    '
	def to_layout(self)->_G:return cast(byref(self),POINTER(CY_uiLayout)).contents
	def next_item(self)->'CY_uiItem'or _A:
		if self.next<=0:return
		return CY_uiItem.from_address(self.next)
	_fields_=[(_C,c_void_p),(_D,c_void_p),(_B,c_int),(_E,c_int)]
class CY_uiButtonItem(Structure):_fields_=[('item',CY_uiItem),('but',c_longlong)]
class CY_uiLayout(Structure):
	x:int;y:int;w:int;h:int
	@property
	def position(self)->tuple[int,int]:return self.x,self.y
	@property
	def size(self)->tuple[int,int]:return self.w,self.h
	@property
	def children_layout(self)->_G or _A:
		if self.child_items_layout==0:return
		return CY_uiLayout.from_address(self.child_items_layout)
	@property
	def children(self)->list[_G]:
		if self.items is _A:return[]
		children=[];layout_size=sizeof(CY_uiLayout);next_item=self.items.first;last_item=self.items.last
		while next_item<last_item:children.append(CY_uiItem.from_address(next_item));next_item+=layout_size
		children.append(CY_uiItem.from_address(last_item));return children
	_fields_=[('item',CY_uiItem),('root',c_longlong),(_H,c_longlong),('parent',c_longlong),('items',CY_ListBase),('heading',c_char*UI_MAX_NAME_STR),('child_items_layout',c_longlong),('x',c_int),('y',c_int),('w',c_int),('h',c_int),('scale',c_float*2),('space',c_short),('align',c_bool),(_I,c_bool),('active_default',c_bool),('activate_init',c_bool),('enabled',c_bool),('redalert',c_bool),('keepaspect',c_bool),('variable_size',c_bool),(_J,c_char),(_K,c_int),('units',c_float*2)]
class CY_IconTextOverlay(Structure):_fields_=[('text',c_char*5)]
class CY_PointerRNA(Structure):_fields_=[('owner_id',c_longlong),(_B,c_longlong),('data',c_void_p)]
class CY_uiBut(Structure):
	@property
	def size(self)->tuple[int,int]:return self.rect.size
	@property
	def position(self)->tuple[int,int]:return self.rect.position
	_fields_=[(_C,c_longlong),(_D,c_longlong),('layout',POINTER(CY_uiLayout)),(_E,c_int),('drawflag',c_int),(_B,c_int),('pointype',c_int),('bit',c_short),('bitnr',c_short),('retval',c_short),('strwidth',c_short),('alignnr',c_short),('ofs',c_short),('pos',c_short),('selsta',c_short),('selend',c_short),('str',c_char_p),('strdata',c_char*UI_MAX_NAME_STR),('drawstr',c_char*UI_MAX_NAME_STR),('rect',CY_rectf),('poin',c_char_p),('hardmin',c_float),('hardmax',c_float),('softmin',c_float),('softmax',c_float),('a1',c_float),('a2',c_float),('col',c_ubyte*4),('identity_cmp_func',c_longlong),('func',c_longlong),('func_arg1',c_void_p),('func_arg2',c_void_p),('funcN',c_longlong),('func_argN',c_void_p),(_H,c_longlong),('autocomplete_func',c_longlong),('autofunc_arg',c_void_p),('rename_func',c_longlong),('rename_arg1',c_void_p),('rename_orig',c_void_p),('hold_func',c_longlong),('hold_argN',c_void_p),('tip',c_char_p),('tip_func',c_longlong),('tip_arg',c_void_p),('tip_arg_free',c_longlong),('disabled_info',c_char_p),('icon',c_int),(_K,c_int),('pie_dir',c_int),('changed',c_bool),('unit_type',c_ubyte),('iconadd',c_short),('block_create_func',c_longlong),('menu_create_func',c_longlong),('menu_step_func',c_longlong),('rnapoin',CY_PointerRNA),('rnaprop',c_longlong),('rnaindex',c_int),('optype',c_longlong),('opptr',c_longlong),('opcontext',c_int),('menu_key',c_ubyte),('extra_op_icons',CY_ListBase),('dragtype',c_char),('dragflag',c_short),('dragpoin',c_longlong),('imb',c_longlong),('imb_scale',c_float),(_I,c_longlong),('custom_data',c_void_p),('editstr',c_char_p),('editval',POINTER(c_double)),('editvec',c_float_p),('pushed_state_func',c_longlong),('pushed_state_arg',c_void_p),('icon_overlay_text',CY_IconTextOverlay),('block',c_longlong)]
class CY_uiLayoutItemBx(Structure):
	@property
	def button(self)->CY_uiBut:return CY_uiBut.from_address(self.roundbox)
	_fields_=[('litem',CY_uiLayout),('roundbox',c_longlong)]
class CY_wmGizmoGroup(Structure):_fields_=[(_C,c_longlong),(_D,c_longlong),(_B,c_longlong),('gizmos',CY_ListBase),('parent_gzmap',c_longlong),('py_instance',c_void_p),('reports',c_longlong),('hide',c_uint*2),('tag_remove',c_bool),('customdata',c_void_p),('customdata_free',c_void_p),('init_flag',c_int)]
class CY_wmGizmoMapSelectState(Structure):_fields_=[('items',c_longlong),('len',c_int),('len_alloc',c_int)]
class CY_GizmoMapContext(Structure):_fields_=[('highlight',c_longlong),('modal',c_longlong),('select',CY_wmGizmoMapSelectState),('event_xy',c_int*2),('event_grabcursor',c_short),('last_cursor',c_int)]
class CY_wmGizmoMap(Structure):
	@property
	def context(self)->CY_GizmoMapContext:return self.gzmap_context
	@property
	def group(self)->CY_wmGizmoGroup:return self.groups
	_fields_=[(_B,c_int),('groups',CY_ListBase),('update_flag',c_char*2),('is_init',c_bool),('tag_remove_group',c_bool),('gzmap_context',CY_GizmoMapContext)]
class CY_SmoothView2DStore(Structure):_fields_=[('orig_cur',CY_rectf),('new_rect',CY_rectf),('time_allowed',c_double)]
class CY_View2D(Structure):_fields_=[('tot',CY_rectf),('cur',CY_rectf),('vert',CY_recti),('hor',CY_recti),('mask',CY_recti),('min',c_float*2),('max',c_float*2),('minzoom',c_float),('maxzoom',c_float),('scroll',c_short),('scroll_ui',c_short),('keeptot',c_short),('keepzoom',c_short),('keepofs',c_short),(_E,c_short),('align',c_short),('winx',c_short),('winy',c_short),('oldwinx',c_short),('oldwiny',c_short),('around',c_short),('alpha_vert',c_char),('alpha_hor',c_char),('_pad',c_char*2),('page_size_y',c_float),('sms',POINTER(CY_SmoothView2DStore)),('smooth_timer',c_longlong)]
class CY_ARegion_Runtime(Structure):_fields_=[('category',c_char_p),('visible_rect',CY_recti),('offset_x',c_int),('offset_y',c_int),('block_name_map',c_longlong)]
class CY_ARegion(Structure):
	@property
	def size(self)->tuple[int,int]:return self.sizex,self.sizey
	def resize_x(self,width)->_A:self.sizex=width
	def resize_y(self,height)->_A:self.sizey=height
	@property
	def size_win(self)->tuple[int,int]:return self.winx,self.winy
	@property
	def size_view2d(self)->tuple[int,int]:return self.v2d.cur.size
	@property
	def view2d_scroll(self)->int:return self.v2d.scroll
	_fields_=[(_C,c_longlong),(_D,c_longlong),('v2d',CY_View2D),('winrct',CY_recti),('drawrct',CY_recti),('winx',c_short),('winy',c_short),('category_scroll',c_int),('_pad0',c_char*4),('visible',c_short),('regiontype',c_short),(_J,c_short),(_E,c_short),('sizex',c_short),('sizey',c_short),('do_draw',c_short),('do_draw_paintcursor',c_short),('overlap',c_short),('flagfullscreen',c_short),(_B,c_longlong),('uiblocks',CY_ListBase),('panels',CY_ListBase),('panels_category_active',CY_ListBase),('ui_lists',CY_ListBase),('ui_previews',CY_ListBase),('handlers',CY_ListBase),('panels_category',CY_ListBase),('gizmo_map',c_longlong),('regiontimer',c_longlong),('draw_buffer',c_longlong),('headerstr',POINTER(c_char)),('regiondata',c_void_p),('runtime',CY_ARegion_Runtime)]
class CyBlStruct(Enum):
	_UI_ITEM=CY_uiItem;_UI_LAYOUT=CY_uiLayout;_UI_LAYOUT_BOX=CY_uiLayoutItemBx;_UI_REGION=CY_ARegion
	@classmethod
	def UI_LAYOUT(cls,bl_struct)->CY_uiLayout:return cls._UI_LAYOUT(bl_struct)
	@classmethod
	def UI_LAYOUT_BOX(cls,bl_struct)->CY_uiLayoutItemBx:return cls._UI_LAYOUT_BOX(bl_struct)
	@classmethod
	def UI_ITEM(cls,bl_struct)->CY_uiItem:return cls._UI_ITEM(bl_struct)
	@classmethod
	def UI_REGION(cls,bl_struct)->CY_ARegion:return cls._UI_REGION(bl_struct)
	def __call__(self,bl_struct):return self.value.from_address(bl_struct.as_pointer())