_C='Affect only faces facing towards the view'
_B='Front Faces Only'
_A=False
from bpy.types import PropertyGroup,Context,Scene as SCN
from bpy.props import PointerProperty,BoolProperty
from bpy.types import Context,Image as BlImage,ImageTexture as BlImageTexture
class SCULPTPLUS_PG_scn(PropertyGroup):
	@staticmethod
	def get_data(ctx:Context)->'SCULPTPLUS_PG_scn':return ctx.scene.sculpt_plus
	texture:PointerProperty(type=BlImageTexture);image:PointerProperty(type=BlImage,name='Image base');image_seq:PointerProperty(type=BlImage,name='Image Base used for sequence source images (PSD)');mask_op_use_front_faces_only:BoolProperty(default=_A,name=_B,description=_C);mask_op_clear_previous_mask:BoolProperty(default=_A,name='Clear Previous Masks',description='Does not keep previous masks. Clear everything before the expand operation');mask_op_invert:BoolProperty(default=_A,name='Invert Mask',description='Invert mask effect');mask_op_use_reposition_pivot:BoolProperty(default=_A,name='Reposition Pivot',description='Reposition the sculpt transform pivot to the boundary of the expand active area');facesets_op_use_front_faces_only:BoolProperty(default=_A,name=_B,description=_C)
def register():SCN.sculpt_plus=PointerProperty(type=SCULPTPLUS_PG_scn)