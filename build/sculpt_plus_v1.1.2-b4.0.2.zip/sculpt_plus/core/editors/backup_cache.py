from bl_ui.space_view3d import VIEW3D_HT_tool_header
from bpy.types import VIEW3D_PT_tools_brush_select,VIEW3D_PT_tools_active,VIEW3D_PT_tools_brush_settings
from collections import defaultdict
classes_to_cache=VIEW3D_PT_tools_active,VIEW3D_HT_tool_header,VIEW3D_PT_tools_brush_select,VIEW3D_PT_tools_brush_settings
_cache_reset={}
_mod_cls_attributes=defaultdict(set)
def get_attr_from_cache(cls,attr,default=None):
	B=attr;A=cls
	if(C:=_cache_reset.get(A,None)):
		if hasattr(C,B):return C[B]
		else:print(f"No cache attr '{B}' for cls '{A}'")
	else:print(f"No cache for cls:",A)
	return default
def cache_cls_attributes(cls)->dict:A=cls;_cache_reset[A]=A.__dict__.copy();return _cache_reset[A]
def set_cls_attribute(cls,attr:str,new_value):
	B=attr;A=cls
	if(C:=_cache_reset.get(A,None)):0
	else:C=cache_cls_attributes(A)
	setattr(A,B,new_value)
	if B not in C:print('Attribute %s not in cls'%B,A);return
	_mod_cls_attributes[A].add(B);setattr(A,'old_'+B,C[B])
def pre_register():
	for A in classes_to_cache:cache_cls_attributes(A)
def pre_unregister():
	for(A,E)in _mod_cls_attributes.items():
		C=_cache_reset[A]
		for B in E:
			if not hasattr(A,B)or B not in C:continue
			setattr(A,B,C[B]);D='old_'+B
			if not hasattr(A,D)or D not in C:continue
			delattr(A,D)