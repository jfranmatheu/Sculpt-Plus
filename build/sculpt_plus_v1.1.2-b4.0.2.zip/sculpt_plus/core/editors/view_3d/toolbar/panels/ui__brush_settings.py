_D=None
_C='TRIA_DOWN'
_B=False
_A=True
from._dummy import DummyPanel
from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
from bl_ui.properties_paint_common import brush_settings,brush_settings_advanced,brush_texture_settings,StrokePanel,FalloffPanel,SmoothStrokePanel
from bpy.types import UILayout,Context
from sculpt_plus.props import Props
from sculpt_plus.globals import G
def draw_brush_settings_tabs(layout:UILayout,context:Context):
	O='BRUSH_SETTINGS_FALLOFF';N='BRUSH_SETTINGS';M='show_brush_settings_panel';L='name';C=context;from sculpt_plus.core.data.wm import SCULPTPLUS_PG_ui_toggles as P;D:P=Props.UI(C);E:str=D.toolbar_brush_sections;Q=C.tool_settings.sculpt;B=Q.brush;G=layout.column(align=_A);G.use_property_split=_A;F=G.box().row(align=_A);F.scale_y=1.5;F.use_property_split=_B;J,R=ToolSelectPanelHelper._tool_key_from_context(C);S=ToolSelectPanelHelper._tool_class_from_space_type(J);T,Y,U=S._tool_get_active(C,J,R,with_icon=_A)
	if T is _D:return
	if B is _D:F.label(text='No Active Brush');return
	V='brush_manager'in B
	if V and L in B:K=B[L]
	else:K=B.name
	F.label(text='',icon_value=U);W=_C if D.show_brush_settings_panel else'TRIA_LEFT';F.prop(D,M,expand=_A,text=K+' Brush',emboss=_B);F.prop(D,M,expand=_A,text='',icon=W,emboss=_B)
	if not D.show_brush_settings_panel:return
	H=G.grid_flow(align=_A,columns=0);H.use_property_split=_B;H.scale_y=1.35;H.prop(D,'toolbar_brush_sections',text='',expand=_A);X=G.box();X.ui_units_y=.1;A:UILayout=G.box().column(align=_B if E in{N,O}else _A);A.separator()
	if E==N:brush_settings(A,C,B)
	elif E=='BRUSH_SETTINGS_ADVANCED':A.use_property_split=_B;brush_settings_advanced(A,C,B)
	elif E=='BRUSH_SETTINGS_STROKE':
		StrokePanel.draw(DummyPanel(A),C);A.separator();A=A.column(align=_A);I=A.box().row(align=_A);I.use_property_split=_B;I.alignment='LEFT';I.prop(B,'use_smooth_stroke',text='Stabilize Stroke')
		if B.use_smooth_stroke:SmoothStrokePanel.draw(DummyPanel(A.box()),C)
	elif E==O:FalloffPanel.draw(DummyPanel(A),C)
	elif E=='BRUSH_SETTINGS_TEXTURE':
		if B.texture is not _D:A.template_icon(icon_value=UILayout.icon(B.texture),scale=5.);brush_texture_settings(A,B,sculpt=_A);A.separator();A.alert=_A;A.operator('sculpt_plus.unasign_bl_texture',text='Unasign Texture');A.alert=_B
		else:A.alert=_A;A.label(text='Brush has not texture');A.alert=_B;A.separator();A.prop(B,'texture',text='Asign Existing');A.separator();A.operator('sculpt_plus.import_texture',text='Import from image file')
	A.separator(factor=.5)
def draw_brush_settings_expandable(layout:UILayout,context:Context):
	O='show_brush_settings_texture';N='show_brush_settings_falloff';M='show_brush_settings_stroke';L='show_brush_settings_advanced';K='show_brush_settings';I='NONE';H='TRIA_RIGHT';G=context;from sculpt_plus.core.data.wm import SCULPTPLUS_PG_ui_toggles as P;A:P=Props.UI(G);Q=G.tool_settings.sculpt;J=Q.brush;F=layout.column();F.use_property_split=_A;D=F.column(align=_A);B=D.row(align=_A);B.use_property_split=_B;B.box().label(text='',icon='BRUSH_DATA');E=_C if A.show_brush_settings else H;C=B.box().row(align=_A);C.emboss=I;C.prop(A,K,text='Brush Settings',toggle=_B);C.prop(A,K,text='',icon=E,toggle=_B)
	if A.show_brush_settings:
		brush_settings(D.box(),G,J);E=_C if A.show_brush_settings_advanced else H;B=D.row(align=_A);B.use_property_split=_B;B.box().label(text='',icon='GHOST_ENABLED');C=B.box().row(align=_A);C.emboss=I;C.prop(A,L,text='Advanced',toggle=_B);C.prop(A,L,text='',icon=E,toggle=_B)
		if A.show_brush_settings_advanced:brush_settings_advanced(D.box(),G,J)
	F.separator();D=F.column(align=_A);B=D.row(align=_A);B.use_property_split=_B;B.box().label(text='',icon='GP_SELECT_STROKES');E=_C if A.show_brush_settings_stroke else H;C=B.box().row(align=_A);C.emboss=I;C.prop(A,M,text='Stroke Settings',toggle=_B);C.prop(A,M,text='',icon=E,toggle=_B)
	if A.show_brush_settings_stroke:StrokePanel.draw(DummyPanel(D.box()),G)
	F.separator();D=F.column(align=_A);B=D.row(align=_A);B.use_property_split=_B;B.box().label(text='',icon='SMOOTHCURVE');E=_C if A.show_brush_settings_falloff else H;C=B.box().row(align=_A);C.emboss=I;C.prop(A,N,text='Falloff Settings',toggle=_B);C.prop(A,N,text='',icon=E,toggle=_B)
	if A.show_brush_settings_falloff:FalloffPanel.draw(DummyPanel(D.box()),G)
	if J.texture is _D:return
	F.separator();D=F.column(align=_A);B=D.row(align=_A);B.use_property_split=_B;B.box().label(text='',icon='TEXTURE_DATA');E=_C if A.show_brush_settings_texture else H;C=B.box().row(align=_A);C.emboss=I;C.prop(A,O,text='Texture Settings',toggle=_B);C.prop(A,O,text='',icon=E,toggle=_B)
	if A.show_brush_settings_texture:brush_texture_settings(D.box(),J,sculpt=_A)