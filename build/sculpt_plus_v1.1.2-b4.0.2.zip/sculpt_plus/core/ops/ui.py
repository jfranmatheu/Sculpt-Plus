_B='RUNNING_MODAL'
_A='FINISHED'
from bpy.types import Operator,Region
from bpy.props import BoolProperty
from time import time
from sculpt_plus.utils.math import map_value
from sculpt_plus.core.data.cy_structs import CyBlStruct
class SCULPTPLUS_OT_expand_toolbar(Operator):
	bl_idname='sculpt_plus.expand_toolbar';bl_label='[Sculpt+] Expand Toolbar';use_smooth:BoolProperty(default=True)
	def execute(A,context):
		F='CANCELLED';D=None;B=context
		if B.area is D:print('Bad context to expand toolbar!');return{F}
		C:Region=D
		for E in B.area.regions:
			if E.type=='TOOLS':C=E;break
		if C is D:return{F}
		A.region=C;A.space_data=B.space_data;A.cy_region=CyBlStruct.UI_REGION(C);G=B.preferences
		if not A.use_smooth:A.set_width(320);del A.cy_region;return{_A}
		A.width=A.cy_region.winx;A.target_width=320;A.anim_time=.32;A.start_time=time();B.window_manager.modal_handler_add(A);A._timer=B.window_manager.event_timer_add(time_step=.01,window=B.window);return{_B}
	def finish(A,context):
		if hasattr(A,'_timer')and A._timer:context.window_manager.event_timer_remove(A._timer)
	def modal(A,context,event):
		if event.type=='TIMER':
			if(B:=A.increment_width()):A.finish(context);return{_A}
			return{_B}
		return{'PASS_THROUGH'}
	def increment_width(A)->bool:
		B=map_value(time()-A.start_time,(0,A.anim_time),(0,1))*A.target_width
		if B>=A.target_width:B=A.target_width
		A.width=B;A.set_width(int(B))
		if B==A.target_width:return True
		return False
	def set_width(A,width:int):A.cy_region.sizex=width;A.region.tag_redraw();B=A.space_data.show_region_header;A.space_data.show_region_header=True;A.space_data.show_region_header=False;A.space_data.show_region_header=B