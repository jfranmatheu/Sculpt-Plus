_I='Remove Multires Modifier'
_H='OBJECT'
_G='Apply Multires Modifier'
_F='Change Multires Level'
_E='FINISHED'
_D='MULTIRES'
_C='CANCELLED'
_B='SCULPT'
_A=False
import bpy
from bpy.types import Operator,MultiresModifier
from bpy.props import IntProperty,BoolProperty
from sculpt_plus.utils.modifiers import get_modifier_by_type
class SCULPTPLUS_OT_multires_change_level(Operator):
	bl_idname='sculpt_plus.multires_change_level';bl_label=_F;bl_description=_F;level:IntProperty(default=0,name='Multires Level')
	@classmethod
	def poll(B,context):A=context;return A.mode==_B and A.sculpt_object is not None
	def execute(B,context):
		A:MultiresModifier=get_modifier_by_type(context.sculpt_object,_D)
		if not A:return{_C}
		if B.level>A.total_levels:return{_C}
		A.sculpt_levels=B.level;return{_E}
class SCULPTPLUS_OT_multires_apply(Operator):
	bl_idname='sculpt_plus.multires_apply';bl_label=_G;bl_description=_G;as_shape_key:BoolProperty(name='Apply as Shape Key',default=_A)
	@classmethod
	def poll(B,context):A=context;return A.mode==_B and A.sculpt_object is not None
	def execute(B,context):
		A:MultiresModifier=get_modifier_by_type(context.sculpt_object,_D)
		if not A:return{_C}
		bpy.ops.object.mode_set(_A,mode=_H,toggle=_A);A.levels=A.sculpt_levels
		if B.as_shape_key:bpy.ops.object.modifier_apply_as_shapekey(_A,keep_modifier=_A,modifier=A.name,report=True)
		else:bpy.ops.object.modifier_apply(modifier=A.name,report=True)
		bpy.ops.object.mode_set(_A,mode=_B,toggle=_A);return{_E}
class SCULPTPLUS_OT_multires_remove(Operator):
	bl_idname='sculpt_plus.multires_remove';bl_label=_I;bl_description=_I
	@classmethod
	def poll(B,context):A=context;return A.mode==_B and A.sculpt_object is not None
	def execute(C,context):
		A=context;B:MultiresModifier=get_modifier_by_type(A.sculpt_object,_D)
		if not B:return{_C}
		bpy.ops.object.mode_set(_A,mode=_H,toggle=_A);A.active_object.modifiers.remove(B);bpy.ops.object.mode_set(_A,mode=_B,toggle=_A);return{_E}