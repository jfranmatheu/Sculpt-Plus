_D='FINISHED'
_C='SCULPT'
_B='CANCELLED'
_A=None
import bpy
from bpy.types import Operator,ImageTexture
from bpy.props import StringProperty
from bpy_extras.io_utils import ImportHelper
from os.path import isfile,basename
class SCULPTPLUS_OT_import_texture(Operator,ImportHelper):
	bl_idname='sculpt_plus.import_texture';bl_label='Import Texture';bl_description='Import texture from an image file and asign it to the active brush';filter_glob:StringProperty(options={'HIDDEN'},default='*.jpg;*.jpeg;*.png;*.bmp;*.psd;*.tiff;*.tif')
	@classmethod
	def poll(B,context):A=context;return A.mode==_C and A.sculpt_object is not _A and A.tool_settings.sculpt.brush is not _A
	def execute(A,context):
		if not isfile(A.filepath):return{_B}
		B=bpy.data.images.load(A.filepath)
		if B is _A:return{_B}
		D=A.filepath.endswith(('.psd','.tiff','.tif'));C:ImageTexture=bpy.data.textures.new(basename(A.filepath),'IMAGE');C.image=B;from sculpt_plus.globals import G;G.bm_data.add_bl_texture(context,C,set_active=True);return{_D}
class SCULPTPLUS_OT_unasign_bl_texture(Operator):
	bl_idname='sculpt_plus.unasign_bl_texture';bl_label='Unasign Texture';bl_description='Un-asign the texture from the Brush'
	@classmethod
	def poll(B,context):A=context;return A.mode==_C and A.sculpt_object is not _A and A.tool_settings.sculpt.brush is not _A
	def execute(D,context):
		A=context
		if A.tool_settings.sculpt.brush.texture is _A:return{_B}
		from sculpt_plus.globals import G;B=A.tool_settings.sculpt.brush;B.texture=_A;C=G.bm_data.active_brush
		if B['uuid']==C.uuid:C.texture=_A
		return{_D}