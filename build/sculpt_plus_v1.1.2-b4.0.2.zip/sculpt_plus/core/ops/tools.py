_A='SCULPT'
from bpy.types import Operator
from bpy.props import StringProperty
from bpy import ops as OPS
class SCULPTPLUS_OT_select_tool__face_set_edit(Operator):
	bl_idname='sculpt_plus.select_tool__face_set_edit';bl_label="Select 'Face Set Edit' tool";mode:StringProperty()
	@classmethod
	def poll(A,context):return context.mode==_A
	def execute(B,context):
		OPS.wm.tool_set_by_id(name='builtin.face_set_edit');A=context.workspace.tools.from_space_view3d_mode(_A,create=False)
		if A:A.operator_properties('sculpt.face_set_edit').mode=B.mode
		return{'FINISHED'}