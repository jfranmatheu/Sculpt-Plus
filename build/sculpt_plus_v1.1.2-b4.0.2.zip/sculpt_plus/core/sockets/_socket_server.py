_D='CANCELLED'
_C='Got connection from'
_B='FINISHED'
_A=None
from socket import socket,AF_INET,SOCK_STREAM
import struct
class SocketServer:
	' Listener socket server. ';recv_format:str;recv_size:int;port:int;_instance=_A
	@classmethod
	def Singleton(A):
		if A._instance is _A:A._instance=A()
		return A._instance
	def __init__(A,port:int=0)->_A:A.socket=socket(AF_INET,SOCK_STREAM);A.port=port;A.connection=_A;A.init()
	def init(A)->_A:0
	def start(A)->_A:
		A.socket.bind(('localhost',A.port));A.socket.listen()
		if A.port==0:A.port=A.socket.getsockname()[1]
	def stop(A)->_A:
		A.socket.close()
		if A.connection is not _A:A.connection.close()
	def __enter__(A):A.start();return A
	def __exit__(A,exc_type,exc_val,exc_tb):A.stop()
	@property
	def recv_format(self)->str:return'i'
	@property
	def recv_size(self)->int:return struct.calcsize(self.recv_format)
	def receive_data(A,client:socket)->tuple:'\n        Receive data from client.\n\n        :param client: Client socket.\n        :return: Received data.\n        ';return A.unpack_data(client.recv(A.recv_size))
	def unpack_data(A,data:bytes)->tuple:
		'\n        Unpack received data.\n\n        :param data: Received data.\n        :return: Unpacked data.\n        '
		if not data:return
		return struct.unpack(A.recv_format,data)
	def process_data(A,*B:tuple)->str:0
	def on_process_data(A,*B:tuple)->_A:0
	def run(A)->_A:
		while True:
			C,D=A.socket.accept()
			with C:
				print(_C,D)
				while True:
					B=A.receive_data(C)
					if not B:break
					E=A.process_data(*B);A.on_process_data(*B)
					if E in{_B,_D}:return
	def run_in_modal(A)->str:
		if not A.connection:B,E=A.socket.accept();A.connection=B;print(_C,E)
		else:B=A.connection
		try:
			C=A.receive_data(B)
			if not C:A.connection=_A;return _B
			D=A.process_data(*C);A.on_process_data(*C)
			if D in{_B,_D}:A.connection=_A;return D
		except Exception as F:print(F);A.connection=_A
		return'RUNNING_MODAL'