_H='SIMPLIFY'
_G='DISPLACEMENT_SMEAR'
_F='DISPLACEMENT_ERASER'
_E='DRAW_FACE_SETS'
_D='sculpt_plus'
_C='NONE'
_B='stored_sculpt_tool_id'
_A=None
from typing import Union,List,Dict,Set,Tuple
from enum import Enum,auto
import bpy
from bpy.types import Context,Image as BlImage,ImageTexture as BlImageTexture,Brush as BlBrush,WorkSpace
from sculpt_plus.sculpt_hotbar.canvas import Canvas
from sculpt_plus.path import SculptPlusPaths
from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
from brush_manager.api import bm_types,BM_UI
from brush_manager.globals import GLOBALS,CM_UIContext
from sculpt_plus.globals import G
sculpt_tool_brush_name:Dict[str,str]={'BLOB':'Blob','BOUNDARY':'Boundary','CLAY':'Clay','CLAY_STRIPS':'Clay Strips','CLAY_THUMB':'Clay Thumb','CLOTH':'Cloth','CREASE':'Crease',_E:'Draw Face Sets','DRAW_SHARP':'Draw Sharp','ELASTIC_DEFORM':'Elastic Deform','FILL':'Fill/Deepen','FLATTEN':'Flatten/Contrast','GRAB':'Grab','INFLATE':'Inflate/Deflate','LAYER':'Layer','MASK':'Mask','MULTIPLANE_SCRAPE':'Multi-plane Scrape',_F:'Multires Displacement Eraser',_G:'Multires Displacement Smear','NUDGE':'Nudge','PAINT':'Paint','PINCH':'Pinch/Magnify','POSE':'Pose','ROTATE':'Rotate','SCRAPE':'Scrape/Peaks','DRAW':'SculptDraw',_H:'Simplify','TOPOLOGY':'Slide Relax','SMOOTH':'Smooth','SNAKE_HOOK':'Snake Hook','THUMB':'Thumb'}
builtin_brush_names:Tuple[str]=tuple(sculpt_tool_brush_name.values())
builtin_brushes:Set[str]=set(builtin_brush_names)
builtin_images:Set[str]={'Render Result','Viewer Node'}
manager_exclude_brush_tools:Set[str]={'MASK',_E,_H,_F,_G}
toolbar_hidden_brush_tools:Set[str]={A for A in sculpt_tool_brush_name.keys()if A not in manager_exclude_brush_tools}
exclude_brush_names:Set[str]={sculpt_tool_brush_name[A]for A in manager_exclude_brush_tools}
filtered_builtin_brush_names=tuple(A for A in builtin_brush_names if A not in exclude_brush_names)
states={_B:_C}
IN_BRUSH_CTX=lambda _type:_type=='BRUSH'
IN_TEXTURE_CTX=lambda _type:_type=='TEXTURE'
' Helper to get properties paths (with typing). '
class Props:
	@staticmethod
	def Workspace(context=_A)->WorkSpace or _A:
		A=context;A=A if A else bpy.context
		for B in bpy.data.workspaces:
			if _D in B:return B
	@staticmethod
	def WorkspaceSetup(context)->WorkSpace or _A:
		C='Sculpt+';A=context;D=A.window.workspace
		try:Props.Temporal(A).test_context=True
		except RuntimeError as E:print(E);return
		bpy.ops.workspace.append_activate(False,idname=C,filepath=SculptPlusPaths.BLEND_WORKSPACE());B:WorkSpace=bpy.data.workspaces.get(C,_A);A.window.workspace=B
		if _D not in B:B[_D]=1
		A.window.workspace=D;return B
	@staticmethod
	def Canvas()->Union[Canvas,_A]:
		if not hasattr(bpy,'sculpt_hotbar'):return
		return bpy.sculpt_hotbar._cv_instance
	@staticmethod
	def Scene(context:Context):return context.scene.sculpt_plus
	@staticmethod
	def Temporal(context:Context):return context.window_manager.sculpt_plus
	@classmethod
	def UI(A,context:Context):return A.Temporal(context).ui
class SculptTool:
	@staticmethod
	def get_stored()->str:return states[_B]
	@staticmethod
	def set_stored(id:str)->_A:states[_B]=id
	@classmethod
	def clear_stored(A)->_A:A.set_stored(_C)
	@staticmethod
	def get_from_context(context:Context)->tuple[str,str]:
		try:A=ToolSelectPanelHelper._tool_active_from_context(context,'VIEW_3D',mode='SCULPT',create=False)
		except AttributeError as B:print('[SCULPT+] WARN!',B);return _A,_C
		if A is _A:print('[SCULPT+] WARN! Current active tool is NULL');return _A,_C
		C,D=A.idname.split('.');return C,D
	@classmethod
	def update_stored(A,context:Context)->str:A.set_stored(A.get_from_context(context)[1])
	@classmethod
	def has_changed(A,context:Context)->bool:return states[_B]!=A.get_from_context(context)[1]
def pre_unregister():
	if(A:=Props.Workspace(bpy.context)):del A[_D]
	if bpy.context.workspace==A:bpy.ops.workspace.delete()