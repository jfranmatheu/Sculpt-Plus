_A='config.json'
import bpy
from os.path import join,dirname,abspath
import sys,pathlib
from enum import Enum
b3d_user_path=bpy.utils.resource_path('USER')
b3d_config_path=join(b3d_user_path,'config')
b3d_appdata_path=dirname(bpy.utils.resource_path('USER'))
def get_datadir()->pathlib.Path:
	'\n    Returns a parent directory path\n    where persistent application data can be stored.\n\n    # linux: ~/.local/share\n    # macOS: ~/Library/Application Support\n    # windows: C:/Users/<USER>/AppData/Roaming\n    ';A=pathlib.Path.home()
	if sys.platform=='win32':return A/'AppData/Roaming/Blender Foundation/Blender'
	elif sys.platform=='linux':return A/'.config/blender'
	elif sys.platform=='darwin':return A/'Library/Application Support/Blender'
src_path=pathlib.Path(__file__).parent
app_dir=pathlib.Path(b3d_appdata_path)/'addon_data'/__package__
temp_dir=app_dir/'temp'
data_dir=app_dir/'data'
data_brush_dir=data_dir/'brush'
data_texture_dir=data_dir/'texture'
version_file=app_dir/'version.ini'
management_config_file=data_dir/_A
def ensure_paths():
	B='ascii'
	try:
		app_dir.mkdir(parents=True,exist_ok=True)
		if not version_file.exists():version_file.touch()
		with version_file.open('w',encoding=B)as A:from.import bl_info as C;A.write(f"{C['version']}\n")
		data_dir.mkdir(parents=False);temp_dir.mkdir();(temp_dir/'fake_items').mkdir();(temp_dir/'thumbnails').mkdir()
		if not management_config_file.exists():
			management_config_file.touch()
			with management_config_file.open('w',encoding=B)as A:A.write('{ }')
	except FileExistsError:pass
ensure_paths()
class SculptPlusPaths(Enum):
	SRC=dirname(abspath(__file__));SRC_LIB=join(SRC,'lib');SRC_LIB_IMAGES=join(SRC_LIB,'images');SRC_LIB_IMAGES_ICONS=join(SRC_LIB_IMAGES,'icons');SRC_LIB_IMAGES_BRUSHES=join(SRC_LIB_IMAGES,'brushes');SRC_LIB_SCRIPTS=join(SRC_LIB,'scripts');SRC_LIB_BLEND=join(SRC_LIB,'blend');SRC_LIB_BRUSH_PACKS=join(SRC_LIB,'brush_packs');BLEND_EMPTY=join(SRC_LIB_BLEND,'empty.blend');BLEND_WORKSPACE=join(SRC_LIB_BLEND,'sculpt_plus_workspace.blend');LIB_SHADERS=join(SRC_LIB,'shaders');LIB_SHADERS_VERT=join(LIB_SHADERS,'vert');LIB_SHADERS_FRAG=join(LIB_SHADERS,'frag');LIB_SHADERS_BUILTIN=join(LIB_SHADERS,'builtin');APP=app_dir;APP__DATA=data_dir;APP__TEMP=temp_dir;CONFIG_FILE=data_dir/_A;HOTBAR_DATA=data_dir/'hotbar'
	def __call__(A,*B,as_path:bool=False):
		C=as_path
		if not B:return A.value if C else str(A.value)
		return A.value.joinpath(*B)if C else join(str(A.value),*B)
	def read(A,*B)->str:
		with open(A(*B),mode='r')as C:return C.read()