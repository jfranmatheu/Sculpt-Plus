_N='SECTIONS'
_M='sculpt_hotbar'
_L='Active Slot Color'
_K='Slot Background Color'
_J='Background Color'
_I='LEFT'
_H='DIR_PATH'
_G='NONE'
_F=None
_E=False
_D=True
_C='COLOR'
_B=.0
_A=1.
from bpy.types import AddonPreferences,Context
from bpy.props import StringProperty
from sculpt_plus.path import SculptPlusPaths
from bpy.types import AddonPreferences,Region,UILayout
from bpy.props import FloatProperty,BoolProperty,EnumProperty,IntVectorProperty,IntProperty,FloatVectorProperty,StringProperty
from mathutils import Vector
import bpy,os
from os.path import dirname,abspath,join
app_data_path=os.getenv('APPDATA')
SLOT_SIZE=56
enum_list=[(_G,'None','')]
class SCULPTPLUS_AddonPreferences(AddonPreferences):
	bl_idname:str=__package__;first_time:BoolProperty(default=_E);brush_lib_path:StringProperty(name='Brush Library Directory',description='Folder where to save your brush sets',default=SculptPlusPaths.APP__DATA(),subtype=_H);num_backup_versions:IntProperty(name='Backup Versions',description='Number of Backup Versions to store',default=2,min=0,max=10)
	def get_cv(C,context):
		if not hasattr(bpy,_M):return
		if bpy.sculpt_hotbar is _F:return
		from.sculpt_hotbar.canvas import Canvas as B;A:B=bpy.sculpt_hotbar.get_cv(context.region)
		if A is _F:return
		return A
	def get_scale(A,context)->float:B=context.preferences.system.ui_scale;return B*A.scale
	def update_ui(A,context):
		B=context
		if(C:=A.get_cv(B)):D=A.get_scale(B);C.update(_F,_F,D,A)
	def update_hotbar_mask_group(A,context):
		if(B:=A.get_cv(context)):B.group_mask.enabled=A.show_hotbar_mask_group
	def update_hotbar_transform_group(A,context):
		if(B:=A.get_cv(context)):B.group_t.enabled=A.show_hotbar_transform_group
	data_path_local=StringProperty(default=join(dirname(abspath(__file__)),'data'),subtype=_H);data_path=StringProperty(default=join(app_data_path,_M)if app_data_path else join(dirname(abspath(__file__)),'data'),subtype=_H);use_smooth_scroll:BoolProperty(default=_D,name='Smooth Scroll',update=update_ui);show_hotbar_mask_group:BoolProperty(default=_E,name='Show Hotbar Mask Buttons',update=update_hotbar_mask_group);show_hotbar_transform_group:BoolProperty(default=_E,name='Show Hotbar Transform Buttons',update=update_hotbar_transform_group);padding:IntProperty(default=1,min=0,max=6,name='Hotbar Brush-Icon Padding',update=update_ui);margin_bottom:IntProperty(default=8,min=0,max=64,name='Hotbar Bottom Margin',update=update_ui);margin_left:IntProperty(default=8,min=0,max=64,name='Sidebar Left Margin',update=update_ui);scale:FloatProperty(default=_A,min=.8,max=2.,name='Scale',update=update_ui);sidebar_position:EnumProperty(name='Sidebar Position',items=(('AUTO','Automatic','Based on the toolbar alignment, will be positioned in the other side of the viewport'),(_I,'Left',''),('RIGHT','Right',''),('TOP','Top','')),default='AUTO');theme_hotbar:FloatVectorProperty(size=4,default=(.007,.007,.007,.95),min=_B,max=_A,name=_J,subtype=_C);theme_hotbar_slot:FloatVectorProperty(size=4,default=(.09,.09,.09,.85),min=_B,max=_A,name=_K,subtype=_C);theme_shelf:FloatVectorProperty(size=4,default=(.1,.1,.1,.9),min=_B,max=_A,name=_J,subtype=_C);theme_shelf_slot:FloatVectorProperty(size=4,default=(.16,.16,.16,.5),min=_B,max=_A,name=_K,subtype=_C);theme_sidebar:FloatVectorProperty(size=4,default=(.1,.1,.1,.9),min=_B,max=_A,name=_J,subtype=_C);theme_sidebar_slot:FloatVectorProperty(size=4,default=(.16,.16,.16,.5),min=_B,max=_A,name=_K,subtype=_C);theme_selected_slot_color:FloatVectorProperty(size=4,default=(.9,.5,.4,_A),min=_B,max=_A,name='Selected Slot Color',subtype=_C);theme_active_slot_color:FloatVectorProperty(size=4,default=(.2,.5,.9,_A),min=_B,max=_A,name=_L,subtype=_C);theme_slot_outline_color:FloatVectorProperty(size=4,default=(.1,.1,.1,.9),min=_B,max=_A,name=_L,subtype=_C);theme_slot_color:FloatVectorProperty(size=4,default=(.1,.1,.1,.9),min=_B,max=_A,name=_L,subtype=_C);theme_text:FloatVectorProperty(size=4,default=(.92,.92,.92,1),min=_B,max=_A,name='Text Color (0-9)',subtype=_C)
	def get_camera_list(B,context):
		enum_list.clear()
		for A in context.scene.objects:
			if A.type=='CAMERA':enum_list.append((A.name,A.name,''))
		if enum_list:return enum_list
		return[(_G,'None','')]
	set_list:EnumProperty(items=get_camera_list,name='Camera List');toolbar_position:EnumProperty(name='Toolbar Position',items=((_I,'Left','Left, while panels will be at its right'),('RIGHT','Right','Right, while panels will be at its left')),default=_I);toolbar_panel_mask_layout:EnumProperty(name='Mask Panel Layout',items=(('COMPACT','Compact','A simple and compact display of the different mask operations, without subpanels/sections or tabs'),(_N,'Sections','A set of sections (box-like) for each kind of mask operation'),('TABS','Tabs','Only the selected tab option is visible')),default=_N)
	def draw(A,context):
		I='STATUSBAR';B:UILayout=A.layout;B.use_property_split=_D
		if A.first_time:return
		def C(title:str,icon:str=_G,align=_D,_layout=_F,props:tuple[str]=()):
			C=_layout;C=C or B;D=C.column(align=_D);D.box().row(align=_D).label(text=title,icon=icon);E=D.box().column(align=align)
			for F in props:E.prop(A,F)
			return E
		F=C('3D Viewport Toolbar Settings','TOOL_SETTINGS',align=_E);F.row().prop(A,'toolbar_position',expand=_D);F.prop(A,'toolbar_panel_mask_layout');' SCULPT HOTBAR.... ';E=C('Sculpt Hotbar Settings',I,align=_E);G=E.split(factor=.4);H=C('General UI Settings','SETTINGS',align=_E,_layout=G);H.prop(A,'scale',slider=_D);H.prop(A,'use_smooth_scroll');D=C('Style',I,align=_E,_layout=G);D.prop(A,'margin_bottom',text='Bottom Margin',slider=_D);D.prop(A,'padding',text='Brush Icon Padding',slider=_D);E.separator();J=E.split();D=C('Button Groups - Visibility','HIDE_OFF',align=_E,_layout=J);D.prop(A,'show_hotbar_mask_group',text='Mask Group');D.prop(A,'show_hotbar_transform_group',text='Transform Group');B.separator(factor=2);B.alert=_D;B.operator('sculpt_plust.clear_data',text='Clear Sculpt+ Data');B.alert=_E
def get_prefs(context:Context)->SCULPTPLUS_AddonPreferences:
	A=context
	if __package__ not in A.preferences.addons:return
	return A.preferences.addons[__package__].preferences