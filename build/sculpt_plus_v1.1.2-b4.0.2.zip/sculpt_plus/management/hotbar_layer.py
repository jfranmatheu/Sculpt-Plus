_C='Expected int (index) or string (uuid)'
_B='HotbarLayer_Collection'
_A=None
from collections import OrderedDict
from typing import List,Iterator
from uuid import uuid4
from brush_manager.api import bm_types
from.hotbar_brush_set import HotbarBrushSet
class HotbarLayer:
	owner:_B;uuid:str;name:str;brush_set:HotbarBrushSet;brush_set_alt:HotbarBrushSet
	@property
	def collection(self)->_B:return self.owner
	@property
	def active_set(self)->HotbarBrushSet:A=self;return A.brush_set_alt if A.collection.hotbar_manager.use_alt else A.brush_set
	@property
	def brushes(self)->List[bm_types.BrushItem]:' Wrapper. ';return self.active_set.brushes
	@property
	def brushes_ids(self)->List[str]:' Wrapper. ';return self.active_set.brushes_ids
	def __init__(A,collection:'HotbarLayer_Collection',name:str='Layer',custom_uuid:str|_A=_A)->_A:B=custom_uuid;print('[Sculpt+] New HotbarLayer',name,B);A.owner=collection;A.uuid=uuid4().hex if B is _A else B;A.name=name;A.brush_set=HotbarBrushSet(A,set_size=10,type='MAIN');A.brush_set_alt=HotbarBrushSet(A,set_size=10,type='ALT')
	def __del__(A)->_A:del A.brush_set;del A.brush_set_alt
	def switch(A,index_A:int,index_B:int)->_A:' Wrapper. ';A.active_set.switch(index_A,index_B)
	def link_brush(A,brush:bm_types.BrushItem,at_index:int)->_A:' Wrapper. ';A.active_set.asign_brush(brush,at_index)
	def unlink_brush(A,brush:bm_types.BrushItem)->_A:
		B=brush;C=B.hotbar_layers[A.uuid]
		if C=='MAIN':A.brush_set.unasign_brush(B)
		elif C=='ALT':A.brush_set_alt.unasign_brush(B)
	def clear_owners(A)->_A:A.owner=_A;A.brush_set.clear_owners();A.brush_set_alt.clear_owners()
	def ensure_owners(A,collection:'HotbarLayer_Collection')->_A:A.owner=collection;A.brush_set.ensure_owners(A);A.brush_set_alt.ensure_owners(A)
class HotbarLayer_Collection:
	active:HotbarLayer;layers:OrderedDict[str,HotbarLayer];owner:object
	@property
	def hotbar_manager(self):return self.owner
	@property
	def count(self)->int:return len(self.layers)
	@property
	def active(self)->HotbarLayer|_A:return self.get(self._active)
	@property
	def active_id(self)->str:return self._active
	@active.setter
	def active(self,layer:str|HotbarLayer)->_A:
		A=layer
		if A is _A:self._active='';return
		if not isinstance(A,(str,HotbarLayer)):raise TypeError('Expected an HotbarLayer instance or a string (uuid)')
		self._active=A if isinstance(A,str)else A.uuid
	def __init__(A,hm:object)->_A:A.layers=OrderedDict();A._active='';A.owner=hm
	def __iter__(A)->Iterator[HotbarLayer]:return iter(A.layers.values())
	def __getitem__(B,uuid_or_index:str|int)->HotbarLayer|_A:
		A=uuid_or_index
		if isinstance(A,str):return B.layers.get(A,_A)
		elif isinstance(A,int):
			C:int=A
			if C<0 or C>=len(B.layers):return
			return list(B.layers.values())[C]
		raise TypeError(_C)
	def get(A,uuid:str)->HotbarLayer|_A:return A[uuid]
	def select(B,layer:str|HotbarLayer|int)->_A:
		A=layer
		if isinstance(A,HotbarLayer):return B.select(A.uuid)
		if isinstance(A,int):C:int=A;return B.select(list(B.layers.keys())[C])
		if isinstance(A,str)and A in B.layers:B._active=A
	def add(B,name:str='New Layer',custom_uuid:str|_A=_A)->HotbarLayer:A=HotbarLayer(B,name,custom_uuid=custom_uuid);B.layers[A.uuid]=A;B._active=A.uuid;return A
	def remove(A,layer:HotbarLayer|str)->_A|HotbarLayer:
		B=layer
		if isinstance(B,str):
			if B==A.active:A.active=_A
			del A.layers[B]
			if A.active is _A:
				if A.count==0:A.add('Default','DEFAULT')
				else:A.select(0)
		elif isinstance(B,HotbarLayer):return A.remove(B.uuid)
		raise TypeError(_C)
	def clear(A)->_A:A.layers.clear();A._active=''
	def __del__(A)->_A:
		for B in reversed(A.layers):del B
		A.owner=_A;A.clear()
	def clear_owners(A)->_A:
		A.owner=_A
		for B in A:B.clear_owners()
	def ensure_owners(A,hm:object)->_A:
		A.owner=hm
		for B in A:B.ensure_owners(A)