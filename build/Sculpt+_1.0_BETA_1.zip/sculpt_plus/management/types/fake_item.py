_F='FakeViewItem_Texture'
_E='FakeViewItem_Brush'
_D='JPEG'
_C=True
_B='id'
_A=None
import bpy
from bpy.types import Brush,Texture,ImageTexture,Image
from gpu.types import GPUTexture
from mathutils import Vector
from typing import Union
from os.path import exists,isfile
import numpy as np,PIL
from pathlib import Path
from uuid import uuid4
from sculpt_plus.utils.gpu import gputex_from_image_file,get_brush_type_tex,gputex_from_pixels
from sculpt_plus.management.types.brush_props import sculpt_tool_items
from sculpt_plus.management.types import Brush,Texture
sculpt_tool_items_set=set(sculpt_tool_items)
COMPATIBLE_IMAGE_EXTENSIONS={'PNG','JPG',_D,'TGA','TIFF','TIF','PSD'}
def _verify_image_path(filepath:str)->Path or _A:
	A=Path(filepath)
	if not A.exists()or not A.is_file():return _A
	format=A.suffix[1:].upper()
	if format not in COMPATIBLE_IMAGE_EXTENSIONS:return _A
	return format
class FakeViewItemThumbnail:
	pixels:np.ndarray;size:tuple[int,int];filepath:str
	def __init__(A,idname:str,filepath:str,size:tuple[int,int]=(100,100),pixels=_A):A.id=idname;A.pixels=pixels;A.size=size;A.filepath=filepath
	def load_gputex(A)->GPUTexture:
		if A.pixels:return gputex_from_pixels(A.size,A.id,A.pixels)
		elif A.filepath:
			C,B=gputex_from_image_file(A.filepath,A.size,A.id)
			if B:A.pixels=B
			return C
		return _A
	def draw(A,p,s)->_A:
		if(B:=A.load_gputex()):0
class FakeViewItem:
	id:str;name:str;icon:FakeViewItemThumbnail
	def __init__(A,name:str='',icon_filepath:str='',icon_size:tuple=(100,100),icon_pixels=_A,id:str=_A)->_A:
		C=icon_pixels;B=icon_filepath;A.id=id if id else uuid4().hex;A.name=name
		if B or C:A.icon=FakeViewItemThumbnail(A.id,B,icon_size,C)
		else:A.icon=_A
	def draw(A,p,s):
		if A.icon:A.icon.draw(p,s)
		else:A.draw_default(p,s)
	def draw_default(A,p,s):' To be overrided in subclasses. '
	def set_icon(A,filepath:str,size:tuple[int,int]=(100,100),pixels=_A)->Union[_E,_F]:A.icon=FakeViewItemThumbnail(A.id,filepath,size,pixels);return A
	def come_true(A)->_A:' Turn fake item into a real item! Save thumbnail and image, brush info...\n            whatever info in corresponding folder and database. '
class FakeViewItem_Texture(FakeViewItem):
	@classmethod
	def from_bl_image(F,image:Image,generate_thumbnail:bool=_C):
		B=image;B[_B]=uuid4().hex;C=F(name=B.name,id=B[_B])
		if generate_thumbnail:from sculpt_plus.path import SculptPlusPaths as G;from sculpt_plus.props import Props;D:str=G.TEMP_FAKE_ITEMS(B[_B]+'.jpg');H=Props.get_temp_thumbnail_image();A:Image=H.copy();A.scale(100,100);A.filepath_raw=D;A.save();E=np.empty(40000,dtype=np.float32);A.pixels.foreach_get(E);C.set_icon(D,size=(100,100),pixels=E);bpy.data.images.remove(A)
		return C
	def come_true(A)->_A:' Turn fake item into a real item! Save thumbnail and image, brush info...\n            whatever info in corresponding folder and database. '
class FakeViewItem_Brush(FakeViewItem):
	use_custom_icon:bool;sculpt_tool:str
	@classmethod
	def from_bl_brush(E,brush:Brush,generate_thumbnail:bool=_C,generate_tex_thumbnail:bool=_C):
		A=brush;A[_B]=uuid4().hex;B=E(name=A.name,sculpt_tool=A.sculpt_tool,id=A[_B])
		if A.use_custom_icon:
			if generate_thumbnail:from sculpt_plus.path import SculptPlusPaths as F;G:str=F.TEMP_FAKE_ITEMS(A[_B]+'.jpg');B.generate_from_filepath(A.icon_filepath,G,_D)
			else:B.set_icon(filepath=A.icon_filepath)
		if(D:=A.texture):
			if isinstance(D,ImageTexture)and(C:=D.image):
				if C.type=='IMAGE'and C.source in{'FILE','SEQUENCE'}and len(C.pixels)>0:B.set_texture(FakeViewItem_Texture.from_bl_image(C,generate_thumbnail=generate_tex_thumbnail))
		return B
	def generate_from_filepath(C,filepath,output,format:str=_D):
		B=output;A=PIL.Image.open(filepath);A.thumbnail((100,100),resample=PIL.Image.Resampling.NEAREST);A=A.transpose(Image.Transpose.FLIP_TOP_BOTTOM);D=np.array(A,dtype=np.float32).reshape(40000)/255
		if format==_D:A.save(B,format=format,optimize=_C,quality=80)
		else:A.save(B,format=format)
		C.set_icon(B,size=(100,100),pixels=D);A.close();del A
	def __init__(A,name:str='',sculpt_tool:str='DRAW',id:str=_A):A.use_custom_icon=False;A.sculpt_tool=sculpt_tool;A.texture=_A;super().__init__(name,id=id);'\n        super().__init__(name, icon_filepath, icon_size, icon_pixels)\n        if texture_data:\n            self.texture = FakeViewItem_Texture(**texture_data)\n        else:\n            self.texture = None\n        '
	def set_icon(B,filepath:str,size:tuple[int,int]=(100,100),pixels=_A)->Union[_E,_F]:
		A=filepath
		if exists(A)and isfile(A):B.use_custom_icon=_C
		super().set_icon(A,size,pixels)
	def load_icon(A):
		if A.use_custom_icon:super().load_icon()
		else:A.icon=get_brush_type_tex(A.icon_filepath)
	def set_texture(A,fake_texture:FakeViewItem_Texture)->_E:A.texture=fake_texture;return A
	def new_texture(B,name:str='',icon_filepath:str='',icon_size:tuple=(100,100),icon_pixels=_A,id:str=_A):A=FakeViewItem_Texture(name=name,icon_filepath=icon_filepath,icon_size=icon_size,icon_pixels=icon_pixels,id=id);B.set_texture(A);return A
	def come_true(A)->_A:
		' Turn fake item into a real item! Save thumbnail and image, brush info...\n            whatever info in corresponding folder and database. '
		if A.texture is not _A:A.texture.come_true()