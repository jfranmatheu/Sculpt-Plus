_M='thumbnails'
_L='fake_items'
_K='config.json'
_J='images'
_I='defaults'
_H='previews'
_G='.png'
_F='settings'
_E=True
_D='DBShelfManager'
_C='cats'
_B=False
_A=None
import os
from os.path import join,dirname,abspath,exists as path_exists,isfile
import sys,pathlib
from pathlib import Path
import shelve,pickle
from enum import Enum
def get_datadir()->pathlib.Path:
	'\n    Returns a parent directory path\n    where persistent application data can be stored.\n\n    # linux: ~/.local/share\n    # macOS: ~/Library/Application Support\n    # windows: C:/Users/<USER>/AppData/Roaming\n    ';A=pathlib.Path.home()
	if sys.platform=='win32':return A/'AppData/Roaming/Blender Foundation/Blender'
	elif sys.platform=='linux':return A/'.config/blender'
	elif sys.platform=='darwin':return A/'Library/Application Support/Blender'
addon_data_dir=get_datadir()/'addon_data'
app_dir=addon_data_dir/__package__
temp_dir=app_dir/'temp'
data_dir=app_dir/'data'
data_brush_dir=data_dir/'brush'
data_texture_dir=data_dir/'texture'
version_file=app_dir/'version.ini'
management_config_file=data_dir/_K
def ensure_paths():
	B='ascii'
	try:
		app_dir.mkdir(parents=_E,exist_ok=_E)
		if not version_file.exists():version_file.touch()
		with version_file.open('w',encoding=B)as A:from .  import bl_info as C;A.write(f"{C['version']}\n")
		data_dir.mkdir(parents=_B);temp_dir.mkdir();(data_brush_dir/_F/_I).mkdir(parents=_E);(data_brush_dir/_C).mkdir();(data_brush_dir/_H).mkdir();(data_texture_dir/_F/_I).mkdir(parents=_E);(data_texture_dir/_C).mkdir();(data_texture_dir/_H).mkdir();(data_texture_dir/_J).mkdir();(temp_dir/_L).mkdir();(temp_dir/_M).mkdir()
		if not management_config_file.exists():
			management_config_file.touch()
			with management_config_file.open('w',encoding=B)as A:A.write('{ }')
	except FileExistsError:pass
ensure_paths()
class SculptPlusPaths(Enum):
	SRC=dirname(abspath(__file__));SRC_LIB=join(SRC,'lib');SRC_LIB_IMAGES=join(SRC_LIB,_J);SRC_LIB_IMAGES_ICONS=join(SRC_LIB_IMAGES,'icons');SRC_LIB_IMAGES_BRUSHES=join(SRC_LIB_IMAGES,'brushes');SRC_LIB_SCRIPTS=join(SRC_LIB,'scripts');SRC_LIB_BLEND=join(SRC_LIB,'blend');BLEND_EMPTY=join(SRC_LIB_BLEND,'empty.blend');LIB_SHADERS=join(SRC_LIB,'shaders');LIB_SHADERS_VERT=join(LIB_SHADERS,'vert');LIB_SHADERS_FRAG=join(LIB_SHADERS,'frag');LIB_SHADERS_BUILTIN=join(LIB_SHADERS,'builtin');APP=str(app_dir);APP__DATA=str(data_dir);APP__TEMP=str(temp_dir);CONFIG_FILE=str(data_dir/_K);HOTBAR_CONFIG=str(data_brush_dir/'hotbar.txt');DATA_BRUSH_SETTINGS=str(data_brush_dir/_F);DATA_BRUSH_DEFAULTS=str(data_brush_dir/_F/_I);DATA_BRUSH_CATS=str(data_brush_dir/_C);DATA_BRUSH_PREVIEWS=str(data_brush_dir/_H);DATA_BRUSH_CAT_ICONS=str(data_brush_dir/_C);DATA_TEXTURE_SETTINGS=str(data_texture_dir/_F);DATA_TEXTURE_CATS=str(data_texture_dir/_C);DATA_TEXTURE_PREVIEWS=str(data_texture_dir/_H);DATA_TEXTURE_IMAGES=str(data_texture_dir/_J);DATA_TEXTURE_CAT_ICONS=str(data_texture_dir/_C);TEMP_FAKE_ITEMS=str(temp_dir/_L);TEMP_THUMBNAILS=str(temp_dir/_M)
	def __call__(A,*B):
		if not B:return A.value
		return join(A.value,*(B))
	def read(A,*B)->str:
		with open(A(*(B)),mode='r')as C:return C.read()
class ScriptPaths:GENERATE_THUMBNAILS=SculptPlusPaths.SRC_LIB_SCRIPTS('generate_thumbnails.py');GENERATE_NPZ_FROM_BLENDLIB=SculptPlusPaths.SRC_LIB_SCRIPTS('generate_images_n_thumbnails.py');EXPORT_BRUSHES_FROM_BLENDLIB=SculptPlusPaths.SRC_LIB_SCRIPTS('export_brushes_from_blendlib.py');CONVERT_TEXTURES_TO_PNG_FROM_BLENDLIB=SculptPlusPaths.SRC_LIB_SCRIPTS('convert_textures_to_png_from_blendlib.py');EXPORT_TEXTURES_FROM_DIRECTORY=SculptPlusPaths.SRC_LIB_SCRIPTS('export_textures_from_directory.py');GENERATE_NPY_FROM_IMAGE_PATHS=SculptPlusPaths.SRC_LIB_SCRIPTS('generate_npy_from_image_paths.py')
class ThumbnailPaths:
	@staticmethod
	def _GET_PATH(_path:SculptPlusPaths,item:str,ext:str=_G,check_exists:bool=_B)->Path or str:
		A=item;D:str=A if isinstance(A,str)else A.id;C:str=_path(D+ext)
		if not check_exists:return C
		B:Path=Path(C);return B if B.exists()and B.is_file()else _A
	@classmethod
	def BRUSH(A,brush,check_exists:bool=_B)->Path or _A:return A._GET_PATH(SculptPlusPaths.DATA_BRUSH_PREVIEWS,brush,ext=_G,check_exists=check_exists)
	@classmethod
	def TEXTURE(A,texture,check_exists:bool=_B)->Path or _A:return A._GET_PATH(SculptPlusPaths.DATA_TEXTURE_PREVIEWS,texture,ext=_G,check_exists=check_exists)
	@classmethod
	def BRUSH_CAT(A,cat,check_exists:bool=_B)->Path or _A:return A._GET_PATH(SculptPlusPaths.DATA_BRUSH_CAT_ICONS,cat,ext=_G,check_exists=check_exists)
	@classmethod
	def TEXTURE_CAT(A,cat,check_exists:bool=_B)->Path or _A:return A._GET_PATH(SculptPlusPaths.DATA_TEXTURE_CAT_ICONS,cat,ext=_G,check_exists=check_exists)
	@classmethod
	def get_texture_image_path(B,texture,check_exists:bool=_B)->Path or _A:A=texture;return B._GET_PATH(SculptPlusPaths.DATA_TEXTURE_CAT_ICONS,A,ext=A.image.ext,check_exists=check_exists)
	@classmethod
	def remove_brush_previews(A,brush_ids:list[str])->_A:
		for B in brush_ids:
			if(C:=A.BRUSH(B)):C.unlink()
	@classmethod
	def remove_texture_previews(A,tex_ids:list[str])->_A:
		for B in tex_ids:
			if(C:=A.TEXTURE(B)):C.unlink()
class DBPickle(Enum):
	BRUSH_SETTINGS=SculptPlusPaths.DATA_BRUSH_SETTINGS;BRUSH_DEFAULTS=SculptPlusPaths.DATA_BRUSH_DEFAULTS;BRUSH_CAT=SculptPlusPaths.DATA_BRUSH_CATS;TEXTURE_CAT=SculptPlusPaths.DATA_TEXTURE_CATS;TEXTURES=SculptPlusPaths.DATA_TEXTURE_SETTINGS
	def load(B,item):
		A=item;C:str=A if isinstance(A,str)else A.id;D:str=B.value(C)
		with open(D,'rb')as E:return pickle.load(E)
	def write(A,item):
		B:str=A.value(item.id)
		with open(B,'wb')as C:pickle.dump(item,C)
	def remove(B,item):A=item;C:str=A if isinstance(A,str)else A.id;D:str=B.value(C);os.remove(D)
class DBShelfPaths:BRUSH_SETTINGS=SculptPlusPaths.APP__DATA('brush_settings');BRUSH_DEFAULTS=SculptPlusPaths.APP__DATA('brush_defaults');BRUSH_CAT=SculptPlusPaths.APP__DATA('brush_cats');TEXTURE_CAT=SculptPlusPaths.APP__DATA('texture_cats');TEXTURES=SculptPlusPaths.APP__DATA('textures');TEMPORAL=SculptPlusPaths.APP__TEMP('temporal_items')
class DBShelf(Enum):
	BRUSH_SETTINGS=DBShelfPaths.BRUSH_SETTINGS;BRUSH_DEFAULTS=DBShelfPaths.BRUSH_DEFAULTS;BRUSH_CAT=DBShelfPaths.BRUSH_CAT;TEXTURE_CAT=DBShelfPaths.TEXTURE_CAT;TEXTURES=DBShelfPaths.TEXTURES;TEMPORAL=DBShelfPaths.TEMPORAL
	def destroy(A)->_A:Path(A.value).unlink()
	def items(A)->dict:
		B:str=A.value
		with shelve.open(B)as C:return C.items()
	def values(A)->list:
		B:str=A.value
		with shelve.open(B)as C:return list(C.values())
	def write(B,*C:tuple):
		D:str=B.value
		with shelve.open(D)as E:
			for A in C:E[A.id]=A
	def remove(B,*C:tuple[str]):
		D:str=B.value
		with shelve.open(D)as E:
			for A in C:F:str=A if isinstance(A,str)else A.id;del E[F]
	def reset(A)->_A:' Remove everything from this database. ';B=shelve.open(A.value,flag='n');B.close()
class DBShelfManager:
	@classmethod
	def TEMPORAL(A,cleanup:bool=_E)->_D:return A(DBShelfPaths.TEMPORAL,cleanup=cleanup)
	@classmethod
	def BRUSH_SETTINGS(A)->_D:return A(DBShelfPaths.BRUSH_SETTINGS)
	@classmethod
	def BRUSH_DEFAULTS(A)->_D:return A(DBShelfPaths.BRUSH_DEFAULTS)
	@classmethod
	def BRUSH_CAT(A)->_D:return A(DBShelfPaths.BRUSH_CAT)
	@classmethod
	def TEXTURE_CAT(A)->_D:return A(DBShelfPaths.TEXTURE_CAT)
	@classmethod
	def TEXTURE(A)->_D:return A(DBShelfPaths.TEXTURES)
	def __init__(E,path:str,cleanup:bool=_B):
		A=path;E.db_path=A
		if cleanup:
			B=Path(A+'.dat')
			if B.exists()and B.is_file():B.unlink()
			C=Path(A+'.dir')
			if C.exists()and C.is_file():C.unlink()
			D=Path(A+'.bak')
			if D.exists()and D.is_file():D.unlink()
	def __enter__(A):A.db=shelve.open(A.db_path);return A
	def get(A,key:str):return A.db[key]
	def write(B,component):A=component;B.db[A.id]=A
	def remove(B,component):A=component;C:str=A if isinstance(A,str)else A.id;del B.db[C]
	def get_items(A)->list:return list(A.db.items())
	def __exit__(A,exc_type,exc_value,exc_traceback):A.db.close()
	def reset(A)->_A:' Remove everything from this database. ';A.db.close();A.db=shelve.open(A.db_path,flag='n')