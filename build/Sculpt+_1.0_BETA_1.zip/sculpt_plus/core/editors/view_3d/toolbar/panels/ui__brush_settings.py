_C='TRIA_DOWN'
_B=False
_A=True
from ._dummy import DummyPanel
from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
from bl_ui.properties_paint_common import brush_settings,brush_settings_advanced,brush_texture_settings,StrokePanel,FalloffPanel
from bpy.types import UILayout
from sculpt_plus.props import Props
def draw_brush_settings_tabs(layout,context):
	L='BRUSH_SETTINGS_FALLOFF';K='BRUSH_SETTINGS';J='show_brush_settings_panel';B=context;from sculpt_plus.core.data.wm import SCULPTPLUS_PG_ui_toggles as M;C:M=Props.UI(B);D:str=C.toolbar_brush_sections;N=B.tool_settings.sculpt;E=N.brush;F=layout.column(align=_A);F.use_property_split=_A;G=F.box().row(align=_A);G.scale_y=1.5;G.use_property_split=_B;I,O=ToolSelectPanelHelper._tool_key_from_context(B);P=ToolSelectPanelHelper._tool_class_from_space_type(I);Q,V,R=P._tool_get_active(B,I,O,with_icon=_A)
	if Q is None:return None
	S=E.name;G.label(text='',icon_value=R);T=_C if C.show_brush_settings_panel else'TRIA_LEFT';G.prop(C,J,expand=_A,text=S+' Brush',emboss=_B);G.prop(C,J,expand=_A,text='',icon=T,emboss=_B)
	if not C.show_brush_settings_panel:return
	H=F.grid_flow(align=_A,columns=0);H.use_property_split=_B;H.scale_y=1.35;H.prop(C,'toolbar_brush_sections',text='',expand=_A);U=F.box();U.ui_units_y=0.1;A=F.box().column(align=_B if D in{K,L}else _A);A.separator()
	if D==K:brush_settings(A,B,E)
	elif D=='BRUSH_SETTINGS_ADVANCED':A.use_property_split=_B;brush_settings_advanced(A,B,E)
	elif D=='BRUSH_SETTINGS_STROKE':StrokePanel.draw(DummyPanel(A),B)
	elif D==L:FalloffPanel.draw(DummyPanel(A),B)
	elif D=='BRUSH_SETTINGS_TEXTURE':A.template_icon(icon_value=UILayout.icon(E.texture),scale=5.0);brush_texture_settings(A,E,sculpt=_A)
	A.separator(factor=0.5)
def draw_brush_settings_expandable(layout,context):
	O='show_brush_settings_texture';N='show_brush_settings_falloff';M='show_brush_settings_stroke';L='show_brush_settings_advanced';K='show_brush_settings';I='NONE';H='TRIA_RIGHT';G=context;from sculpt_plus.core.data.wm import SCULPTPLUS_PG_ui_toggles as P;A:P=Props.UI(G);Q=G.tool_settings.sculpt;J=Q.brush;F=layout.column();F.use_property_split=_A;D=F.column(align=_A);B=D.row(align=_A);B.use_property_split=_B;B.box().label(text='',icon='BRUSH_DATA');E=_C if A.show_brush_settings else H;C=B.box().row(align=_A);C.emboss=I;C.prop(A,K,text='Brush Settings',toggle=_B);C.prop(A,K,text='',icon=E,toggle=_B)
	if A.show_brush_settings:
		brush_settings(D.box(),G,J);E=_C if A.show_brush_settings_advanced else H;B=D.row(align=_A);B.use_property_split=_B;B.box().label(text='',icon='GHOST_ENABLED');C=B.box().row(align=_A);C.emboss=I;C.prop(A,L,text='Advanced',toggle=_B);C.prop(A,L,text='',icon=E,toggle=_B)
		if A.show_brush_settings_advanced:brush_settings_advanced(D.box(),G,J)
	F.separator();D=F.column(align=_A);B=D.row(align=_A);B.use_property_split=_B;B.box().label(text='',icon='GP_SELECT_STROKES');E=_C if A.show_brush_settings_stroke else H;C=B.box().row(align=_A);C.emboss=I;C.prop(A,M,text='Stroke Settings',toggle=_B);C.prop(A,M,text='',icon=E,toggle=_B)
	if A.show_brush_settings_stroke:StrokePanel.draw(DummyPanel(D.box()),G)
	F.separator();D=F.column(align=_A);B=D.row(align=_A);B.use_property_split=_B;B.box().label(text='',icon='SMOOTHCURVE');E=_C if A.show_brush_settings_falloff else H;C=B.box().row(align=_A);C.emboss=I;C.prop(A,N,text='Falloff Settings',toggle=_B);C.prop(A,N,text='',icon=E,toggle=_B)
	if A.show_brush_settings_falloff:FalloffPanel.draw(DummyPanel(D.box()),G)
	if J.texture is None:return
	F.separator();D=F.column(align=_A);B=D.row(align=_A);B.use_property_split=_B;B.box().label(text='',icon='TEXTURE_DATA');E=_C if A.show_brush_settings_texture else H;C=B.box().row(align=_A);C.emboss=I;C.prop(A,O,text='Texture Settings',toggle=_B);C.prop(A,O,text='',icon=E,toggle=_B)
	if A.show_brush_settings_texture:brush_texture_settings(D.box(),J,sculpt=_A)