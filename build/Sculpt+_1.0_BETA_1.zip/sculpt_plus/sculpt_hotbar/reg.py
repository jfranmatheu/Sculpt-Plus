_A=None
import bpy,functools
from bpy.app.timers import register as register_timer,is_registered as is_timer_registered
sculpt_hotbar_classes=[]
exclude_brush_tools:set[str]={'MASK','DRAW_FACE_SETS','DISPLACEMENT_ERASER','DISPLACEMENT_SMEAR','SIMPLIFY'}
def register():
	L='FINISHED';K='master';J='VIEW3D_GZ_sculpt_hotbar';I='setup';H='bl_idname';G='SCULPT';C=True;B='cv';print('[SculptHotbar] Registering...');from mathutils import Vector;from sculpt_plus.prefs import get_prefs as F;from sculpt_plus.sculpt_hotbar.km import WidgetKM as M;from sculpt_plus.sculpt_hotbar.canvas import Canvas as N;from sculpt_plus.utils.gpu import LiveView;from sculpt_plus.props import Props as A;from bl_ui.space_toolsystem_toolbar import VIEW3D_PT_tools_active;from bl_ui.space_toolsystem_common import ToolSelectPanelHelper as O
	def P(gzg,ctx,gmaster):
		D=gzg;B=ctx;A=gmaster;D.roff=0,0;D.rdim=B.region.width,B.region.height;A.reg=B.region;A.init(B);A.use_event_handle_all=C;A.use_draw_modal=C;A.scale_basis=1.0
		if not bpy.sculpt_hotbar._cv_instance:bpy.sculpt_hotbar._cv_instance=A.cv
		D.master=A
	def D():
		C=bpy.context
		if(D:=A.GetActiveBrush()):A.SelectBrush(C,D)
		elif(E:=list(A.BrushManager().brushes.values())):A.SelectBrush(C,E[0])
		else:
			if C.space_data is _A:A.BrushManager().active_sculpt_tool='NULL';return _A
			bpy.ops.wm.tool_set_by_id(name='builtin_brush.Draw');B=O.tool_active_from_context(C)
			if B is _A:return
			type,B=B.idname.split('.');B=B.replace(' ','_').upper()
			if B in exclude_brush_tools or type!='builtin_brush':return
			A.BrushManager().active_sculpt_tool=B
	def Q(ctx):
		if ctx.mode!=G:return False
		B=A.BrushManager()
		if not B.initilized or not B.active_sculpt_tool:
			if is_timer_registered(D):return C
			B.initilized=C;register_timer(D,first_interval=0.1)
		'\n        prev_active_tool = Props.BrushManager().active_sculpt_tool\n        curr_active_tool = ToolSelectPanelHelper.tool_active_from_context(ctx)\n        if curr_active_tool is None:\n            return\n        type, curr_active_tool = curr_active_tool.idname.split(\'.\')\n        curr_active_tool = curr_active_tool.replace(\' \', \'_\').upper()\n        if prev_active_tool != curr_active_tool:\n            if curr_active_tool in exclude_brush_tools or type != \'builtin_brush\':\n                return True\n            Props.BrushManager().active_sculpt_tool = curr_active_tool\n            print(f"Info! Changed tool from {prev_active_tool} to {curr_active_tool}.")\n            if curr_active_tool == \'ALL_BRUSH\':\n                if active_br := Props.GetActiveBrush():\n                    Props.SelectBrush(ctx, active_br)\n                elif brushes := list(Props.BrushManager().brushes.values()):\n                    Props.SelectBrush(ctx, brushes[0])\n                else:\n                    bpy.ops.wm.tool_set_by_id(name=\'builtin_brush.draw\')\n        ';return C
	def R(gzg,ctx):return C
	def S(gzg,ctx,cv):
		B=gzg;A=ctx;C=0;D=0;K=0;I=0
		for E in A.area.regions:
			if E.type=='TOOLS':C+=E.width
			elif E.type=='UI':I+=E.width
		G=A.region.width-I-C;H=A.region.height-K-D
		if cv.reg!=A.region or B.rdim[0]!=G or B.rdim[1]!=H or C!=B.roff[0]or D!=B.roff[1]:cv.reg=A.region;cv.refresh();B.roff=C,D;B.rdim=G,H;J=F(A);cv.update((C,D),(G,H),J.get_scale(A),J)
	from bpy.types import GizmoGroup as T,Gizmo as U;from ..utils.gpu import OffscreenBuffer as V;W=type('SculptHotbarGController',(T,M),{H:'VIEW3D_GZG_sculpt_hotbar','bl_label':'Sculpt Hotbar Controller','bl_space_type':'VIEW_3D','bl_region_type':'WINDOW','bl_options':{'PERSISTENT','SHOW_MODAL_ALL'},'gz':J,'poll':classmethod(lambda x,y:Q(y)and y.object and y.mode==G and y.scene.sculpt_hotbar.show_gizmo_sculpt_hotbar and y.space_data.show_gizmo),'draw_prepare':lambda x,y:S(x,y,x.master.cv)if hasattr(x,K)and hasattr(x.master,B)else _A,I:lambda x,y:P(x,y,x.gizmos.new(x.__class__.gz)),'refresh':lambda x,y:setattr(x.master.cv,'reg',y.region)if R(x,y)and hasattr(x,K)and hasattr(x.master,B)else _A});E=type('SculptHotbarGMaster',(U,),{H:J,'_cv_instance':_A,'get':classmethod(lambda x,r:x._cv_instance if x._cv_instance is not _A else N(r)),'init':lambda x,c:x.cv.update((0,0),(c.region.width,c.region.height),F(c).get_scale(c),F(c)),I:lambda x:setattr(x,B,x.__class__.get(bpy.context.region)),'test_select':lambda x,c,_:x.cv.test(c,_)if hasattr(x,B)else-1,'invoke':lambda x,c,e:x.cv.invoke(c,e)if hasattr(x,B)else{L},'modal':lambda x,c,e,_:x.cv.modal(c,e,_)if hasattr(x,B)else{L},'exit':lambda x,c,_:x.cv.exit(c,_)if hasattr(x,B)else _A,'draw':lambda x,c:V.draw(c)});global sculpt_hotbar_classes;sculpt_hotbar_classes=[E,W]
	for X in sculpt_hotbar_classes:bpy.utils.register_class(X)
	bpy.sculpt_hotbar=E
def unregister():
	print('[SculptHotbar] Unregistering...')
	for A in sculpt_hotbar_classes:bpy.utils.unregister_class(A)
	if getattr(bpy,'sculpt_hotbar',_A):del bpy.sculpt_hotbar
	sculpt_hotbar_classes.clear()