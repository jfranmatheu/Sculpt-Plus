def gizmo_display_ext(self,context):
	A=context
	if A.mode!='SCULPT':return
	self.layout.prop(A.scene.sculpt_hotbar,'show_gizmo_sculpt_hotbar',text='Sculpt Hotbar')
def register():from bpy.types import VIEW3D_PT_gizmo_display as A;A.prepend(gizmo_display_ext)
def unregister():from bpy.types import VIEW3D_PT_gizmo_display as A;A.remove(gizmo_display_ext)