_B=False
_A=True
from bpy.types import UILayout,MultiresModifier,VIEW3D_PT_sculpt_voxel_remesh,VIEW3D_PT_sculpt_dyntopo
from sculpt_plus.utils.modifiers import get_modifier_by_type
from sculpt_plus.props import Props
from ._dummy import DummyPanel
def draw_sculpt_sections(layout:UILayout,context):
	b='sculpt.dynamic_topology_toggle';a='REMOVE';Z='ADD';Y='MULTIRES';X='show_sculpt_mesh_panel';U='INFO';T=None;S='toolbar_sculpt_sections';I='sculpt_plus.remesh_voxel_increase_size';H='';F=context;E='sculpt_plus.remesh_voxel_increase_density';D=Props.UI(F);J:str=D.toolbar_sculpt_sections;c:str=UILayout.enum_item_description(D,S,J);d:int=UILayout.enum_item_icon(D,S,J);L=layout.column(align=_A);M=L.box().row(align=_A);M.scale_y=1.5;O=M.row(align=_A);O.scale_y=0.5;O.scale_x=0.75;O.template_icon(icon_value=d,scale=2.0);e='TRIA_DOWN'if D.show_sculpt_mesh_panel else'TRIA_LEFT';M.prop(D,X,expand=_A,text=c,emboss=_B);M.prop(D,X,expand=_A,text=H,icon=e,emboss=_B)
	if not D.show_sculpt_mesh_panel:return
	P=get_modifier_by_type(F.sculpt_object,Y);V=F.sculpt_object.use_dynamic_topology_sculpting or P is not T
	if not V:Q=L.grid_flow(align=_A,row_major=_A,even_columns=_A,even_rows=_A,columns=0);Q.use_property_split=_B;Q.scale_y=1.35;Q.prop(D,S,text=H,expand=_A);f=L.box();f.ui_units_y=0.1
	B=L.box().column(align=_B)
	if not V:B.separator()
	B.use_property_split=_A;B.use_property_decorate=_B;g=DummyPanel(B),F
	if J=='VOXEL_REMESH':
		N=F.sculpt_object.data;K=B.row(align=_A);K.prop(N,'remesh_voxel_size');h=K.operator('sculpt.sample_detail_size',text=H,icon='EYEDROPPER');h.mode='VOXEL';B.prop(N,'remesh_voxel_adaptivity')
		if N.remesh_voxel_adaptivity==0:B.prop(N,'use_remesh_fix_poles')
		W=B.column(align=_B);G=W.column(align=_A);G.label(text='Increment / Decrement Voxel Size :');A=G.row(align=_A);A.label(text=H,icon=Z);A.operator(I,text='0.1').value=0.1;A.operator(I,text='0.01').value=0.01;A.operator(I,text='0.001').value=0.001;A=G.row(align=_A);A.label(text=H,icon=a);A.operator(I,text='-0.1').value=-0.1;A.operator(I,text='-0.01').value=-0.01;A.operator(I,text='-0.001').value=-0.001;G=W.column(align=_A);G.label(text='Change Voxel Density (in %) :');A=G.row(align=_A);A.label(text=H,icon=Z);A.operator(E,text='10%').value=10;A.operator(E,text='20%').value=20;A.operator(E,text='33%').value=33;A.operator(E,text='50%').value=50;A=G.row(align=_A);A.label(text=H,icon=a);A.operator(E,text='-10%').value=-10;A.operator(E,text='-20%').value=-20;A.operator(E,text='-33%').value=-33;A.operator(E,text='-50%').value=-50;B.separator();K=B.row();K.scale_y=1.5;K.operator('object.voxel_remesh')
	elif J=='QUAD_REMESH':B.scale_y=1.5;B.operator('object.quadriflow_remesh',text='QuadriFlow Remesh')
	elif J=='DYNTOPO':
		if not F.sculpt_object.use_dynamic_topology_sculpting:C=B.box();C.scale_y=1.5;C.label(text='You should enable Dyntopo!',icon=U);C.operator(b,text='Enable Dyntopo');return
		else:
			i=VIEW3D_PT_sculpt_dyntopo.paint_settings(F)
			if i is T:C=B.box();C.scale_y=1.5;C.label(text='Only shown when using a brush.',icon=U);return
			VIEW3D_PT_sculpt_dyntopo.draw(*(g));B.separator();R=B.row();R.scale_y=1.5;R.alert=_A;R.operator(b,text='Disable Dyntopo')
	else:
		if P is T:C=B.box();C.scale_y=1.5;C.label(text='No Multires Modifier',icon=U);C.operator('object.modifier_add',text='Add Multires Modifier').type=Y;return
		draw_sculpt_multires(B,P)
	B.separator(factor=0.1)
def draw_sculpt_multires(layout:UILayout,mod:MultiresModifier):
	K='sculpt_plus.multires_apply';J='object.multires_subdivide';E=mod;B=layout;B.use_property_split=_B;G=B.column(align=_A);C=G.box();C.scale_y=0.8;C.label(text='L e v e l s',icon='ALIASED');G=G.grid_flow(row_major=_A,columns=4,even_columns=_A,even_rows=_A,align=_A);G.scale_y=1.5
	for H in range(E.total_levels+1):G.operator('sculpt_plus.multires_change_level',text=str(H),depress=H==E.sculpt_levels).level=H
	B.separator(factor=0.25);A=B.column(align=_A);C=A.box();C.scale_y=0.8;C.label(text='L e v e l   U p !  (Subdivide)',icon='SORT_DESC');A=A.row(align=_A);A.scale_y=1.5;D=A.operator(J,text='Smooth');D.modifier=E.name;D.mode='CATMULL_CLARK';D=A.operator(J,text='Simple');D.modifier=E.name;D.mode='SIMPLE';D=A.operator(J,text='Linear');D.modifier=E.name;D.mode='LINEAR';B.separator(factor=0.25);A=B.column(align=_A);C=A.box();C.scale_y=0.8;C.label(text='L e v e l   D o w n !',icon='SORT_ASC');A=A.column(align=_A);A.operator('object.multires_unsubdivide',text='Rebuild Lower Level from Base Level');A.operator('object.multires_higher_levels_delete',text='Delete Higher Levels from Level '+str(E.sculpt_levels));B.separator(factor=0.25);A=B.column(align=_A);C=A.box();C.scale_y=0.8;C.label(text='S h a p e   M o r p h',icon='MONKEY');A=A.column(align=_A);A.operator('object.multires_reshape',text='Reshape');A.operator('object.multires_base_apply',text='Apply Base');B.separator();B.prop(E,'use_sculpt_base_mesh');B.separator();I=B.column(align=_B);F=I.split(factor=0.33,align=_B);F.scale_y=1.5;F.operator(K,text='Apply').as_shape_key=_B;F.operator(K,text='Apply as ShapeKey').as_shape_key=_B;I.separator(factor=0.5);F=I.row();F.scale_y=1.2;F.alert=_A;F.operator('sculpt_plus.multires_remove',text='Remove')