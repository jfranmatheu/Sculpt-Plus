'Sorted Set\n=============\n\n:doc:`Sorted Containers<index>` is an Apache2 licensed Python sorted\ncollections library, written in pure-Python, and fast as C-extensions. The\n:doc:`introduction<introduction>` is the best way to get started.\n\nSorted set implementations:\n\n.. currentmodule:: sortedcontainers\n\n* :class:`SortedSet`\n\n'
_A=None
from itertools import chain
from operator import eq,ne,gt,ge,lt,le
from textwrap import dedent
from.sortedlist import SortedList,recursive_repr
try:from collections.abc import MutableSet,Sequence,Set
except ImportError:from collections import MutableSet,Sequence,Set
class SortedSet(MutableSet,Sequence):
	'Sorted set is a sorted mutable set.\n\n    Sorted set values are maintained in sorted order. The design of sorted set\n    is simple: sorted set uses a set for set-operations and maintains a sorted\n    list of values.\n\n    Sorted set values must be hashable and comparable. The hash and total\n    ordering of values must not change while they are stored in the sorted set.\n\n    Mutable set methods:\n\n    * :func:`SortedSet.__contains__`\n    * :func:`SortedSet.__iter__`\n    * :func:`SortedSet.__len__`\n    * :func:`SortedSet.add`\n    * :func:`SortedSet.discard`\n\n    Sequence methods:\n\n    * :func:`SortedSet.__getitem__`\n    * :func:`SortedSet.__delitem__`\n    * :func:`SortedSet.__reversed__`\n\n    Methods for removing values:\n\n    * :func:`SortedSet.clear`\n    * :func:`SortedSet.pop`\n    * :func:`SortedSet.remove`\n\n    Set-operation methods:\n\n    * :func:`SortedSet.difference`\n    * :func:`SortedSet.difference_update`\n    * :func:`SortedSet.intersection`\n    * :func:`SortedSet.intersection_update`\n    * :func:`SortedSet.symmetric_difference`\n    * :func:`SortedSet.symmetric_difference_update`\n    * :func:`SortedSet.union`\n    * :func:`SortedSet.update`\n\n    Methods for miscellany:\n\n    * :func:`SortedSet.copy`\n    * :func:`SortedSet.count`\n    * :func:`SortedSet.__repr__`\n    * :func:`SortedSet._check`\n\n    Sorted list methods available:\n\n    * :func:`SortedList.bisect_left`\n    * :func:`SortedList.bisect_right`\n    * :func:`SortedList.index`\n    * :func:`SortedList.irange`\n    * :func:`SortedList.islice`\n    * :func:`SortedList._reset`\n\n    Additional sorted list methods available, if key-function used:\n\n    * :func:`SortedKeyList.bisect_key_left`\n    * :func:`SortedKeyList.bisect_key_right`\n    * :func:`SortedKeyList.irange_key`\n\n    Sorted set comparisons use subset and superset relations. Two sorted sets\n    are equal if and only if every element of each sorted set is contained in\n    the other (each is a subset of the other). A sorted set is less than\n    another sorted set if and only if the first sorted set is a proper subset\n    of the second sorted set (is a subset, but is not equal). A sorted set is\n    greater than another sorted set if and only if the first sorted set is a\n    proper superset of the second sorted set (is a superset, but is not equal).\n\n    '
	def __init__(A,iterable=_A,key=_A):
		"Initialize sorted set instance.\n\n        Optional `iterable` argument provides an initial iterable of values to\n        initialize the sorted set.\n\n        Optional `key` argument defines a callable that, like the `key`\n        argument to Python's `sorted` function, extracts a comparison key from\n        each value. The default, none, compares values directly.\n\n        Runtime complexity: `O(n*log(n))`\n\n        >>> ss = SortedSet([3, 1, 2, 5, 4])\n        >>> ss\n        SortedSet([1, 2, 3, 4, 5])\n        >>> from operator import neg\n        >>> ss = SortedSet([3, 1, 2, 5, 4], neg)\n        >>> ss\n        SortedSet([5, 4, 3, 2, 1], key=<built-in function neg>)\n\n        :param iterable: initial values (optional)\n        :param key: function used to extract comparison key (optional)\n\n        ";E=iterable;C=key;A._key=C
		if not hasattr(A,'_set'):A._set=set()
		A._list=SortedList(A._set,key=C);D=A._set;A.isdisjoint=D.isdisjoint;A.issubset=D.issubset;A.issuperset=D.issuperset;B=A._list;A.bisect_left=B.bisect_left;A.bisect=B.bisect;A.bisect_right=B.bisect_right;A.index=B.index;A.irange=B.irange;A.islice=B.islice;A._reset=B._reset
		if C is not _A:A.bisect_key_left=B.bisect_key_left;A.bisect_key_right=B.bisect_key_right;A.bisect_key=B.bisect_key;A.irange_key=B.irange_key
		if E is not _A:A._update(E)
	@classmethod
	def _fromset(B,values,key=_A):'Initialize sorted set from existing set.\n\n        Used internally by set operations that return a new set.\n\n        ';A=object.__new__(B);A._set=values;A.__init__(key=key);return A
	@property
	def key(self):'Function used to extract comparison key from values.\n\n        Sorted set compares values directly when the key function is none.\n\n        ';return self._key
	def __contains__(A,value):'Return true if `value` is an element of the sorted set.\n\n        ``ss.__contains__(value)`` <==> ``value in ss``\n\n        Runtime complexity: `O(1)`\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> 3 in ss\n        True\n\n        :param value: search for value in sorted set\n        :return: true if `value` in sorted set\n\n        ';return value in A._set
	def __getitem__(A,index):"Lookup value at `index` in sorted set.\n\n        ``ss.__getitem__(index)`` <==> ``ss[index]``\n\n        Supports slicing.\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> ss = SortedSet('abcde')\n        >>> ss[2]\n        'c'\n        >>> ss[-1]\n        'e'\n        >>> ss[2:5]\n        ['c', 'd', 'e']\n\n        :param index: integer or slice for indexing\n        :return: value or list of values\n        :raises IndexError: if index out of range\n\n        ";return A._list[index]
	def __delitem__(C,index):
		"Remove value at `index` from sorted set.\n\n        ``ss.__delitem__(index)`` <==> ``del ss[index]``\n\n        Supports slicing.\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> ss = SortedSet('abcde')\n        >>> del ss[2]\n        >>> ss\n        SortedSet(['a', 'b', 'd', 'e'])\n        >>> del ss[:2]\n        >>> ss\n        SortedSet(['d', 'e'])\n\n        :param index: integer or slice for indexing\n        :raises IndexError: if index out of range\n\n        ";A=index;D=C._set;B=C._list
		if isinstance(A,slice):E=B[A];D.difference_update(E)
		else:F=B[A];D.remove(F)
		del B[A]
	def __make_cmp(B,symbol,doc):
		'Make comparator method.'
		def A(self,other):
			'Compare method for sorted set and set.';A=other
			if isinstance(A,SortedSet):return B(self._set,A._set)
			elif isinstance(A,Set):return B(self._set,A)
			return NotImplemented
		C=B.__name__;A.__name__='__{0}__'.format(C);D='Return true if and only if sorted set is {0} `other`.\n\n        ``ss.__{1}__(other)`` <==> ``ss {2} other``\n\n        Comparisons use subset and superset semantics as with sets.\n\n        Runtime complexity: `O(n)`\n\n        :param other: `other` set\n        :return: true if sorted set is {0} `other`\n\n        ';A.__doc__=dedent(D.format(doc,C,symbol));return A
	__eq__=__make_cmp(eq,'==','equal to');__ne__=__make_cmp(ne,'!=','not equal to');__lt__=__make_cmp(lt,'<','a proper subset of');__gt__=__make_cmp(gt,'>','a proper superset of');__le__=__make_cmp(le,'<=','a subset of');__ge__=__make_cmp(ge,'>=','a superset of');__make_cmp=staticmethod(__make_cmp)
	def __len__(A):'Return the size of the sorted set.\n\n        ``ss.__len__()`` <==> ``len(ss)``\n\n        :return: size of sorted set\n\n        ';return len(A._set)
	def __iter__(A):'Return an iterator over the sorted set.\n\n        ``ss.__iter__()`` <==> ``iter(ss)``\n\n        Iterating the sorted set while adding or deleting values may raise a\n        :exc:`RuntimeError` or fail to iterate over all values.\n\n        ';return iter(A._list)
	def __reversed__(A):'Return a reverse iterator over the sorted set.\n\n        ``ss.__reversed__()`` <==> ``reversed(ss)``\n\n        Iterating the sorted set while adding or deleting values may raise a\n        :exc:`RuntimeError` or fail to iterate over all values.\n\n        ';return reversed(A._list)
	def add(B,value):
		'Add `value` to sorted set.\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> ss = SortedSet()\n        >>> ss.add(3)\n        >>> ss.add(1)\n        >>> ss.add(2)\n        >>> ss\n        SortedSet([1, 2, 3])\n\n        :param value: value to add to sorted set\n\n        ';A=value;C=B._set
		if A not in C:C.add(A);B._list.add(A)
	_add=add
	def clear(A):'Remove all values from sorted set.\n\n        Runtime complexity: `O(n)`\n\n        ';A._set.clear();A._list.clear()
	def copy(A):'Return a shallow copy of the sorted set.\n\n        Runtime complexity: `O(n)`\n\n        :return: new sorted set\n\n        ';return A._fromset(set(A._set),key=A._key)
	__copy__=copy
	def count(A,value):'Return number of occurrences of `value` in the sorted set.\n\n        Runtime complexity: `O(1)`\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> ss.count(3)\n        1\n\n        :param value: value to count in sorted set\n        :return: count\n\n        ';return 1 if value in A._set else 0
	def discard(B,value):
		'Remove `value` from sorted set if it is a member.\n\n        If `value` is not a member, do nothing.\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> ss.discard(5)\n        >>> ss.discard(0)\n        >>> ss == set([1, 2, 3, 4])\n        True\n\n        :param value: `value` to discard from sorted set\n\n        ';A=value;C=B._set
		if A in C:C.remove(A);B._list.remove(A)
	_discard=discard
	def pop(A,index=-1):"Remove and return value at `index` in sorted set.\n\n        Raise :exc:`IndexError` if the sorted set is empty or index is out of\n        range.\n\n        Negative indices are supported.\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> ss = SortedSet('abcde')\n        >>> ss.pop()\n        'e'\n        >>> ss.pop(2)\n        'c'\n        >>> ss\n        SortedSet(['a', 'b', 'd'])\n\n        :param int index: index of value (default -1)\n        :return: value\n        :raises IndexError: if index is out of range\n\n        ";B=A._list.pop(index);A._set.remove(B);return B
	def remove(A,value):'Remove `value` from sorted set; `value` must be a member.\n\n        If `value` is not a member, raise :exc:`KeyError`.\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> ss.remove(5)\n        >>> ss == set([1, 2, 3, 4])\n        True\n        >>> ss.remove(0)\n        Traceback (most recent call last):\n          ...\n        KeyError: 0\n\n        :param value: `value` to remove from sorted set\n        :raises KeyError: if `value` is not in sorted set\n\n        ';B=value;A._set.remove(B);A._list.remove(B)
	def difference(A,*B):'Return the difference of two or more sets as a new sorted set.\n\n        The `difference` method also corresponds to operator ``-``.\n\n        ``ss.__sub__(iterable)`` <==> ``ss - iterable``\n\n        The difference is all values that are in this sorted set but not the\n        other `iterables`.\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> ss.difference([4, 5, 6, 7])\n        SortedSet([1, 2, 3])\n\n        :param iterables: iterable arguments\n        :return: new sorted set\n\n        ';C=A._set.difference(*B);return A._fromset(C,key=A._key)
	__sub__=difference
	def difference_update(A,*E):
		'Remove all values of `iterables` from this sorted set.\n\n        The `difference_update` method also corresponds to operator ``-=``.\n\n        ``ss.__isub__(iterable)`` <==> ``ss -= iterable``\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> _ = ss.difference_update([4, 5, 6, 7])\n        >>> ss\n        SortedSet([1, 2, 3])\n\n        :param iterables: iterable arguments\n        :return: itself\n\n        ';B=A._set;D=A._list;C=set(chain(*E))
		if 4*len(C)>len(B):B.difference_update(C);D.clear();D.update(B)
		else:
			F=A._discard
			for G in C:F(G)
		return A
	__isub__=difference_update
	def intersection(A,*B):'Return the intersection of two or more sets as a new sorted set.\n\n        The `intersection` method also corresponds to operator ``&``.\n\n        ``ss.__and__(iterable)`` <==> ``ss & iterable``\n\n        The intersection is all values that are in this sorted set and each of\n        the other `iterables`.\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> ss.intersection([4, 5, 6, 7])\n        SortedSet([4, 5])\n\n        :param iterables: iterable arguments\n        :return: new sorted set\n\n        ';C=A._set.intersection(*B);return A._fromset(C,key=A._key)
	__and__=intersection;__rand__=__and__
	def intersection_update(A,*D):'Update the sorted set with the intersection of `iterables`.\n\n        The `intersection_update` method also corresponds to operator ``&=``.\n\n        ``ss.__iand__(iterable)`` <==> ``ss &= iterable``\n\n        Keep only values found in itself and all `iterables`.\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> _ = ss.intersection_update([4, 5, 6, 7])\n        >>> ss\n        SortedSet([4, 5])\n\n        :param iterables: iterable arguments\n        :return: itself\n\n        ';B=A._set;C=A._list;B.intersection_update(*D);C.clear();C.update(B);return A
	__iand__=intersection_update
	def symmetric_difference(A,other):'Return the symmetric difference with `other` as a new sorted set.\n\n        The `symmetric_difference` method also corresponds to operator ``^``.\n\n        ``ss.__xor__(other)`` <==> ``ss ^ other``\n\n        The symmetric difference is all values tha are in exactly one of the\n        sets.\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> ss.symmetric_difference([4, 5, 6, 7])\n        SortedSet([1, 2, 3, 6, 7])\n\n        :param other: `other` iterable\n        :return: new sorted set\n\n        ';B=A._set.symmetric_difference(other);return A._fromset(B,key=A._key)
	__xor__=symmetric_difference;__rxor__=__xor__
	def symmetric_difference_update(A,other):'Update the sorted set with the symmetric difference with `other`.\n\n        The `symmetric_difference_update` method also corresponds to operator\n        ``^=``.\n\n        ``ss.__ixor__(other)`` <==> ``ss ^= other``\n\n        Keep only values found in exactly one of itself and `other`.\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> _ = ss.symmetric_difference_update([4, 5, 6, 7])\n        >>> ss\n        SortedSet([1, 2, 3, 6, 7])\n\n        :param other: `other` iterable\n        :return: itself\n\n        ';B=A._set;C=A._list;B.symmetric_difference_update(other);C.clear();C.update(B);return A
	__ixor__=symmetric_difference_update
	def union(A,*B):'Return new sorted set with values from itself and all `iterables`.\n\n        The `union` method also corresponds to operator ``|``.\n\n        ``ss.__or__(iterable)`` <==> ``ss | iterable``\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> ss.union([4, 5, 6, 7])\n        SortedSet([1, 2, 3, 4, 5, 6, 7])\n\n        :param iterables: iterable arguments\n        :return: new sorted set\n\n        ';return A.__class__(chain(iter(A),*B),key=A._key)
	__or__=union;__ror__=__or__
	def update(A,*E):
		'Update the sorted set adding values from all `iterables`.\n\n        The `update` method also corresponds to operator ``|=``.\n\n        ``ss.__ior__(iterable)`` <==> ``ss |= iterable``\n\n        >>> ss = SortedSet([1, 2, 3, 4, 5])\n        >>> _ = ss.update([4, 5, 6, 7])\n        >>> ss\n        SortedSet([1, 2, 3, 4, 5, 6, 7])\n\n        :param iterables: iterable arguments\n        :return: itself\n\n        ';B=A._set;C=A._list;D=set(chain(*E))
		if 4*len(D)>len(B):C=A._list;B.update(D);C.clear();C.update(B)
		else:
			F=A._add
			for G in D:F(G)
		return A
	__ior__=update;_update=update
	def __reduce__(A):'Support for pickle.\n\n        The tricks played with exposing methods in :func:`SortedSet.__init__`\n        confuse pickle so customize the reducer.\n\n        ';return type(A),(A._set,A._key)
	@recursive_repr()
	def __repr__(self):'Return string representation of sorted set.\n\n        ``ss.__repr__()`` <==> ``repr(ss)``\n\n        :return: string representation\n\n        ';A=self;B=A._key;C=''if B is _A else', key={0!r}'.format(B);D=type(A).__name__;return'{0}({1!r}{2})'.format(D,list(A),C)
	def _check(B):'Check invariants of sorted set.\n\n        Runtime complexity: `O(n)`\n\n        ';C=B._set;A=B._list;A._check();assert len(C)==len(A);assert all(A in C for A in A)