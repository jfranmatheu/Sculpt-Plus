_A=None
from typing import Set
from collections import defaultdict
class CallbackSet:
	def __init__(A):(A.callback_func):Set[callable]=set()
	def __iadd__(A,function:callable)->_A:A.add(function)
	def __isub__(A,function:callable)->bool:return A.remove(function)
	def add(A,function:callable)->_A:A.callback_func.add(function)
	def remove(A,function:callable)->bool:
		B=function
		if B in A.callback_func:A.callback_func.remove(B);return True
		return False
	def __call__(A,*B,**C)->_A:
		for D in A.callback_func:D(*B,**C)
class _CallbackSetCollection:
	def __init__(A)->_A:(A.callbacks):dict[str,dict[str,CallbackSet]]=defaultdict(dict)
	def get(A,owner_id:str,callback_idname:str)->CallbackSet|_A:
		if(B:=A.callbacks.get(owner_id,_A)):return B.get(callback_idname,_A)
	def init(A,owner_id:str,callback_idname:str)->CallbackSet:A.callbacks[owner_id][callback_idname]=B=CallbackSet();return B
CallbackSetCollection=_CallbackSetCollection()