_C='name'
_B=False
_A=True
import bpy
from bpy.types import UILayout,Context
class BRUSHMANAGER_UL_sidebar_list(bpy.types.UIList):
	use_order_name:bpy.props.BoolProperty(name='Name',default=_B,options=set(),description='Sort groups by their name (case-insensitive)');use_filter_name_reverse:bpy.props.BoolProperty(name='Reverse Name',default=_B,options=set(),description='Reverse name filtering')
	def draw_item(G,context:Context,layout:UILayout,data,item,icon,active_data,active_propname,index,flt_flag):
		E='load_on_boot';A=item;F=getattr(active_data,active_propname);C=layout.row(align=_A);B=C.row(align=_A);B.alignment='LEFT';B.label(text='',icon='KEYTYPE_KEYFRAME_VEC'if index==F else'BLANK1');B.prop(A,_C,text='',emboss=_B,icon_value=A.icon_id if hasattr(A,'icon_id')else 0);D=C.row(align=_A);D.alignment='RIGHT'
		if hasattr(A,E):D.prop(A,E,icon='QUIT',emboss=A.load_on_boot,text='')
	def draw_filter(A,context,layout):C=layout;B=C.row();D=B.row(align=_A);D.prop(A,'filter_name',text='');E='ZOOM_OUT'if A.use_filter_name_reverse else'ZOOM_IN';D.prop(A,'use_filter_name_reverse',text='',icon=E);B=C.row(align=_A);B.label(text='Order by:');B.prop(A,'use_order_name',toggle=_A)
	def filter_items(A,context,data,propname):
		C=getattr(data,propname);D=bpy.types.UI_UL_list;B=[];E=[]
		if A.filter_name:B=D.filter_items_by_name(A.filter_name,A.bitflag_filter_item,C,_C,reverse=A.use_filter_name_reverse)
		if not B:B=[A.bitflag_filter_item]*len(C)
		if A.use_order_name:E=D.sort_items_by_name(C,_C)
		return B,E