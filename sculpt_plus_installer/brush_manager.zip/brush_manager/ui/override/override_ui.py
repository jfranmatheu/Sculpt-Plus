from bpy.utils import register_class,unregister_class
states:dict[type,bool]={}
def toggle_ui(cls_to_replace,my_cls):
	B=cls_to_replace;A=my_cls
	if A not in states:states[A]=False
	try:
		if states[A]:unregister_class(A);register_class(B)
		else:unregister_class(B);register_class(A)
	except(RuntimeError,ValueError)as C:pass
	states[A]=not states[A]
def clear_states():states.clear()