_A=None
import bpy
from bpy.types import UILayout,Context,WindowManager as WM
from gpu.types import GPUTexture
from bpy.props import StringProperty
from enum import Enum,auto
from uuid import uuid4
from brush_manager.paths import Paths
from brush_manager.icons import get_preview,get_gputex,create_preview_from_filepath,clear_icon
IconPath=Paths.Icons
temp_properties:list[str]=[]
def ensure_temp_property(context:Context,item:'IconHolder',attr:str):
	C=attr;B=item;D=context.window_manager;A=B.uuid+C;E=getattr(B,C)
	if not hasattr(D,A):setattr(WM,A,StringProperty(name=A.title(),default=E,update=lambda self,_ctx:setattr(B,C,getattr(self,A))));temp_properties.append(A)
	return A
class IdHolder:
	uuid:str;name:str
	def __init__(A,name:str)->_A:A.uuid=uuid4().hex;A.name=name
	def draw_item_in_layout(C,context:Context,layout:UILayout)->UILayout:A=context;D=A.window_manager;E=ensure_temp_property(A,C.uuid,'name');B=layout.row(align=True);B.prop(D,E,text='Name');return B
class IconHolder(IdHolder):
	icon_path:IconPath=_A
	@property
	def icon_filepath(self)->str:return self.icon_path(self.uuid+'.png')
	@property
	def icon_id(self)->int:return get_preview(self.uuid,self.icon_filepath)
	@property
	def icon_gputex(self)->GPUTexture:return get_gputex(self.uuid,self.icon_filepath)
	def asign_icon(A,filepath:str)->_A:create_preview_from_filepath(A.uuid,filepath,A.icon_filepath)
	def clear_icon(A)->_A:clear_icon(A.uuid,A.icon_filepath)
	def draw_item_in_layout(B,context:Context,layout:UILayout,icon_scale:float=1.)->UILayout:A=super().draw_item_in_layout(context,layout);A.template_icon(B.icon_id,scale=icon_scale);return A
class Collection:0
def unregister():
	for A in temp_properties:delattr(WM,A)