_D='TEXTURE'
_C='AddonDataByMode'
_B='BRUSH'
_A=None
import bpy
from bpy.types import Context,Texture as BlTexture
from bpy.app.timers import register as timer_register
from functools import partial
from pathlib import Path
from enum import Enum,auto
import pickle
from collections import OrderedDict
from brush_manager.pg.pg_ui import UIProps
from brush_manager.paths import Paths
from.cats import Category,BrushCat,TextureCat,BrushCat_Collection,TextureCat_Collection
from.items import BrushItem,TextureItem
from brush_manager.globals import GLOBALS,CM_UIContext
from..utils.callback import CallbackSetCollection
callback__AddonDataInit=CallbackSetCollection.init(_C,'init')
callback__AddonDataLoad=CallbackSetCollection.init(_C,'load')
callback__AddonDataSave=CallbackSetCollection.init(_C,'save')
DataPath=Paths.DATA
class ContextModes(Enum):SCULPT=auto();IMAGE_PAINT=auto();PAINT_GPENCIL=auto()
VALID_CONTEXT_MODES={A.name for A in ContextModes}
_addon_data_cache:dict[str,_C]={}
def init_load_defaults(addon_data:'AddonDataByMode'):A=addon_data;print(f"[brush_manager] Initializing defaults for BM_DATA.{A.mode}@[{id(A)}]");from..api import BM_OPS as B;from..paths import Paths;B.import_library_default(libpath=Paths.Lib.DEFAULT_BLEND(),ui_context_mode=A.mode);callback__AddonDataInit(A)
class AddonDataByMode:
	@classmethod
	def get_data(E,mode:ContextModes|str)->_C:
		D=mode;B:str=D if isinstance(D,str)else D.name
		if(A:=_addon_data_cache.get(B,_A)):return A
		C:Path=DataPath/B
		if not C.exists()or C.stat().st_size==0:print(f"[brush_manager] BM_DATA.{B} not found in path: '{str(C)}'");_addon_data_cache[B]=A=E(B)
		else:
			with C.open('rb')as F:A:AddonDataByMode=pickle.load(F);A.ensure_owners();_addon_data_cache[B]=A
			print(f"[brush_manager] Loaded BM_DATA.{B}@[{id(A)}] from file: '{str(C)}'");callback__AddonDataLoad(A)
		return A
	def save(A,save_items_id_data:bool=True)->_A:
		D:Path=DataPath/A.mode;print(f"[brush_manager] Saving BM_DATA.{A.mode}@[{id(A)}] to file: '{D}'")
		if save_items_id_data:
			for B in A.brush_cats:
				for C in B.items:C.save()
			for B in A.texture_cats:
				for C in B.items:C.save()
		A.clear_owners()
		with D.open('wb')as E:pickle.dump(A,E)
		A.ensure_owners();callback__AddonDataSave(A)
	def clear_owners(A)->_A:A.brush_cats.clear_owners();A.texture_cats.clear_owners()
	def ensure_owners(A)->_A:A.brush_cats.ensure_owners(A);A.texture_cats.ensure_owners(A)
	mode:ContextModes;brush_cats:BrushCat_Collection;texture_cats:TextureCat_Collection;active_brush:BrushItem;active_texture:TextureItem
	@property
	def active_brush(self)->BrushItem|_A:
		A=self
		if A._active_brush is _A:return
		B,C=A._active_brush
		if(D:=A.brush_cats.get(B)):return D.items.get(C)
	@property
	def active_texture(self)->TextureItem|_A:
		A=self
		if A._active_texture is _A:return
		B,C=A._active_texture
		if(D:=A.texture_cats.get(B)):return D.items.get(C)
	@active_brush.setter
	def active_brush(self,brush_item:BrushItem)->_A:A=brush_item;self._active_brush=A.uuid,A.cat_id;A.set_active(bpy.context)
	@active_texture.setter
	def active_texture(self,texture_item:TextureItem)->_A:A=texture_item;self._active_texture=A.uuid,A.cat_id;A.set_active(bpy.context)
	@property
	def active_item(self)->BrushItem|TextureItem|_A:return self.active_brush if GLOBALS.ui_context_item==_B else self.active_texture
	@active_item.setter
	def active_item(self,item:BrushItem|TextureItem)->_A:
		A=item
		if isinstance(A,BrushItem):self.active_brush=A
		elif isinstance(A,TextureItem):self.active_texture=A
	@property
	def active_category(self)->BrushCat|TextureCat|_A:return self.brush_cats.active if GLOBALS.ui_context_item==_B else self.texture_cats.active
	@active_category.setter
	def active_category(self,cat:BrushCat|TextureCat)->_A:A=self.brush_cats if isinstance(cat,BrushCat)else self.texture_cats;A.select(cat)
	def __init__(A,mode:str)->_A:print(f"[brush_manager] New BM_DATA.{mode}@[{id(A)}]");A.mode=mode;A.brush_cats=BrushCat_Collection(A);A.texture_cats=TextureCat_Collection(A);A._active_brush=_A;A._active_texture=_A;timer_register(partial(init_load_defaults,A))
	def add_bl_texture(B,context,bl_texture:BlTexture,set_active:bool=False)->TextureItem:
		" Create a new texture item from a texture datablock.\n            Asign it to a 'unasigned' or specified category and mark as active if wanted. ";D='UNASIGNED';A=B.get_texture_cat(D)
		if A is _A:A=B.new_texture_cat('Unasigned',custom_uuid=D)
		C:TextureItem=A.items.add_from_id_data(bl_texture)
		if set_active:C.set_active(context)
		return C
	def get_cats(B,skip_active:bool=False)->list[Category]:
		A=B.brush_cats if GLOBALS.ui_context_item==_B else B.texture_cats
		if skip_active:C=A.active;return[A for A in A if A!=C]
		else:return A
	def _get_cat(A,cat_uuid:str)->Category|_A:B=A.brush_cats if GLOBALS.ui_context_item==_B else A.texture_cats;return B.get(cat_uuid)
	def get_brush_cat(A,cat_uuid:str)->BrushCat:
		with CM_UIContext(mode=A.mode,item_type=_B):return A._get_cat(cat_uuid)
	def get_texture_cat(A,cat_uuid:str)->TextureCat:
		with CM_UIContext(mode=A.mode,item_type=_D):return A._get_cat(cat_uuid)
	def _new_cat(B,cat_name:str|_A=_A,custom_uuid:str|_A=_A)->Category:A=cat_name;C=B.brush_cats if GLOBALS.ui_context_item==_B else B.texture_cats;A:str=A if A is not _A else'New Category';return C.add(A,custom_uuid=custom_uuid)
	def new_brush_cat(A,cat_name:str|_A=_A,custom_uuid:str|_A=_A)->BrushCat:
		with CM_UIContext(mode=A.mode,item_type=_B):return A._new_cat(cat_name,custom_uuid=custom_uuid)
	def new_texture_cat(A,cat_name:str|_A=_A,custom_uuid:str|_A=_A)->TextureCat:
		with CM_UIContext(mode=A.mode,item_type=_D):return A._new_cat(cat_name,custom_uuid=custom_uuid)
class AddonData:
	_instance=_A
	@classmethod
	def get(A):
		if A._instance is _A:A._instance=AddonData()
		return A._instance
	@classmethod
	def clear_instances(A):
		if A._instance is not _A:
			del A._instance;A._instance=_A
			for B in _addon_data_cache.values():del B
			_addon_data_cache.clear()
	@property
	def SCULPT(self)->AddonDataByMode:return AddonDataByMode.get_data(mode=ContextModes.SCULPT)
	@property
	def IMAGE_PAINT(self)->AddonDataByMode:return AddonDataByMode.get_data(mode=ContextModes.IMAGE_PAINT)
	@property
	def PAINT_GPENCIL(self)->AddonDataByMode:return AddonDataByMode.get_data(mode=ContextModes.PAINT_GPENCIL)
	@classmethod
	def get_data_by_context(B,ctx:Context|UIProps|str|_A=_A)->AddonDataByMode|_A:
		A=ctx
		if A is _A:A=bpy.context
		if isinstance(A,Context):return B.get_data_by_mode(A.mode)
		if isinstance(A,UIProps):return B.get_data_by_mode(A.ui_context_mode)
		if isinstance(A,str):return B.get_data_by_mode(A)
		raise TypeError(f"Invalid context type {A}. Expected bpy.types.Context or brush_manager's UIProps type")
	@classmethod
	def get_data_by_mode(B,mode:str)->AddonDataByMode|_A:
		A=mode
		if A not in VALID_CONTEXT_MODES:raise ValueError(f"Invalid mode! Expected: {VALID_CONTEXT_MODES}; But got: {A}")
		return AddonDataByMode.get_data(mode=A)
	@staticmethod
	def save_all(save_items_id_data:bool=True)->_A:
		for A in _addon_data_cache.values():A.save(save_items_id_data=save_items_id_data)
get_brush_names_by_ctx_mode={'SCULPT':('Blob','Boundary','Clay','Clay Strips','Clay Thumb','Cloth','Crease','Draw','Draw Face Sets','Draw Sharp','Elastic Deform','Fill/Deepen','Flatten/Contrast','Grab','Inflate/Deflate','Layer','Mask','Multi-plane Scrape','Multires Displacement Eraser','Multires Displacement Smear','Nudge','Paint','Pinch/Magnify','Pose','Rotate','Scrape/Peaks','SculptDraw','Simplify','Slide Relax','Smooth','Snake Hook','Thumb'),'IMAGE_PAINT':('TexDraw','Soften','Smear','Clone','Fill','Mask'),'PAINT_GPENCIL':('Airbrush','Ink Pen','Ink Pen Rough','Marker Bold','Marker Chisel','Pen','Pencil','Pencil Soft','Fill Area','Eraser Hard','Eraser Point','Eraser Soft','Eraser Stroke','Tint')}