_D='Expected int (index) or string (uuid)'
_C='Cat_Collection'
_B='Category_Collection'
_A=None
from collections import OrderedDict
from typing import Iterator
from.common import IconHolder,IconPath
from.items import Item,BrushItem,TextureItem,BrushItem_Collection,TextureItem_Collection,Item_Collection
from..utils.callback import CallbackSetCollection
callback__CatsAdd=CallbackSetCollection.init(_B,'cats.add')
callback__CatsRemove=CallbackSetCollection.init(_B,'cats.remove')
class Category(IconHolder):
	owner:object;items:Item_Collection;flags:set;fav:bool
	@property
	def collection(self)->_C:return self.owner
	def __init__(A,name:str)->_A:super().__init__(name);A.flags=set()
	def __del__(A)->_A:del A.items;A.owner=_A
	def set_active(A):A.collection.select(A)
	def save_default(A,compress:bool=True)->_A:
		for B in A.items:B.save_default(compress=compress)
	def reset(A)->_A:
		for B in A.items:B.reset()
	def clear_owners(A)->_A:A.owner=_A;A.items.clear_owners()
	def ensure_owners(A,cat_collection:'Cat_Collection')->_A:A.owner=cat_collection;A.items.ensure_owners(A)
class BrushCat(Category):
	icon_path:IconPath=IconPath.CAT_BRUSH;items:BrushItem_Collection
	def __init__(A,name:str)->_A:super().__init__(name);A.items=BrushItem_Collection(A)
class TextureCat(Category):
	icon_path:IconPath=IconPath.CAT_TEXTURE;items:TextureItem_Collection
	def __init__(A,name:str)->_A:super().__init__(name);A.items=TextureItem_Collection(A)
class Cat_Collection:
	active:Category;cats:OrderedDict[str,Category];owner:object
	@property
	def count(self)->int:return len(self.cats)
	@property
	def favs(self):return[A for A in self.cats.values()if A.fav]
	@property
	def active(self)->Category:return self.get(self._active)
	@property
	def active_id(self)->str:return self._active
	@active.setter
	def active(self,cat:str|Category)->_A:
		A=cat
		if A is _A:self._active='';return
		if not isinstance(A,(str,Category)):raise TypeError('Expected a Category instance or a string (uuid)')
		self._active=A if isinstance(A,str)else A.uuid
	def __init__(A,addon_data_by_mode)->_A:A.cats=OrderedDict();A._active='';(A._selected_items):list[str]=[];A.owner=addon_data_by_mode
	def __iter__(A)->Iterator[Category]:return iter(A.cats.values())
	def __getitem__(B,uuid_or_index:str|int)->Category|_A:
		A=uuid_or_index
		if isinstance(A,str):return B.cats.get(A,_A)
		elif isinstance(A,int):
			C:int=A
			if C<0 or C>=len(B.cats):return
			return list(B.cats.values())[C]
		raise TypeError(_D)
	def get(A,uuid:str)->Category|_A:' Wrapper for __getitem__ method. ';return A[uuid]
	def select(B,cat:str)->_A:
		A=cat
		if isinstance(A,Category):return B.select(A.uuid)
		if isinstance(A,int):C:int=A;return B.select(list(B.cats.keys())[C])
		if isinstance(A,str)and A in B.cats:B._active=A
	def add(C,name:str,_type=Category,custom_uuid:str|_A=_A)->Category:
		B=custom_uuid;A=_type(name)
		if B is not _A and isinstance(B,str)and B!='':A.uuid=B
		C.cats[A.uuid]=A;A.owner=C;A.set_active();callback__CatsAdd(A);return A
	def remove(B,uuid_or_index:int|str|Category)->_A:
		A=uuid_or_index
		if isinstance(A,str):
			if A in B.cats:callback__CatsRemove(B.cats[A]);del B.cats[A]
			return
		if isinstance(A,Category):return B.remove(A.uuid)
		if isinstance(A,int):C:int=A;return B.remove(list(B.cats.keys())[C])
		raise TypeError(_D)
	def clear(A)->_A:A.cats.clear();A.active=_A
	def __del__(A)->_A:
		for B in reversed(A.cats):del B
		A.clear();A.owner=_A
	def clear_owners(A)->_A:
		A.owner=_A
		for B in A.cats.values():B.clear_owners()
	def ensure_owners(A,addon_data_by_mode)->_A:
		A.owner=addon_data_by_mode
		for B in A.cats.values():B.ensure_owners(A)
class BrushCat_Collection(Cat_Collection):
	active:BrushCat;cats:OrderedDict[str,BrushCat]
	def get(A,uuid_or_index:str|int)->BrushCat|_A:return super().get(uuid_or_index)
	def add(A,name:str,custom_uuid:str|_A=_A)->BrushCat:return super().add(name,BrushCat,custom_uuid=custom_uuid)
class TextureCat_Collection(Cat_Collection):
	active:TextureCat;cats:OrderedDict[str,TextureCat]
	def get(A,uuid_or_index:str|int)->TextureCat|_A:return super().get(uuid_or_index)
	def add(A,name:str,custom_uuid:str|_A=_A)->TextureCat:return super().add(name,TextureCat,custom_uuid=custom_uuid)