from..types import AddonData,AddonDataByMode
import bpy
from bpy.types import Context,OperatorProperties
class BaseOp:
	def action(A,context:Context,addon_data_ctx:AddonDataByMode):0
	def execute(C,context)->set[str]:
		A=context;D=AddonData.get_data_by_ui_mode(A);B=C.action(A,D)
		if isinstance(B,set):return B
		return{'FINISHED'}
	@classmethod
	def draw_in_layout(A,layout,**B)->OperatorProperties:return layout.operator(A.bl_idname,**B)
	@classmethod
	def run(A,*B,**C)->None:D,E=A.bl_idname.split('.');getattr(getattr(bpy.ops,D),E)(*B,**C)