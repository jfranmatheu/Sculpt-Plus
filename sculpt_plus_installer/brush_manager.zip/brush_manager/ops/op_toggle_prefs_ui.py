import bpy
from bpy.types import Context
from brush_manager.addon_utils import Reg
enabled=False
def toggle_addon_prefs():from..ui.override.sidebar_actions import USERPREF_PT_brush_manager_sidebar_actions as A;from..ui.override.sidebar import USERPREF_PT_brush_manager_sidebar as B;from..ui.override.header import USERPREF_HT_brush_manager_header as C;from..ui.override.content import USERPREF_PT_brush_manager_content as D;B.toggle();A.toggle();C.toggle();D.toggle();global enabled;enabled=not enabled
@Reg.Ops.setup
class ToggleBrushManagerUI(Reg.Ops.ACTION):
	label='Toggle Brush Manager UI'
	def action(E,context:Context,_ui_props,_addon_data)->set[str]:
		A=context;A.preferences.active_section='ADDONS';toggle_addon_prefs();global enabled;C=enabled;D='TOP'if enabled else'BOTTOM';A.space_data.show_region_header=C
		for B in A.area.regions:
			if B.type=='HEADER':
				if B.alignment!=D:
					with A.temp_override(window=A.window,area=A.area,region=B):bpy.ops.screen.region_flip()
				break
def unregister():
	global enabled
	if enabled:toggle_addon_prefs()